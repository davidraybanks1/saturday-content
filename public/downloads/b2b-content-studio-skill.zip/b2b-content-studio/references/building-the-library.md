# Building a messaging library

## From existing materials (fastest)

Ask the user for whatever they have: a positioning doc, persona one-pagers, a messaging house, sales decks, website copy, win/loss notes. Read them, then draft entries following `library-schema.md`.

- Pull **goal**, **emphasize** and **value** from positioning and messaging docs.
- Pull **pains** and **objections** from sales material, call notes and win/loss notes. Keep the customer's wording.
- Pull **proof** from product pages and case studies. Only include what's stated in the materials.
- Infer **avoid** from what the materials explicitly reject ("we are not a…"), and confirm it with the user.

Mark anything you inferred rather than read with "(inferred)" in your summary so the user can check it.

## By interview (no materials)

Ask these in two or three short rounds, not all at once.

**Round 1: the company**
1. What do you sell, to whom, in one sentence?
2. What should people never call it?
3. How should your content sound? Name a brand whose voice you like, if that's easier.

**Round 2: per persona (repeat for 3–6 personas)**
4. Which roles buy or use it, and what are their titles?
5. What's going wrong for them before they find you?
6. What should they believe after reading your content?
7. What do they push back with, and how do you answer?
8. What can you prove: features, numbers, customers you're allowed to name?

**Round 3: industries (optional)**
9. Which industries matter, and what's different about selling to each (regulation, buyers, vocabulary)?

## Before publishing

Show a compact table of every entry (name, goal, top pain, top proof point) and ask the user to confirm or correct it. Then write the full entries into the page's `LIBRARY` block.
