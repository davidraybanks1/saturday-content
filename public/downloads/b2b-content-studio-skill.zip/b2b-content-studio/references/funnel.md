# Funnel stages

| Stage | Reader's state | What to do | Product mentions | Typical call to action |
|---|---|---|---|---|
| **Top of funnel (TOFU)** | Feels the problem, isn't shopping | Name the problem sharply and give one useful idea | Light or none | Read more, subscribe, follow |
| **Middle of funnel (MOFU)** | Exploring approaches | Teach a method, compare options fairly, show where the product fits | Present but not pushy | Download, register for a webinar, see how it works |
| **Bottom of funnel (BOFU)** | Choosing a vendor | Be specific about value, proof, pricing logic and objections | Central | Start a trial, book a demo, talk to sales |

## Signals in a request

- **Top of funnel:** "awareness", "thought leadership", "top of funnel", or a request for "LinkedIn" content with no product angle.
- **Middle of funnel:** "guide", "comparison", "how to choose", "webinar".
- **Bottom of funnel:** "product page", "battlecard", "vs competitor", "pricing", "case study".

When no stage is given and none is implied, don't pick one silently. Write for the stage that suits the format, and say which stage you chose.
