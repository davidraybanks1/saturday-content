# Format playbooks

The studio page carries short versions of these in its `FORMATS` block. Use the fuller notes below when writing in chat.

## LinkedIn post
- **Length:** 150–250 words.
- **Opening:** the first two lines show before "see more", so the hook goes there. Use a claim, a number from the library, or a tension.
- **Body:** one idea, one concrete example, one takeaway. Keep paragraphs to one or two lines.
- **Ending:** a question, or a light call to action.
- **Hashtags:** 3 at most, at the end.
- **Voice:** first person when written for an individual's byline.
- **Avoid:** "I'm excited to announce", engagement bait, and emoji bullets unless that's the house style.

## Blog post
- **Length:** 1,000–1,500 words.
- **Title:** an H1 that matches what the reader would search for.
- **Intro:** 2–3 sentences that name the problem and promise the payoff.
- **Body:** 4–6 H2 sections, with at least one framework, example or checklist.
- **Ending:** a short conclusion and one call to action.
- **Meta description:** suggest one, under 155 characters.

## Ebook
- **Title page:** a title and subtitle that state the outcome, plus who it's for.
- **Chapters:** 5–7, each with a one-paragraph summary and its key takeaway.
- **Practical piece:** at least one worksheet, template or checklist.
- **Landing page:** a headline, 3 bullets on what's inside, and a call to action.
- **Funnel stage:** usually middle of funnel. Keep product mentions to one chapter and the close.

## Webinar
- **Title:** a title plus a 3-bullet promise of what attendees will leave with.
- **Speakers:** roles, with one customer or practitioner voice where possible.
- **Run of show for 45 minutes:**
  - Intro: 5 minutes
  - Three segments: 10 minutes each
  - Demo or case study: 5 minutes
  - Q&A: 10 minutes
- **Questions:** 5 to seed the Q&A.
- **Registration page:** a short blurb, plus one follow-up email.

## Product page
- **Hero:** a headline that states the outcome, a subhead that says how, and a primary call to action.
- **Value:** 3 pillars, each with one proof point from the library.
- **How it works:** 3–4 steps.
- **FAQ:** 3–5 questions that answer the persona's objections.
- **Calls to action:** a primary one (trial or demo) and a secondary one (tour, pricing, docs).

## Web page (hub, solution or landing page)
- **Opening:** a clear H1 and one orienting paragraph.
- **Sections:** 3–5 short sections, each routing the visitor to a next page.
- **Close:** a call to action.
- **Style:** scannable. Use subheads and short lists, and avoid long paragraphs.

## Adding formats

Add an entry to `FORMATS` in the page (id, name, icon, blurb, play). Good candidates:
- Case study
- Sales email sequence
- Press release
- Newsletter issue
- Video script
- One-pager
