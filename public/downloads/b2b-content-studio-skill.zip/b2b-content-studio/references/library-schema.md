# Messaging library schema

One entry per audience. An audience is a **persona** (a role or buyer) or a **vertical** (an industry). A request can pick one of each; both entries go into the prompt.

```json
{
  "id": "content-lead",
  "dimension": "persona",
  "name": "Content lead",
  "icon": "target",
  "blurb": "Ship more without more meetings",
  "titles": "Head of Content, Content Marketing Manager",
  "goal": "What this audience should come to believe about the product. One or two sentences.",
  "tone": "How to sound for this audience.",
  "pains": "What's going wrong for them today, in their words.",
  "emphasize": "The 3–5 themes to lead with.",
  "avoid": "Positioning, words or claims to stay away from. Be blunt.",
  "proof": "Real capabilities, data or customer facts the writer may cite.",
  "objections": [{ "o": "The objection, as they'd say it.", "r": "The answer." }],
  "value": "The outcome to land, in one sentence.",
  "metrics": "How this audience is measured, or how the company measures content for them."
}
```

## Field guidance

| Field | Required | Notes |
|---|---|---|
| `id` | yes | lowercase-hyphenated, unique |
| `dimension` | yes | `persona` or `vertical` |
| `name`, `blurb` | yes | Shown on the picker card. Blurb under 40 characters. |
| `icon` | no | A key from the page's `ICON` map |
| `goal` | yes | The single most important field. Specific to this audience. |
| `pains` | yes | Use the audience's language, not the company's. |
| `avoid` | strongly recommended | Stops the most common brand mistakes. Use "Don't…" sentences. |
| `proof` | strongly recommended | Only real, verifiable things. The writer may use nothing else as evidence. |
| `objections` | recommended | 1–3 is plenty. |
| `titles`, `tone`, `emphasize`, `value`, `metrics` | optional | Fill when known. |

## Quality bar

- Each entry should be usable on its own: a writer who reads only this entry should know what to say and what not to.
- Vertical entries describe what changes *for that industry* (regulation, buyers, vocabulary). Don't repeat the persona content.
- Keep sentences short. The whole entry should fit in about 250 words.
- Never put confidential customer names or unreleased plans in a library that will be shared beyond the team.
