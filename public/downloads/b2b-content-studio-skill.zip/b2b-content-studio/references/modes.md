# Modes

Every request is one of four modes. All four use the same inputs: optional format, persona, industry and funnel stage, plus any extra context. Remix and Critique also need source content.

## Draft

**Use for:** "write", "draft", "create", "give me a…"

**Output**
1. **Proposal**
   - 2–3 working titles
   - The angle in one or two sentences
   - Why it fits this audience
   - A short outline
2. **Draft:** a complete first draft that follows the format playbook.

## Remix

**Use for:** "turn this into", "repurpose", "rewrite for", "adapt"

**Needs:** source content. If it's missing, ask for it in one line.

**Output**
1. The remixed piece, in the target format for the target audience.
2. **What changed:** 3–5 bullets explaining each change.

**Rules:** keep the strongest ideas and every fact from the source. Cut whatever doesn't serve the new reader. Add only what the new format needs. Don't add claims the source didn't make, unless they're proof points from the library.

## Critique

**Use for:** "review", "feedback on", "what's wrong with", "critique"

**Needs:** source content.

**Output**
1. A one-line verdict.
2. A score out of 10 for each of:
   - Audience fit
   - Clarity
   - Message alignment (against the library)
   - CTA strength
3. The 3 biggest strengths.
4. The 3–5 most important fixes, in priority order. Each fix gets a concrete suggested rewrite.
5. A rewritten opening.

**Rules:** judge the piece against the chosen persona, industry, format and stage. Call out anything that breaks an "Avoid" line. Be direct, and don't pad the strengths.

## Brainstorm

**Use for:** "ideas", "topics", "what should we write about", "content gaps"

**Output**
1. **10 distinct ideas.** For each:
   - A working title
   - The angle in one sentence
   - The hook
   - Why this audience would care now
2. **Whitespace:** 2–3 questions this audience has that most competitors don't answer.
3. **Strongest three:** the 3 best ideas, with a one-line reason for each.

**Rules:** vary the formats when no format is chosen. Tie ideas to the audience's pains and objections from the library.

## Rules for every mode

- **Voice:** write in the house voice from the company config.
- **Evidence:** use only proof points from the library or the user's context. Never invent statistics, customer names or quotes. Write `[placeholder: what's needed]` instead.
- **Formatting:** use Markdown with clear headings. Start with the output itself, with no preamble.
- **Call to action:** match it to the funnel stage. When nothing fits, use the company's default.
