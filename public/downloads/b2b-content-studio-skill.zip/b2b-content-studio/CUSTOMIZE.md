# B2B content studio — setup and customization guide

The B2B content studio drafts, remixes, critiques and brainstorms content from your own messaging. You can use it two ways:

- **Ask Claude in chat.** For example: "Draft a LinkedIn post for our ops persona, top of funnel."
- **Share a studio page with your team.** People pick a mode, a format, a persona, an industry and a funnel stage, and the page writes with Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Your messaging in any form: a positioning doc, persona one-pagers, sales decks, or just answers to a few questions.

## 1. Install the skill

Add the `b2b-content-studio` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Build your messaging library

Start a new chat and say: **"Use the b2b-content-studio skill to build our messaging library."** Then attach whatever messaging you have.

- **If you have documents:** Claude drafts one entry per persona and industry from them. It marks anything it had to guess, so you can check it.
- **If you have nothing written down:** Claude interviews you in two or three short rounds.

Check the summary table carefully before you say yes. Every piece of content the studio writes takes its goal, pains, proof points and "avoid" rules from this library.

## 3. Publish your studio page (optional)

Say: **"Publish our content studio page."** Claude puts your library and house voice into the page and publishes it as a private page. Share it from the page's Share menu.

The first time each teammate clicks Generate, Claude asks them to allow the page to use Claude. Each generation uses that teammate's own Claude usage.

## 4. Write

| Mode | Use it to | You provide |
|---|---|---|
| Draft | Get a proposal and a full first draft | Optional picks and context |
| Remix | Turn existing content into a new format or for a new audience | The source content |
| Critique | Get scored, prioritized feedback with rewrites | The draft |
| Brainstorm | Get 10 ideas, whitespace, and a top three | Optional picks and context |

All four picks (format, persona, industry, funnel stage) are optional. The more you pick, the more specific the output.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Add a persona | "Add a CFO persona to our library: [what you know about them]." |
| Change positioning | "We no longer lead with AI. Update the library and republish the studio." |
| Add a format | "Add case studies and sales emails as formats." |
| Change the voice | "Make our house voice warmer and less formal. Here's an example post we like: …" |
| Rebrand the page | "Use our colors and fonts on the studio page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/studio.html`:

- **`CONFIG`:** company, about, house voice, default CTA, branding.
- **`LIBRARY`:** your audiences. See `references/library-schema.md`.
- **`FORMATS` and `FUNNEL`:** the playbooks the studio follows.
- **`EXAMPLES`:** the worked examples shown when Claude isn't connected. Replace them with your own, or delete them.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| Output invents numbers or customers | Add the real proof to the library's `proof` field. The studio is told never to invent evidence, and uses placeholders instead. |
| Output sounds off-brand | Tighten the house `voice` and the persona's `tone` and `avoid` fields. |
| Remix or Critique button stays disabled | Paste the source content in step 1. |
