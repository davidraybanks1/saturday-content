---
name: b2b-content-studio
description: Draft, remix, critique and brainstorm B2B content for a specific format, persona, industry and funnel stage using a company's own messaging library. Also builds the team a published B2B Content Studio page that writes with Claude. Use for B2B content creation, messaging-aligned drafts, content critique, or setting up a messaging library.
---

# B2B content studio

This skill writes B2B content from a **messaging library**: a structured record of who the company sells to (personas and industries) and what to say to each. Every piece of content is shaped by four optional picks (format, persona, industry, funnel stage) and one of four modes (Draft, Remix, Critique, Brainstorm).

It works two ways:

1. **In chat.** The user asks for content; you write it using the library and the playbooks in `references/`.
2. **As a studio page.** You publish `templates/studio.html` as a private artifact with the team's library and voice inside it. Teammates pick a mode and targets, and the page writes with Claude on their own account.

## Files

| File | Read it when |
|---|---|
| `references/library-schema.md` | Building or editing a messaging library |
| `references/building-the-library.md` | The user has no library yet, or gives you raw messaging docs |
| `references/modes.md` | Running any Draft, Remix, Critique or Brainstorm request |
| `references/formats.md` | Writing any specific format |
| `references/funnel.md` | A funnel stage is chosen or implied |
| `references/example-library.json` | You need a model of a finished library |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Find the library.** Look for one in this conversation, the project's files, or a connected doc. If there isn't one, ask whether to build one now (`building-the-library.md`) or work from what the user tells you in the message. Don't stall: a single sentence about the product and audience is enough to start.
2. **Resolve the picks.** Mode from the verb (write/draft → Draft; turn into/repurpose → Remix; review/feedback → Critique; ideas/topics → Brainstorm). Format, persona, industry and funnel stage from the request; leave any unclear pick open rather than asking, and say which you assumed in one line.
3. **Pull the matching library entries** (persona and industry) and the format and funnel playbooks.
4. **Write**, following `modes.md` for the output structure.
5. **Keep it honest.** Use only proof points from the library or the user. Never invent statistics, customers or quotes; write `[placeholder: what's needed]` instead. Respect every "Avoid" line.

## Building the studio page for a team

1. **Build the library** from the user's materials using `building-the-library.md`. Show it back as a compact table (one row per audience: name, goal, top pain, top proof point) and get a yes before publishing.
2. **Copy `templates/studio.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice` (house style rules), `ctaDefault`, `demoNote` (`""` for a real team), `brand` (their company name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `LIBRARY`: the team's entries, following `library-schema.md`. Pick `icon` names from the `ICON` map in the file.
   - `FORMATS` and `FUNNEL`: keep the defaults unless the team uses other formats (add a case study, press release, sales email, etc. with its own `play`).
   - `EXAMPLES`: replace with one worked example per mode written from their library, or delete the entries (the Example tab then hides itself for that mode).
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the page falls back to building the prompt for the viewer to paste into Claude.
4. **Tell the user** that each teammate is asked once to allow the page to use Claude, that generation uses their own Claude usage, and that the library changes when they ask you to update it and republish.

## Keeping the library current

When the user says messaging changed ("we're not leading with AI anymore", "add a CFO persona"), update the entries, keep the schema, and republish the page to the same artifact. Summarize what changed in one or two lines.
