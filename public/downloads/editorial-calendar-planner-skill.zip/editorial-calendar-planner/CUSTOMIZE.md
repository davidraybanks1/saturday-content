# Editorial calendar planner — setup and customization guide

The editorial calendar planner turns your goals, launches and team capacity into a 13-week content calendar. You can use it three ways:

- **Ask Claude in chat.** For example: "Plan Q2. We launch SSO on May 6, publish two blog posts and three LinkedIn posts a week, and can make five pieces a week."
- **Get a spreadsheet.** Ask Claude to build the calendar as a spreadsheet for Google Sheets or Excel.
- **Share a planner page with your team.** People adjust the inputs, see the calendar update, copy it as CSV, and ask Claude to fill or rebalance it.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Your quarter's start date and any launches, webinars or events with dates.
- A rough idea of how often you publish on each channel, and how many pieces your team can make in a week. If you don't know, Claude suggests a starting point.

## 1. Install the skill

Add the `editorial-calendar-planner` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Plan your quarter

Start a new chat and say: **"Use the editorial-calendar-planner skill to plan next quarter."** Then give Claude:

| Input | Example |
|---|---|
| Quarter start | April 5 |
| Goals (up to three) | Pipeline, product adoption |
| Launches and events | SSO launch, May 6. Customer webinar, May 27 |
| Content pillars (three to five) | Security for small teams; Admin time; Proving ROI |
| Cadence | Blog 2/week, LinkedIn 3/week, newsletter 2/month, video 1/month |
| Capacity | 5 pieces a week |
| Assets to reuse | Last quarter's survey report, two webinar recordings |

Claude lays out every slot, checks each week against capacity, and tells you where the plan doesn't fit before you commit to it.

## 3. Publish your planner page (optional)

Say: **"Publish our editorial calendar planner page."** Claude puts your quarter, pillars and cadence into the page and publishes it as a private page. Share it from the page's Share menu.

The calendar itself is built in the browser, so it costs no Claude usage. The first time a teammate clicks **Fill with Claude** or **Rebalance with Claude**, they're asked to allow the page to use Claude, and it uses their own Claude usage.

## 4. Work the calendar

| Action | What you get |
|---|---|
| Grid, List, Counts | The calendar by week and channel, a dated list, and per-week counts by pillar and channel |
| Copy as CSV / Copy for Sheets | The full calendar to paste into Google Sheets or Excel |
| Fill the calendar | A working title and angle for every slot, written into the grid |
| Rebalance | A review of the plan with specific changes that fit your capacity |

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Add a channel | "Add a podcast channel, one episode every two weeks, counts as 3 pieces." |
| Change how much a piece costs | "Our blog posts are long. Count each as 1.5 pieces." |
| Change the launch playbook | "We tease launches three weeks out, not two, and we don't do video." |
| Change the default quarter | "Set the page's sample to our Q3 plan." |
| Rebrand the page | "Use our colors and fonts on the planner page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/editorial-calendar-planner.html`:

- **`CONFIG`:** company, about, house voice, branding.
- **`GOALS`:** the five goals and how well each channel serves them (`fit`, 0–3).
- **`CHANNELS`:** effort per piece and default publish days.
- **`KITS`:** the launch, webinar and event timelines. See `references/launch-timeline.md`.
- **`SAMPLE_PLAN`:** the quarter the page opens with.
- **`EXAMPLES`:** the worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · planner + prompt" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. The planner still works. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| A week is red | It's over capacity after the planner moved what it could. Campaign pieces never move. Lower a cadence, raise capacity, or ask Claude to rebalance. |
| A launch has no content | Its date is outside the 13 weeks, or the channels in its kit are set to 0. |
| Titles disappeared from the grid | You changed an input after filling. Titles only show for the plan they were written for. Fill again. |
| Fill stops partway through | The answer was cut short. The titles that arrived are kept. Fill again, or lower a cadence. |
| Inputs reset on another computer | Inputs are saved in each browser only. Share the plan by copying it as CSV. |
