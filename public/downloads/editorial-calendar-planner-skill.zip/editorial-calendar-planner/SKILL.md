---
name: editorial-calendar-planner
description: Plan a quarter of B2B content from goals, launches, pillars, channel cadence and team capacity, with launch lead time, even pillar rotation and capacity checks. Also builds the team a published planner page that fills and rebalances the calendar with Claude, or a spreadsheet of the calendar. Use for editorial calendars, quarterly content plans, launch content timelines, or "what should we publish this quarter".
---

# Editorial calendar planner

This skill turns a quarter's inputs into a 13-week content calendar:

- **Inputs:** quarter start date, up to three goals, launches and events, three to five content pillars, channel cadence, team capacity in pieces per week, and assets to reuse.
- **Output:** a slot for every piece (week, date, channel, pillar, goal, and its role: campaign, evergreen or reuse), checked against capacity. Then working titles and angles for every slot, and a review that proposes changes.

It works three ways:

1. **In chat.** The user gives you the inputs; you plan the calendar with the method in `references/planning-method.md` and write it out.
2. **As a spreadsheet.** If the user wants a file, build the calendar as an .xlsx (see "Building the spreadsheet" below).
3. **As a planner page.** You publish `templates/editorial-calendar-planner.html` as a private artifact with the team's defaults inside. The page plans the calendar in the browser, exports CSV, and uses Claude on the viewer's account to **Fill the calendar** and **Rebalance**.

## Files

| File | Read it when |
|---|---|
| `references/planning-method.md` | Planning any calendar. The six steps the page runs, in words |
| `references/launch-timeline.md` | A launch, webinar or event is in the quarter |
| `references/cadence-benchmarks.md` | The user doesn't know their cadence or capacity, or asks if theirs is realistic |
| `references/sample-plan.json` | You need a model of finished inputs and a filled calendar (Fieldbook, fictional) |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Planning in chat

1. **Collect the inputs.** Ask only for what's missing, in one short message. Defaults if the user doesn't know: capacity from `cadence-benchmarks.md`, pillars drafted from their product and audience (confirm them), quarter starting on the next Monday after the quarter boundary.
2. **Check the math first.** Add up weekly effort from the cadence (blog 1, LinkedIn 0.5, newsletter 1, webinar 3, video 2). If the cadence needs more than capacity before launches are added, say so and suggest what to cut before you plan.
3. **Plan** with `planning-method.md`: recurring slots, launch kits from `launch-timeline.md`, reuse, capacity, pillars, goals.
4. **Show it** as a week-by-week table: Week, Date, Channel, Pillar, Goal, Role, Working title, Angle. Then per-pillar and per-channel totals, and a short list of flags (weeks over capacity, launches too close together, uneven pillars).
5. **Keep it honest.** Never invent statistics, customer names, quotes or results in titles or angles. Write `[placeholder: what's needed]` instead. Don't add launches the user didn't name.

When the user asks to **rebalance**, review the plan against its goals and capacity and return: a one-line verdict, what's working, a table of proposed changes (change, weeks, why, capacity effect), the revised load, and risks.

## Building the spreadsheet

If the user asks for a spreadsheet, a Sheets/Excel file, or "something I can share with the team":

- Use the `xlsx` skill if it's available.
- Sheet **Calendar:** one row per slot with the columns from step 4 plus Campaign, Phase, Reuse and Slot ID. Freeze the header row and filter it. Shade campaign rows lightly, and color the Pillar cell by pillar.
- Sheet **Load:** one row per week with effort, capacity and a formula for remaining capacity (`=capacity - effort`). Use conditional formatting to turn the cell red when it's below zero.
- Sheet **Counts:** pillars × weeks and channels × weeks, using `COUNTIFS` against the Calendar sheet so counts update when the team edits rows.
- Sheet **Inputs:** goals, pillars, cadence, capacity and launches as entered.

## Building the planner page for a team

1. **Confirm the defaults** with the user: pillars, cadence, capacity, goals, and the quarter's launches. Show them back as a short list and get a yes.
2. **Copy `templates/editorial-calendar-planner.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice`, `demoNote` (`""` for a real team), `brand` (their name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `SAMPLE_PLAN`: the team's quarter. This is what the page loads with and what "Load the sample" restores.
   - `CHANNELS`: change `effort` if their pieces are bigger or smaller (a 2,500-word blog post might be 1.5). Add a channel (for example podcast) with its own `id`, `code`, `icon`, `effort` and `days`.
   - `KITS`: adjust if their launch playbook differs. See `launch-timeline.md`.
   - `GOALS`: change `fit` scores if a channel serves a goal better for them.
   - `EXAMPLES`: replace with examples from their plan, or leave the Fieldbook ones with the demo note.
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the planner still works, and the Claude step builds the prompt for the viewer to paste.
4. **Tell the user** that the plan itself runs in the browser with no Claude usage, that each teammate is asked once to allow Fill and Rebalance, and that inputs are remembered per browser only. To share one plan, copy it as CSV into a shared sheet.

## Keeping it current

When launches move or the team changes ("the dashboard launch slipped two weeks", "we lost a writer"), update `SAMPLE_PLAN` (or just the inputs in chat), replan, and say in one or two lines what moved and which weeks changed load.
