# Cadence and capacity: starting points

These are starting points for a conversation, not statistics. They come from common practice, not from a study. Every team's real numbers depend on piece length, review steps, how much design and video work is in-house, and how many other jobs the writers have. Say so when you use them, and replace them with the team's own history as soon as they have it.

## Capacity by team shape

"Pieces" are effort units: one standard blog post = 1.

| Team | Starting capacity | Notes |
|---|---|---|
| One content marketer, some freelance help | 3–4 pieces a week | Most of the week goes to briefing, editing and publishing, not writing |
| Two to three writers and an editor | 5–8 pieces a week | Review is usually the bottleneck, not writing |
| Four or more, with design and video support | 8–12 pieces a week | Plan for launches to take a full week of someone's time |

Leave about 15% of capacity unplanned. Something always comes up: a sales request, an exec post, a slipped review.

## Effort per piece

| Piece | Starting effort | Raise it when |
|---|---|---|
| Blog post, 1,000–1,500 words | 1 | It's long-form, needs research or an SME interview (1.5–2) |
| LinkedIn post | 0.5 | It's a carousel or needs design (1) |
| Newsletter issue | 1 | It's original writing rather than a roundup (1.5) |
| Webinar | 3 | It includes a customer guest or a deck built from scratch (4) |
| Short video, under 3 minutes | 2 | It's scripted and edited in-house (3) |
| Repurposed piece | Half the effort of the format | The source needs heavy rework |

## Cadence by goal

| Goal | A sensible starting cadence |
|---|---|
| Awareness | LinkedIn 3–5 a week; blog 1–2 a week; video 2–4 a month |
| Pipeline | Blog 1–2 a week, aimed at evaluators; webinar 1 a month or quarter; newsletter 2 a month |
| Product adoption | A how-to after every release; newsletter 2–4 a month to customers; video walkthroughs 2 a month |
| Retention | Newsletter 2–4 a month; customer webinar or office hours 1 a month |
| Thought leadership | One bylined point-of-view piece every two weeks; LinkedIn 2–3 a week from named people |

## Checks before committing

- **Consistency beats volume.** A cadence the team can hold for 13 weeks is better than a bigger one that collapses in week 6.
- **Launch weeks cost extra.** Plan evergreen load at 70–80% of capacity in quarters with two or more launches.
- **Count review time.** If every piece needs two review rounds, effective capacity is lower than writing capacity.
- **One new channel at a time.** Adding a channel mid-quarter usually takes capacity from the others.
