# Launch content timeline

These are the default kits the planner applies around each launch, webinar or event. Week 0 is the week of the event. Negative weeks come before it. The page stores them in its `KITS` block.

These are starting points, not rules. A big launch may want a longer tease. A small feature may only need the launch-week pieces.

## Launch (feature or product)

| When | Channel | Phase | Piece |
|---|---|---|---|
| −2 weeks | LinkedIn | Teaser | Name the problem the launch solves, without the product |
| −1 week | Blog | Teaser | The problem post: why the old way breaks |
| −1 week (±1) | Newsletter | Teaser | Heads-up to subscribers: something is coming |
| Launch day | Blog | Launch | The announcement: what it is, who it's for, how to try it |
| Launch day | LinkedIn | Launch | Launch post from the company page or a leader |
| Week of (±1) | Video | Launch | Two-minute walkthrough |
| Week of (±1) | Newsletter | Launch | Launch issue for customers |
| +1 week | Blog | Follow-up | How-to or use case for the new feature |
| +1 week | LinkedIn | Follow-up | What early users did first |
| +2 weeks | LinkedIn | Follow-up | One detail people missed |
| +3 weeks | Blog | Follow-up | Deeper use case or customer story |

**Why this shape:** the teaser builds a reason to care before the news. The launch week answers "what is it" on every active channel at once. Follow-ups answer "how do I use it", which is the content that drives adoption and is the most often skipped.

## Webinar

| When | Channel | Phase | Piece |
|---|---|---|---|
| −3 weeks | LinkedIn | Promo | Announce the session and the one thing attendees will leave with |
| −2 weeks (±1) | Newsletter | Promo | Invitation to subscribers |
| −2 weeks | Blog | Promo | Problem post that ends with the registration link |
| −1 week | LinkedIn | Promo | Speaker post: a question the session answers |
| Event day | Webinar | Event | The live session (always placed) |
| Event day | LinkedIn | Event | Last call on the day |
| +1 week | Blog | Follow-up | Recap with the three strongest answers |
| +1 week (±1) | Video | Follow-up | Clips from the session |
| +2 weeks (±1) | Newsletter | Follow-up | Recording and recap for everyone who missed it |

## Event (conference, field event, community meetup)

| When | Channel | Phase | Piece |
|---|---|---|---|
| −2 weeks | LinkedIn | Promo | Where to find us and what we'll talk about |
| Event day | LinkedIn | Event | From the floor: one idea worth sharing |
| +1 week | Blog | Follow-up | What we heard: takeaways for people who weren't there |
| +1 week (±1) | Newsletter | Follow-up | Event takeaways for subscribers |

## Rules of thumb

- **Two weeks apart, minimum.** Launches closer than that compete for the same teaser and follow-up slots. Move one, or merge them into one story.
- **Protect launch week.** If launch week is over capacity, cut evergreen pieces in that week before you cut launch pieces.
- **The date moves, the kit moves.** If a launch slips, shift the whole kit by the same number of weeks. Don't leave the teasers where they were.
- **Name the owner.** Each launch piece needs one owner and a review date at least three working days before publishing. Product marketing usually reviews the announcement.
