# Planning method

The planner page runs these six steps in the browser. Follow the same steps when planning in chat, so a calendar you write by hand matches what the page would produce. Same inputs, same calendar.

## 0. Set up the quarter

- **13 weeks**, starting on the Monday of the start date's week. Number them 1–13.
- **Effort per piece** (the default; teams can change it):

| Channel | Effort | Default publish days |
|---|---|---|
| Blog | 1 | Tue, Thu |
| LinkedIn | 0.5 | Mon, Wed, Fri, then Tue, Thu |
| Newsletter | 1 | Thu, then Tue |
| Webinar | 3 | Wed |
| Video | 2 | Fri, then Wed |

- **Capacity** is pieces of effort per week. A week's load is the sum of effort of its slots.
- **Before planning,** multiply out the cadence. If evergreen load alone is above capacity, tell the user and suggest a cut first. Launches only add to it.

## 1. Recurring slots

- **Per-week channels:** the same count every week, on the channel's days in order.
- **Per-month channels:** three per month for the quarter (2 per month = 6 slots). Split the 13 weeks into equal stretches, one per slot, and put each slot in the lightest week of its stretch. This keeps monthly pieces from stacking up.

## 2. Launch and event kits

For each launch, webinar or event inside the quarter, apply its kit from `launch-timeline.md`.

- **Take over before you add.** If the channel already has an evergreen slot in that week, the kit piece takes it over. A launch then replaces evergreen content instead of piling on.
- **Flex.** Newsletter and video pieces may look one week away for a slot to take over: teasers look earlier, follow-ups look later, and nothing crosses the event week.
- **Same day.** The launch post, launch-day social and the webinar itself go on the event's own date.
- **Off channels.** Skip kit pieces for channels with a cadence of 0, except the webinar session itself.
- **Edges.** Drop pieces that fall before week 1 or after week 13, and tell the user.
- **Pillar.** Every kit piece takes the launch's pillar.
- **Collisions.** If two events are less than two weeks apart, flag it. Their teasers and follow-ups overlap, and one of them usually needs to move or shrink.

## 3. Reuse

Spread the listed assets evenly across the quarter. Attach each to the evergreen slot nearest its target week, preferring video, then LinkedIn, then blog, then newsletter. A reused piece costs half effort.

## 4. Capacity

For each week over capacity, move evergreen slots, largest effort first, to the nearest week with room (±1 week, then ±2). Campaign pieces never move. Any week still over gets a flag in red. The fix is a human decision: drop a piece, shorten one, or add help.

## 5. Pillars and goals

- **Pillars.** Walk the slots in date order. Campaign slots keep their launch's pillar. Every evergreen slot takes the pillar with the lowest score, where the score is:
  - the pieces it already has,
  - plus its campaign pieces still to come, weighted by how far into the quarter you are,
  - plus a penalty for repeating a pillar in the same week, and a larger one for repeating it in the same channel and week.

  The result is an even split by the end of the quarter, with launch-heavy pillars resting before their launch.
- **Goals.** Campaign slots take a goal from the event type: launches → adoption, then pipeline; webinars → pipeline, then thought leadership; events → awareness, then thought leadership. Pick the first of these the user chose. Evergreen slots take the chosen goal with the best channel fit (below), with a penalty for goals already ahead of an even share.

| Channel fit (0–3) | Awareness | Pipeline | Adoption | Retention | Thought leadership |
|---|---|---|---|---|---|
| Blog | 2 | 2 | 2 | 1 | 3 |
| LinkedIn | 3 | 1 | 1 | 0 | 3 |
| Newsletter | 0 | 2 | 3 | 3 | 2 |
| Webinar | 1 | 3 | 2 | 3 | 2 |
| Video | 3 | 1 | 3 | 2 | 1 |

## 6. Flags

Report, in this order:
- Weeks over capacity, with load and capacity.
- Events outside the quarter, and events less than two weeks apart.
- No goals picked; fewer than three or more than five pillars.
- Pillars uneven by more than about an eighth of all slots.
- The adjustments the planner made (moves and dropped pieces), as a short secondary list.

## Slot IDs

`W{week, two digits}-{channel code}-{n}`, for example `W05-BLOG-1`. Codes: BLOG, LI, NL, WEB, VID. The ID is how Claude's titles get matched back to slots, so keep IDs stable while filling.

## Filling slots with titles

- One working title and a one-sentence angle per slot.
- Match the pillar, channel and goal. LinkedIn titles read as hooks, newsletter titles as subject lines, and video titles as what the viewer will see.
- Teasers don't name the product. Follow-ups assume it shipped.
- Repurpose slots say what they're built from.
- No two slots in the same pillar repeat an idea.
- Never invent numbers, customers or quotes. Use `[placeholder: …]`.
