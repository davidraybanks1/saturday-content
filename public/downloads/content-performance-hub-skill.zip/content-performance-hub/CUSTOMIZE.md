# Content Performance Hub — setup and customization guide

The hub is a private dashboard that Claude builds on your data. It tells you which content earns conversions, which content creates pipeline, which high-traffic pages leak, and what to do next. You can rebuild or change it any time by asking Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Your page data in one of these:
  - **Works live:** Databricks, BigQuery (including the GA4 export), Snowflake, Postgres or Redshift, through a connector you've added in Claude.
  - **Works with limits:** Google Analytics 4 without a warehouse (no journeys; see `references/adapters/ga4-data-api.md`).
  - **Works by export:** Amplitude, Mixpanel, Segment, or any spreadsheet, as a CSV.
- A list of the pages you want to track.

## 1. Install the skill

Add the `content-performance-hub` folder (or the .zip) as a skill in Claude. Check that it shows up in your skills list.

## 2. Add your data connector

In Claude, add the connector for your warehouse and sign in. Run one test question ("list the tables in my analytics dataset") to confirm Claude can reach it. CSV users can skip this.

## 3. Fill in your setup

Two ways:

- **Easiest:** open the demo hub, click **Connect your data**, pick your tools, describe your content program, and copy the build prompt it generates.
- **By hand:** fill in `config.template.md`.

You'll need:

| Input | Example |
|---|---|
| Pages to track | `guides/onboarding = Guide: Onboarding` (no domain, no leading slash) |
| Primary conversion | Sign-up, counted within 7 days |
| Activation (optional) | First project created |
| High-intent action | Demo request — started on `demo`, finished on `demo/thank-you` |
| Launch date | When the content program went live |
| Minimum sample | 100 sessions before a page can be called "best" |

## 4. Ask Claude to build it

Paste your build prompt in a new chat. Claude will:

1. Look at your table and propose how your columns map to the hub's columns. **Check this table carefully** — it's the step that decides whether the numbers are right.
2. Run a coverage check and tell you about any page with no data (usually a slug typo).
3. Build and publish the hub as a private page.
4. Tell you which pages are still "Too early" and which tabs switched off for missing columns.

The first time you open the hub, Claude asks you to allow it to use your connector. Allow it.

## 5. Read the hub

Start with **Overview**: the executive summary has three columns (what's working, what's not, what to do), and the scorecard gives every page a verdict.

| Verdict | Meaning | Typical action |
|---|---|---|
| Fix | Top-two traffic, under 2% conversion | Rework the first screen; add a next step |
| Double down | Top-two conversion rate | More distribution, more internal links |
| Sales driver | Top-two high-intent rate | Add an in-page demo prompt; tell sales |
| Activation surface | Leads on activation, often reached mid-session | Build a direct entry point |
| Optimize | Normal | Iterate |
| Too early | Under your minimum sample | Wait |

Recent days under-report conversions (by up to your conversion window). Judge the last week with care.

---

## Customizing

Ask Claude in plain words; it knows where each setting lives. Common asks:

| You want | Ask Claude |
|---|---|
| Add or remove pages | "Add `/guides/pricing-page` as 'Guide: Pricing' to my hub and republish." |
| Rename conversions | "Call conversions 'Trials' and the intent action 'Contact sales'." |
| Change what 'Fix' means | "Mark a page Fix when it's in the top three by traffic and under 1.5%." |
| A different default range | "Open the hub on the last 90 days." |
| Your brand colors | "Use our colors: primary #0B5FFF, accent #FF7A00." |
| A new breakdown | "Add a tab that shows performance by author." (needs an author column) |
| Hide a tab | "Remove the Journeys tab." |
| Share with your team | Use the hub's Share menu. Each teammate needs the same connector and access to the data. |

### Rebranding the hub

All colors and fonts are tokens at the top of the `<style>` block in `templates/hub.html`: one light set on `:root` and a matching dark set (the hub follows each viewer's light/dark setting). Ask Claude: "Rebrand the hub with our colors and fonts" and give it your hex codes and Google Fonts names, or a link to your site's CSS. Fonts must come from Google Fonts or be embedded in the file.

The strip above the hub and the footer come from `CONFIG.brand` and `CONFIG.footer`. Put your own company name there, or set them to `null` / `""` to remove them.

### If you edit the file yourself

Everything lives at the top of the script in `templates/hub.html`:

- `CONFIG` — site name, goal, pages, labels, minimum sample, default range.
- `SOURCE` — data source settings. Don't change these by hand unless you've read the adapter file for your source.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| A page shows 0 sessions | Slug doesn't match your data (slash, prefix, case) | Ask Claude to run the coverage check |
| "Add the … connector" message | Connector missing for the viewer | Add it in Claude's connector settings |
| "Reconnect …" message | Sign-in expired | Reconnect the connector |
| Journeys tab missing | No view order/timestamp column mapped | Map a timestamp to `view_order` |
| Numbers differ from your BI tool | Different session or conversion definitions | Compare definitions in `references/metric-definitions.md` |
| Slow or partial load | Very long range or huge site | Use a shorter range, or ask Claude to pre-filter in SQL |

---

## How the numbers work (short version)

- A page's sessions are sessions that viewed it at least once.
- A session converts if it has the conversion anywhere in the session (within your window).
- Single-page = didn't convert and saw only one page. Recirculated = everything else.
- A page gets credit for a demo request only if the demo page comes **after** it in the same session.
- Every rate is a ratio of summed counts. Percentages are never averaged.

Full definitions: `references/metric-definitions.md`.
