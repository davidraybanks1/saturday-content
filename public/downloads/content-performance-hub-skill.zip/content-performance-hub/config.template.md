# Hub configuration

Fill this in (or paste the build prompt from the hub's "Connect your data" panel) and give it to Claude along with the skill.

```yaml
site: Acme                     # shown in the hub title
goal: Which content converts, and which front door leaks.
launch_date: 2026-07-01        # first day the content program was live
min_sample: 100                # sessions before a page can be ranked "best"

data_source: BigQuery          # Databricks | BigQuery | BigQuery GA4 export | Snowflake |
                               # Postgres | Redshift | GA4 Data API | CSV
table: analytics.page_views    # table or view (skip for GA4 Data API / CSV)
connector: BigQuery            # connector display name in Claude, if different

pages:                         # slug (no leading slash) = display name
  - guides/onboarding-checklist = Guide: Onboarding checklist
  - templates/content-brief = Template: Content brief
  - compare/acme-vs-spreadsheets = Compare: Spreadsheets
  - reports/state-of-ops-2026 = Report: State of ops 2026

conversion:
  label: Sign-up
  window_days: 7               # conversions counted within N days of the visit
  definition: event_name = 'sign_up'   # how to tell a converted session in your data

activation:                    # optional; delete the block if you don't track one
  label: First project created
  definition: event_name = 'project_created'

intent:
  label: Demo request
  reached: [demo]              # page(s) that mean "started the high-intent action"
  completed: [demo/thank-you]  # page(s) that mean "finished it"
```

## Where to find each value

| Field | Typical source |
|---|---|
| Pages | Your content calendar or CMS export. Use the path without domain, query string or slashes at either end. |
| Conversion definition | The event or flag your growth team already reports as sign-ups. Use the same window they use. |
| Activation | The first "aha" product event. Leave it out if your analytics doesn't connect web sessions to product usage. |
| Intent pages | Your demo, contact-sales, or pricing-consult form page and its confirmation page. |
| Min sample | 100 is a sensible default. Lower it to 50 for small sites; raise it to 300+ for high-traffic sites. |
