# Adapter: Snowflake

**Connection:** a Snowflake connector or MCP server in Claude that runs SQL. Some return rows directly; some return a statement handle to poll. Read the tool schemas and run `SELECT 1 AS X` first.

Snowflake upper-cases unquoted identifiers. Alias with double quotes so the page gets lowercase keys: `sess_id AS "session_id"`.

```js
sql: ({ start, end, pages }) => `
WITH views AS (
  SELECT
    session_id               AS "session_id",
    visitor_id               AS "visitor_id",
    TO_CHAR(event_date, 'YYYY-MM-DD') AS "event_date",
    page_slug                AS "page",
    DATE_PART(epoch_millisecond, event_ts) AS "view_order",
    channel_type             AS "channel_type",
    channel                  AS "channel",
    campaign                 AS "campaign",
    device_type              AS "device",
    visitor_type             AS "visitor_type",
    active_seconds           AS "seconds_on_page",
    is_bounce                AS "bounced",
    has_signup_7d            AS "converted",
    has_activation_7d        AS "activated"
  FROM <db>.<schema>.<page_view_table>
  WHERE event_date BETWEEN '${start}' AND '${end}'
),
touched AS (SELECT DISTINCT "session_id" FROM views WHERE "page" IN (${pages.map(p => `'${p.replace(/'/g, "''")}'`).join(",")}))
SELECT v.* FROM views v JOIN touched t ON v."session_id" = t."session_id"
LIMIT 250000`
```

If results come back with upper-case keys anyway, lower-case them in `readRun`:

```js
readRun: p => ({ done: true, id: null, rows: rowsFrom(p).map(r => Object.fromEntries(Object.entries(r).map(([k, v]) => [k.toLowerCase(), v]))) }),
```
