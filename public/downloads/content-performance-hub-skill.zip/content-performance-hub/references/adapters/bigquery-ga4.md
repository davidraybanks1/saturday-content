# Adapter: BigQuery (including the GA4 export)

**Connection:** a BigQuery connector or MCP server in Claude that runs SQL. Most return rows directly, so `pollTool` is usually `""`. Read the tool's input schema for the argument names (often `query` and a project ID).

```js
server: "<connector display name>",
runTool: "<query tool>",
pollTool: "",
buildRunInput: sql => ({ /* e.g. query: sql, projectId: "<project>" */ }),
readRun: p => ({ done: true, rows: rowsFrom(p), id: null }),
```

Confirm the payload shape with `SELECT 1 AS x` first.

## A. Your own modeled page-view table

Use the Databricks SQL shape with BigQuery functions: `FORMAT_DATE('%F', event_date)`, `UNIX_MILLIS(event_ts)`, backtick table names.

## B. GA4 BigQuery export (`events_*`)

This builds the canonical rows straight from raw GA4 events. Replace `<project>.<dataset>`, the sign-up event, and the activation event. Treat it as a starting point; verify counts against the GA4 UI for one week before trusting it.

```js
sql: ({ start, end, pages }) => {
  const s = start.replace(/-/g, ""), e = end.replace(/-/g, "");
  const list = pages.map(p => `'${p.replace(/'/g, "\\'")}'`).join(",");
  return `
WITH ev AS (
  SELECT
    CONCAT(user_pseudo_id, '.', CAST((SELECT value.int_value FROM UNNEST(event_params) WHERE key = 'ga_session_id') AS STRING)) AS session_id,
    user_pseudo_id AS visitor_id,
    PARSE_DATE('%Y%m%d', event_date) AS d,
    event_name, event_timestamp,
    REGEXP_REPLACE(REGEXP_REPLACE((SELECT value.string_value FROM UNNEST(event_params) WHERE key = 'page_location'), r'^https?://[^/]+|[?#].*$', ''), r'^/+|/+$', '') AS page,
    (SELECT value.int_value FROM UNNEST(event_params) WHERE key = 'engagement_time_msec') AS eng_ms,
    session_traffic_source_last_click.manual_campaign.medium   AS medium,
    session_traffic_source_last_click.manual_campaign.source   AS source,
    session_traffic_source_last_click.manual_campaign.campaign_name AS campaign,
    device.category AS device
  FROM \`<project>.<dataset>.events_*\`
  WHERE _TABLE_SUFFIX BETWEEN '${s}' AND FORMAT_DATE('%Y%m%d', DATE_ADD(PARSE_DATE('%Y%m%d','${e}'), INTERVAL 7 DAY))
),
sess AS (
  SELECT session_id,
    LOGICAL_OR(event_name = '<sign_up_event>')    AS converted,
    LOGICAL_OR(event_name = '<activation_event>') AS activated,
    ARRAY_AGG(STRUCT(medium, source, campaign, device) ORDER BY event_timestamp LIMIT 1)[OFFSET(0)] AS ft
  FROM ev GROUP BY session_id
),
views AS (
  SELECT session_id, ANY_VALUE(visitor_id) AS visitor_id, MIN(d) AS d, page, event_timestamp AS view_order
  FROM ev WHERE event_name = 'page_view' AND d BETWEEN '${start}' AND '${end}'
  GROUP BY session_id, page, event_timestamp
),
touched AS (SELECT DISTINCT session_id FROM views WHERE IF(page = '', 'home', page) IN (${list}))
SELECT
  v.session_id, v.visitor_id, FORMAT_DATE('%F', v.d) AS event_date, IF(v.page = '', 'home', v.page) AS page, v.view_order,
  CASE
    WHEN REGEXP_CONTAINS(LOWER(s.ft.medium), r'cpc|ppc|paid') AND REGEXP_CONTAINS(LOWER(s.ft.source), r'facebook|linkedin|instagram|twitter|x\\.com|reddit|tiktok') THEN 'Paid social'
    WHEN REGEXP_CONTAINS(LOWER(s.ft.medium), r'cpc|ppc|paid') THEN 'Paid search'
    WHEN s.ft.medium = 'organic' THEN 'Organic search'
    WHEN s.ft.medium IN ('social', 'social-network') THEN 'Organic social'
    WHEN s.ft.medium = 'email' THEN 'Email'
    WHEN s.ft.medium = 'referral' THEN 'Referral'
    WHEN s.ft.source = '(direct)' OR s.ft.medium IN ('(none)', '(not set)') THEN 'Direct'
    ELSE 'Other' END AS channel_type,
  CONCAT(IFNULL(s.ft.source, '(direct)'), ' / ', IFNULL(s.ft.medium, '(none)')) AS channel,
  s.ft.campaign AS campaign,
  s.ft.device AS device,
  s.converted, s.activated
FROM views v JOIN touched USING (session_id) JOIN sess s USING (session_id)
LIMIT 250000`;
}
```

Notes:
- The suffix range runs 7 days past `end` so conversions inside the window are found. Match it to `conversion.windowDays`.
- GA4 engagement time sits on later events, not the page_view, so `seconds_on_page` is left out here. Add it by summing `engagement_time_msec` between consecutive page views if the buyer wants time on page.
- `visitor_type`: add `(SELECT value.int_value FROM UNNEST(event_params) WHERE key = 'ga_session_number') > 1` on the first event if wanted.
- Older exports lack `session_traffic_source_last_click`; use `traffic_source.medium/source/name` (first user touch) instead and say so.

## Coverage check

```sql
SELECT page, COUNT(*) views, MIN(d) first_seen FROM (<views CTE over the last 180 days>) WHERE page IN (<slugs>) GROUP BY page
```
