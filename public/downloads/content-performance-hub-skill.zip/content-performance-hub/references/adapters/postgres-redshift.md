# Adapter: Postgres or Redshift

**Connection:** a Postgres-compatible connector or MCP server in Claude with a read-only query tool. These normally return rows directly (`pollTool: ""`). Read the tool schema; the argument is usually `sql` or `query`.

```js
sql: ({ start, end, pages }) => `
WITH views AS (
  SELECT
    session_id::text                         AS session_id,
    visitor_id::text                         AS visitor_id,
    TO_CHAR(event_date, 'YYYY-MM-DD')        AS event_date,
    page_slug                                AS page,
    EXTRACT(EPOCH FROM event_ts) * 1000      AS view_order,
    channel_type, channel, campaign,
    device_type                              AS device,
    visitor_type,
    active_seconds                           AS seconds_on_page,
    is_bounce                                AS bounced,
    has_signup_7d                            AS converted,
    has_activation_7d                        AS activated
  FROM <schema>.<page_view_table>
  WHERE event_date BETWEEN '${start}' AND '${end}'
),
touched AS (SELECT DISTINCT session_id FROM views WHERE page IN (${pages.map(p => `'${p.replace(/'/g, "''")}'`).join(",")}))
SELECT v.* FROM views v JOIN touched t USING (session_id)
LIMIT 250000`
```

Redshift: replace `EXTRACT(EPOCH FROM event_ts) * 1000` with `DATEDIFF(ms, '1970-01-01', event_ts)` if needed.

Many Postgres connectors return numeric columns as strings. The page parses numbers and booleans (`true`, `t`, `1`, `yes`) itself, so no conversion is needed.
