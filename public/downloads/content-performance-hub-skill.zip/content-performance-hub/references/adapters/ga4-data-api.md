# Adapter: Google Analytics 4 Data API (no warehouse)

**Use only when the buyer has no BigQuery export.** The Data API returns aggregates, not sessions, so the hub runs in a reduced mode. Tell the buyer this before building and recommend turning on the free BigQuery export for next time.

## What works and what doesn't

| Works | Approximate or off |
|---|---|
| Sessions, views, conversions and rates per page | Journeys tab (off — no session paths) |
| Channel and device breakdowns | Sequential intent attribution (off — uses page-level key events instead) |
| Engagement time, bounce (via engagement rate) | Single-page / recirculated split (approximate) |
| Monthly trend, verdicts, recommendations | Unique reach across pages (summed, so it over-counts) |

## Approach

Query the report with dimensions `date, landingPagePlusQueryString or pagePath, sessionDefaultChannelGroup, sessionSource, deviceCategory, newVsReturning` and metrics `sessions, screenPageViews, keyEvents:<sign_up>, keyEvents:<activation>, userEngagementDuration, engagementRate` for the tracked paths.

Then expand each aggregate row into synthetic canonical rows in `readRun` (one row per session, with `session_id` generated as `page|date|channel|device|i`, `converted` true on `keyEvents` of those rows, no `view_order`). Because `view_order` is absent, the page switches off order-based features automatically and labels intent attribution as session-level.

Use the connector's own report tool; read its schema for dimension and metric names. Set `pollTool: ""`.

Keep the expansion under `SOURCE.maxRows`; if it would exceed it, shorten the default range.
