# Adapter: Databricks

**Connection:** a Databricks connector or MCP server in Claude that can run read-only SQL against a SQL warehouse. These usually expose one tool that submits a statement and one that polls it.

## Fill in SOURCE

1. Find the connector's tools in this session. Read the input schema of the submit tool and the poll tool. Use their exact argument names.
2. Set:

```js
server: "<connector display name>",
runTool: "<submit tool, e.g. execute_sql_read_only>",
pollTool: "<poll tool, e.g. poll_sql_result>",
buildRunInput: sql => ({ /* e.g. statement: sql, warehouse_id: "<id>" */ }),
readRun: p => ({ done: /SUCCEEDED/.test(p.status?.state || p.state || ""), rows: rowsFrom(p), id: p.statement_id || p.id }),
buildPollInput: id => ({ /* e.g. statement_id: id */ }),
readPoll: p => { const st = p.status?.state || p.state || "";
  return { done: st === "SUCCEEDED", failed: /FAILED|CANCELED|CLOSED/.test(st), rows: rowsFrom(p), error: p.status?.error?.message || "" }; },
```

3. Run one tiny statement (`SELECT 1 AS x`) through both tools to confirm the payload shape matches `readRun`/`readPoll`. `rowsFrom()` already understands `result.data_array` + `manifest.schema.columns`.

## SQL

```js
sql: ({ start, end, pages }) => `
WITH views AS (
  SELECT
    session_id                        AS session_id,
    visitor_id                        AS visitor_id,
    CAST(event_dt AS STRING)          AS event_date,
    page_slug                         AS page,
    UNIX_MILLIS(event_ts)             AS view_order,
    utm.channel_type                  AS channel_type,
    utm.channel                       AS channel,
    utm.campaign                      AS campaign,
    utm.is_paid                       AS is_paid,
    device_type                       AS device,
    visitor_type                      AS visitor_type,
    active_seconds                    AS seconds_on_page,
    is_bounce                         AS bounced,
    has_signup_7d                     AS converted,
    has_activation_7d                 AS activated
  FROM <catalog>.<schema>.<page_view_table>
  WHERE event_dt BETWEEN '${start}' AND '${end}'
    AND site = '<site value>'          -- remove if the table holds one site
),
touched AS (
  SELECT DISTINCT session_id FROM views
  WHERE page IN (${pages.map(p => `'${p.replace(/'/g, "''")}'`).join(",")})
)
SELECT v.* FROM views v JOIN touched t USING (session_id)
LIMIT 250000`
```

Replace every column on the left with the user's column from the agreed mapping. Struct fields use dot notation (`first_touch.channel`).

## Checks

```sql
-- coverage
SELECT page_slug, COUNT(*) AS views, MIN(event_dt) AS first_seen
FROM <table>
WHERE event_dt >= DATE_SUB(CURRENT_DATE(), 180) AND page_slug IN (<slugs>)
GROUP BY page_slug;
```

Slugs missing from the result have no data.
