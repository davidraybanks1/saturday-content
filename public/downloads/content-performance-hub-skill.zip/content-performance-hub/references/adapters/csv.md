# Adapter: CSV or spreadsheet export

No connector needed. The hub's "Connect your data" panel loads a CSV in the viewer's browser, auto-maps common column names, and lets the viewer fix the mapping before loading. The file never leaves their browser and is not saved with the page.

## Expected format

One row per page view. Header row required. Column names can be the canonical ones or any alias the panel recognizes (`ga_session_id`, `event_dt`, `page_path`, `signed_up`, `event_ts`, `user_pseudo_id`, `device_category`, …; the full list is in `FIELDS` in `templates/hub.html`).

```
session_id,event_date,page,converted,view_order,visitor_id,channel_type,channel,campaign,device
s1,2026-10-01,/guides/onboarding,false,1,v1,Organic search,Google organic,,desktop
s1,2026-10-01,/pricing,false,2,v1,Organic search,Google organic,,desktop
s2,2026-10-01,/templates/brief,true,1,v2,Email,Newsletter,weekly-digest,mobile
```

## Getting the file

- **GA4 BigQuery export:** run the SQL in `bigquery-ga4.md` in the BigQuery console and download the result.
- **Amplitude / Mixpanel / Segment:** export page-view events with session ID and timestamp; add the conversion flag per session.
- **Spreadsheet:** File → Download → CSV.

Files over ~50 MB get slow in the browser. Narrow the date range or the page set.

## Making CSV the default

If the buyer only ever uses CSV, publish the template with `SOURCE.mode = "demo"` and tell them to load their file from the Connect panel each session. Don't embed their rows in the page source.
