# Adapter: Amplitude, Mixpanel or Segment

These tools hold events, not page-view tables, and their Claude connectors (where they exist) are built for charts and cohorts, not row exports. Route them through a warehouse or CSV:

1. **Warehouse sync (best):** turn on the tool's native sync (Amplitude → Snowflake/BigQuery, Mixpanel → warehouse export, Segment → warehouse destination). Then use the matching warehouse adapter, with the page-view event as the source of rows.
2. **CSV export:** export page-view events for the date range, then load them in the Connect panel (`csv.md`).

## Mapping notes

| Canonical | Amplitude | Mixpanel | Segment |
|---|---|---|---|
| session_id | `session_id` | `$session_id` (or derive) | `context.session_id` / derive from `anonymous_id` + 30-min gap |
| visitor_id | `amplitude_id` / `device_id` | `distinct_id` | `anonymous_id` |
| page | `event_properties.page_path` | `$current_url` path | `context.page.path` |
| view_order | `event_time` | `time` | `timestamp` |
| converted | any sign-up event in the session (+ window) | same | same |
| channel / campaign | `utm_source`, `utm_campaign` user properties | `utm_*` | `context.campaign.*` |

If there is no session ID, derive one: same visitor, events less than 30 minutes apart.
