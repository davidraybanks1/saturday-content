# Metric definitions

Keep these exact. The hub, the verdicts and the recommendations all depend on them.

## Units

- **Session (for a page):** a session that viewed the page at least once in range. A session that touched three tracked pages counts once for each.
- **Views:** page-view rows for the page.
- **Landing:** sessions whose first view was this page.
- **Mid-session entry:** sessions that reached the page after viewing something else (`sessions − landing`).
- **Exit:** sessions whose last view was this page.

## Session outcomes (among sessions that touched the page)

| Outcome | Definition |
|---|---|
| Conversion (e.g. sign-up) | Session has `converted` true on any row. |
| Single-page | No conversion **and** the session viewed only one distinct page site-wide. |
| Recirculated | `sessions − conversions − single-page`. |
| Activation | Session has `activated` true on any row. |

## High-intent attribution (sequential)

A page gets credit for a high-intent action only when an intent page appears **after the page's first view in the same session**.

- **Reached:** any `intent.reached` or `intent.completed` page after the first view.
- **Completed:** any `intent.completed` page after the first view.

Without `view_order`, any intent page in the session counts, and the page says so.

## Rates

- Every rate is `sum(numerator) / sum(denominator)` over the rows in scope.
- **Never average percentages** across pages, days, devices or channels.
- Conversion rate on page tables = conversions / sessions that touched the page.
- Bounce = bounced views / views.
- Time = active seconds per view; median uses all views in range.

## Overview KPIs

| KPI | Definition |
|---|---|
| Unique reach | Distinct `visitor_id` across sessions that touched any tracked page (falls back to sessions). |
| Conversions | Distinct converting sessions that touched any tracked page. |
| Conversion rate | Converting sessions / sessions touching any tracked page. |
| Intent completions | Sessions touching any tracked page that include a completion page anywhere. |
| Change vs prior | Same metric over the equal-length window immediately before the range. Counts show % change; rates show percentage-point change. Prior value of 0 shows "pre-launch". |

## Conversion lag

Conversions are counted within the conversion window (default 7 days). The last N days of any range under-report; the header says so. Don't draw conclusions from the final week.
