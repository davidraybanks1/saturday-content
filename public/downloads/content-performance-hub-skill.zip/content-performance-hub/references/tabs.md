# Tabs

Tabs render lazily on first open. Results are cached in `D` and cleared whenever a filter changes. A tab with a `needs()` function is hidden when the data can't support it.

| Tab | Shows | Needs |
|---|---|---|
| Overview | Executive summary (working / not / recommendations), KPI cards with change vs prior window, content scorecard with verdict pills, monthly table, session-outcomes table | — |
| Performance | Sessions, landing, unique visitors, views, conversions, activations, intent completions and the three session→outcome rates per page; two bar charts; key insights | — |
| Traffic sources | Channel × conversion table, channel-group doughnut for a chosen page, campaign drill-down for a chosen channel | `channel` or `channel_type` |
| Journeys | Top 2–6 step paths (consecutive repeats collapsed), paths ending in an intent completion, paths that converted, came-from / went-to explorer | `view_order` |
| Engagement | Avg and median time, bounce, exit, returning, mobile share; conversion by visitor type | columns appear as available |
| Intent (named after `intent.label`) | Sequential attribution: reached and completed counts and rates per page, two bar charts, completions by channel | intent pages configured |
| Single page | Five KPI cards, a one-sentence story, a where-the-sessions-go bar, engagement cards, channel and device tables with grouped Conversions / Recirculation / Exits columns, device mix by channel, came-from / went-to | — |
| Recommendations | Five data-driven cards: rebalance paid spend on the highest-reach page, scale the best converter, give the top activation page an acquisition path, turn the top intent page into pipeline, fix the high-traffic front door | at least one page over `minSample` |

## Global controls

- Date range with Apply, Reload, and presets (Last 30 days, Last 90 days, Since launch, This month).
- Exclude-channels multi-select. Its options come from all loaded sessions regardless of the current exclusion, so the filter never hides its own options.
- Device select (All / Desktop / Mobile / Unknown).
- Range, exclusions, device, last tab and last selected page persist in browser storage when it's available; the page works without it.

## Adding a tab

```js
TABS.push({ id: "authors", name: "Authors", render: rAuthors, needs: () => HAS.author });
function rAuthors(el) {
  const { cur } = current();            // analyzed data for the current filters
  el.innerHTML = `<div class="card"><h2>By author</h2>…</div>`;
}
```

Add any new canonical column to `FIELDS` (with CSV aliases) and read it in `ingest()`. Keep the empty-state and small-sample helpers (`empty()`, `small()`).
