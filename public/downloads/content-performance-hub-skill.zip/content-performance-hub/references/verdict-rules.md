# Scorecard verdicts

Each tracked page gets one or more pills. Only pages with at least `minSample` sessions are eligible for any verdict except "Too early".

| Pill | Rule | What it means |
|---|---|---|
| **Too early** | Under `minSample` sessions | Not enough data. Excluded from every ranking and "best" claim. |
| **Fix** | In the top two by sessions **and** conversion rate under 2% | A high-traffic front door that leaks. |
| **Double down** | Top two by conversion rate | Content that converts. Give it more distribution. |
| **Sales driver** | Top two by intent-completion rate | Content that creates pipeline. |
| **Activation surface** | Highest activation rate, **or** more than 50% mid-session entry with activation rate above 0.5% | Content that turns visitors into active users, often reached from other pages. Needs an acquisition path of its own. |
| **Optimize** | None of the above | Normal performer. Iterate on it. |

Rankings ignore pages with a rate of exactly zero, so a "top two" never includes a page that has never converted.

## Changing the rules

The logic lives in `verdicts()` in `templates/hub.html`. When you change a threshold:

1. Edit the rule in `verdicts()`.
2. Update the legend under the scorecard (in `rOverview`) so the page explains itself.
3. Update this file.

Typical changes:
- Sites with high baseline conversion: raise the Fix threshold from 2% to the site median.
- Large page sets (20+ pages): use top three or top 15% instead of top two.
- No activation event: the Activation surface pill disappears on its own.
