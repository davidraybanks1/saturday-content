# Data contract

The hub reads **one row per page view**, for every session that touched at least one tracked page in the requested date range. Include all of that session's page views, not just the tracked ones: journeys, single-page detection and intent attribution need the whole session.

Column names below are what the page expects. Alias them in SQL (`AS session_id`) or map them in the CSV panel.

## Required

| Column | Type | Meaning |
|---|---|---|
| `session_id` | string | Unique per session. For GA4: `user_pseudo_id` + `ga_session_id`. |
| `event_date` | date or `YYYY-MM-DD` | Date of the visit. `YYYYMMDD` and timestamps are accepted. |
| `page` | string | Path or slug. Domain, query string and leading/trailing slashes are stripped automatically. |
| `converted` | boolean | True on every row of a session that produced the primary conversion within the window. Session-level. |

## Optional (each one unlocks features)

| Column | Type | Unlocks |
|---|---|---|
| `view_order` | number or timestamp | Journeys tab, landing and exit metrics, came-from / went-to, sequential intent attribution. **Strongly recommended.** |
| `visitor_id` | string | Unique reach and unique visitors. Without it, reach falls back to sessions. |
| `channel_type` | string | Channel group (Organic search, Paid social…). Traffic tab, channel mix doughnut, paid vs organic recommendation. |
| `channel` | string | Specific channel (Google Ads, Newsletter…). Channel exclusion filter, channel tables. First-touch is preferred. |
| `campaign` | string | Campaign drill-down. |
| `is_paid` | boolean | Kept for buyers who prefer an explicit flag; the page also treats any channel group containing "paid" as paid. |
| `device` | string | Device filter and device tables. Anything with "desk" → desktop; "mob", "tab", "phone" → mobile; else unknown. |
| `visitor_type` | string | "new" / "returning". Returning share and conversion by visitor type. |
| `seconds_on_page` | number | Active (engaged) seconds. Avg and median time. |
| `bounced` | boolean | Bounce rate. Recommended definition: under 10 seconds with no interaction. |
| `activated` | boolean | Activation metrics, cards, verdict and recommendation. Session-level, like `converted`. |

## Rules

- First-touch attributes (`channel_type`, `channel`, `campaign`, `device`, `visitor_type`, `visitor_id`) are read from the session's first row. Repeat them on every row to keep SQL simple.
- `converted` and `activated` count if **any** row in the session is true.
- Rows with no `session_id` or an unparseable date are dropped.
- The hub requests the selected range **plus the prior equal-length window**, for the change-vs-prior comparisons.

## Missing-field behavior

| Missing | What happens |
|---|---|
| `view_order` | Journeys tab hidden. Landing, exit, came-from/went-to hidden. Intent attribution counts any intent page in the session. |
| `channel` and `channel_type` | Traffic tab, channel filter and paid-spend recommendation hidden. |
| `device` | Device filter and device tables hidden. |
| `activated` | Activation columns, KPI, verdict and recommendation hidden. |
| `seconds_on_page`, `bounced`, `visitor_type` | Their columns drop out of Engagement. |

## Mapping proposal format

Show the user something like this before building:

| Hub column | Your column | Notes |
|---|---|---|
| session_id | `sess_id` | |
| event_date | `event_dt` | |
| page | `page_path` | strip `/blog` prefix? ask |
| converted | `has_signup_7d` | already session-level |
| view_order | `event_ts` | timestamp, fine |
| activated | — | not available: activation views will switch off |
