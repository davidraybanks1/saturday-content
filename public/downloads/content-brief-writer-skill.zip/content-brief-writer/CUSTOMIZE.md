# Content brief writer — setup and customization guide

The content brief writer turns a rough content request into a complete brief before a writer starts, and checks the briefs you already have. You can use it two ways:

- **Ask Claude in chat.** For example: "Write a brief for a blog post on why content reviews stall, for content leads," or "Check this brief," followed by the brief.
- **Share a brief writer page with your team.** Requesters fill in a short form and watch the brief and its completeness score build as they type, or paste a brief to see what's missing.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Optional: your current brief template, or two or three past briefs, so Claude can match your sections and headings.

## 1. Install the skill

Add the `content-brief-writer` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Set up your template

Start a new chat and say: **"Use the content-brief-writer skill to set up our brief template."** Attach your current template or a few past briefs if you have them.

- **If you have a template:** Claude maps it to the 11 standard sections, keeps your section names, and flags anything your template lacks.
- **If you don't:** Claude starts from the standard template and asks which sections you'd require, skip or add.

Check the summary table before you say yes. Both modes score briefs against it.

## 3. Publish your brief writer page (optional)

Say: **"Publish our brief writer page."** Claude puts your template, content types and company details into the page and publishes it as a private page. Share it from the page's Share menu.

The first time each teammate clicks the Claude button, Claude asks them to allow the page to use Claude. Each generation uses that teammate's own Claude usage.

## 4. Use it

| Mode | Use it to | You provide | Works without Claude |
|---|---|---|---|
| Write a brief | Turn a request into a full brief with open questions | Content type and a title; anything else you know | Live brief preview, completeness meter, milestone dates |
| Check a brief | Score a brief, list gaps, get questions for the requester | The brief, in any format | Heading scan with per-section status and questions |

In chat, if a request is thin, Claude asks the requester two or three short rounds of questions before writing.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Add a section | "Add a required Legal review section to our brief template." |
| Make a section optional | "Search intent is optional for everything except blog posts." |
| Add a content type | "Add sales one-pagers: 300 words, two-week lead time, not for search." |
| Change lead times | "Our first drafts are due 10 days before publish, not 9." |
| Match your old headings | "Our briefs say 'Why' instead of 'Objective'. Make the check recognize that." |
| Change the scoring | "Count a brief as ready at 80%, and make the CTA a hard stop." |
| Rebrand the page | "Use our colors and fonts on the page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/content-brief-writer.html`:

- **`CONFIG`:** company, about, voice, branding.
- **`BRIEF_TEMPLATE`:** your sections, what each holds, the question to ask when it's missing, and the headings the scan recognizes. See `references/brief-template.md`.
- **`SCORING`:** weights, verdict thresholds and hard-stop sections. See `references/completeness-rubric.md`.
- **`CONTENT_TYPES`:** formats, lengths, lead times and usual outlines.
- **`FUNNEL`, `CHANNELS`, `PERSONAS`:** the choices in the form.
- **`EXAMPLES`:** the worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| The heading scan marks a section missing that's there | Your brief uses a heading the scan doesn't know. Add it to that section's `aliases`, or ask Claude to. Claude's own check reads the content, not the headings. |
| A brief scores low because of search | Pick a content type in Check mode. Search intent is only required for types meant to rank. |
| Output invents a target, name or date | It shouldn't. The prompt tells Claude to use placeholders. Fill those fields in the form, or answer the open questions. |
| The Claude button stays disabled | Write mode needs a content type and a title. Check mode needs a pasted brief. |
