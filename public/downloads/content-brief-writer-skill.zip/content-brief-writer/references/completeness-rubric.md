# Completeness rubric

Use this to score any brief, whether you wrote it or someone pasted it in.

## Scoring each section

| Score | Label | Means |
|---|---|---|
| 2 | Complete | Passes the section's one-line test in `brief-template.md`. A writer could act on it without asking. |
| 1 | Thin | Present, but vague, partial or a placeholder ("TBD", "the usual reviewers", "drive awareness"). |
| 0 | Missing | Not there, or only a heading with nothing under it. |

## Weighting and the overall score

- Required sections count double. Optional sections count once.
- Search intent and keywords is required only for content meant to rank. Otherwise it's optional.
- **Overall score** = points earned ÷ points possible, as a percentage.

| Overall | Verdict | What to do |
|---|---|---|
| 85–100% | Ready to write | Send it to the writer. |
| 60–84% | Nearly there | Ask the requester the open questions before work starts. |
| Under 60% | Not ready | Book 15 minutes with the requester, or run the intake interview. |

**Hard stop:** if Objective, Audience or Key message scores 0, the verdict is "Not ready" whatever the percentage. A writer can work around a missing distribution plan, not a missing point.

## What thin looks like, by section

| Section | Thin | Complete |
|---|---|---|
| Overview | "Blog about reviews" | Type, working title, one-sentence summary, requester |
| Objective and success metric | "Drive awareness" | One goal, one metric, a check-in date |
| Audience | "Marketers" | Role, funnel stage, what they believe now |
| Key message | A topic ("approval workflows") | A claim the reader could disagree with |
| Angle and outline | "Cover best practices" | A specific take and section-by-section plan |
| Search intent | "Good for SEO" | Primary query, intent, secondary terms |
| Sources and proof | "Use our data" | Named sources, the SME, claims that need sign-off |
| Stakeholders | "The usual reviewers" | One name per role, review order, final approver |
| Distribution | "Promote it" | Channels with an owner each |
| Deadline | "End of month" | Publish date and milestone dates |
| CTA | "Learn more" with no link | One action, its link, a fallback |

## Output format for a check

1. **Score and verdict:** "72% · Nearly there"
2. **Section table:** section, score (0–2), one-line reason.
3. **Gaps:** the missing and thin sections, most important first. Objective, Audience and Key message come before everything else.
4. **Questions to ask the requester:** one question per gap, worded so they can answer in a sentence, with a suggested default where you can offer one. Group them by who can answer (requester, SME, approver).
5. **Quick fixes:** anything you can fix without asking (for example, a CTA that doesn't match the funnel stage).

Never fill a gap with a guess presented as fact. If you suggest a default, label it as a suggestion.
