# Example brief: Fieldbook

Fieldbook is a fictional content operations platform. Everything below, including the people, is invented to show what a finished brief looks like. It scores 100% on `completeness-rubric.md`.

---

# Content brief: Why content reviews stall, and the five brief fields that fix it

## Overview
- **Content type:** Blog post (1,200–1,500 words)
- **Working title:** Why content reviews stall, and the five brief fields that fix it
- **Summary:** A practical post for content leads that traces slow reviews back to thin briefs and shows the five fields that stop review from turning into a second kickoff.
- **Requester:** Priya Raman, content lead
- **Writer:** Sam Ortiz

## Objective and success metric
- **Goal:** Earn newsletter sign-ups from content leads who don't know Fieldbook yet.
- **Success metric:** Newsletter sign-ups from the post in its first 30 days.
- **Target:** [placeholder: last quarter's average sign-ups per blog post]
- **Check in:** January 4, 2027

## Audience
- **Persona:** Content lead (Head of Content, Content Marketing Manager, Managing Editor) at a B2B software company.
- **Funnel stage:** Middle of funnel. They know reviews are a problem and are looking for a better process.
- **What they believe now:** Reviews are slow because reviewers are busy. The fix is chasing people harder or adding a deadline.

## Key message and supporting points
**Key message:** Most review rounds are the brief being written late. Fix the brief and reviews get shorter.

1. Late reviews usually reopen questions the brief should have answered: who it's for, the one point, the next step.
2. Five required fields catch most of those questions before drafting starts.
3. A longer brief costs minutes. A late rewrite costs days.
4. Reviewers give better feedback when they can check the draft against an agreed brief.

## Angle and outline
**Angle:** Don't blame the reviewers. Show that review comments are mostly brief questions in disguise, and give the reader a test they can run on their own last five reviews.

1. **Hook:** the review that turned into a kickoff meeting. A short scenario every content lead will recognize.
2. **The pattern:** sort review comments into "the draft" and "the brief". Show how often it's the brief.
3. **The five fields:** reader and their current belief, the one message, proof, approver, CTA. One paragraph and one example each.
4. **Run it on your own work:** a five-minute audit of your last five review threads.
5. **What changes:** what the first review looks like when the brief is complete.
6. **Close and CTA.**

## Search intent and keywords
- **Primary query:** content review process [to check]
- **Intent:** Learn. They want a better process, not a tool yet.
- **Secondary terms:** content approval workflow, content brief template, how to speed up content reviews, too many review rounds
- **What ranks now:** [placeholder: top three results and what they miss]

## Sources and proof
- Fieldbook product docs: brief templates with required fields, approval steps with owners and due dates.
- Past post to link to: "The 20-minute brief" (Fieldbook blog).
- **SME:** Dana Kim, product manager for briefs and reviews. 30-minute interview on how teams set required fields.
- **Data:** [placeholder: any internal data on review rounds per asset, only if approved for publication]
- **Needs sign-off:** any number about review rounds or time saved.

## Stakeholders and approvals
| Role | Name | When |
|---|---|---|
| Requester | Priya Raman | Outline and final read |
| Writer | Sam Ortiz | Owns the draft |
| SME | Dana Kim | Interview, then fact check on the draft |
| Reviewer | Priya Raman | First draft |
| Final approver | Leo Brandt, head of marketing | Final draft |

## Distribution
- **Blog:** publish on the Fieldbook blog (Sam).
- **Newsletter:** lead story in the December newsletter (Priya).
- **LinkedIn:** company page post on publish day, plus two follow-up posts from the five fields (social team).
- **Repurpose:** the five-field audit as a one-page checklist for a later download.

## Deadline and milestones
| Milestone | Date |
|---|---|
| Outline approved | Thu Nov 19 |
| SME interview | Fri Nov 20 |
| First draft | Tue Nov 24 |
| SME and requester review | Fri Nov 27 |
| Final approval | Tue Dec 1 |
| Publish | Thu Dec 3, 2026 |

## CTA
- **Action:** Subscribe to the Fieldbook newsletter for one practical content-ops idea a week.
- **Link:** the newsletter sign-up page.
- **Fallback:** the brief template download, if the sign-up page changes.
