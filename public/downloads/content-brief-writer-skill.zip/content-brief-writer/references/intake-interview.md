# Intake interview

Use this when someone asks for content in chat ("we need a blog post about reviews") and there's no form or existing brief. The goal is a complete brief in two or three short rounds, not a questionnaire.

## How to run it

- **Start from what they gave you.** Fill every section you can from the request, then ask only about the gaps.
- **Ask three to five questions per round,** grouped and numbered so they can answer in one message.
- **Offer a default with each question** so "yes" is a valid answer. "Who's it for? I'm assuming content leads at B2B software companies."
- **Stop after three rounds.** Write the brief with what you have and list the rest under "Open questions".
- **Never fill a gap with an invented fact.** Use `[placeholder: …]`.

## Round 1: the piece and the point

Ask whichever of these the request didn't answer.

1. **What is it, and what's the working title?** (Content type and a rough title or topic.)
2. **What should it do for the business?** If they list several goals, ask which one wins.
3. **Who's reading, and what do they believe right now that we want to change?**
4. **What's the one thing they should believe after reading?**
5. **When does it need to be live, and is that date tied to anything?**

## Round 2: proof and people

6. **What can we use as proof?** Research, product facts, customer stories, data. Which of these can we name publicly?
7. **Who's the subject-matter expert, and how much time do they have?** (An interview, written answers, or a review only.)
8. **Who reviews it, in what order, and who signs off?** Then: "Anyone else who'll see it before it goes live?"
9. **What should the reader do next?** Offer the CTA that fits the funnel stage as the default.

## Round 3: reach (skip what doesn't apply)

10. **Should it rank in search?** If yes: the query you'd want it to win, and anything you know already ranks.
11. **Where will it go after it's published, and who posts it?**
12. **Anything it must avoid?** Competitor names, claims legal won't approve, topics sales is sensitive about.

## Signals that save a question

| If the request says… | Assume… |
|---|---|
| "blog", "guide", "SEO", "rank" | Search intent section is required; middle of funnel unless stated |
| "LinkedIn", "thought leadership", "awareness" | Top of funnel; search intent optional |
| "case study", "product page", "battlecard", "vs" | Bottom of funnel; sales enablement in distribution |
| "webinar", "event" | Fixed date; registration CTA; promo plan in distribution |
| A launch name or date | Deadline is fixed; product marketing is a reviewer |

## Closing the interview

When the rounds are done, write the full brief using `brief-template.md`, then:

1. Show the completeness score from `completeness-rubric.md`.
2. List open questions with the person who can answer each one.
3. Ask: "Anything wrong or missing before this goes to the writer?"
