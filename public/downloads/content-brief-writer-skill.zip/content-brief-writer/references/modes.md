# Modes

The skill has two modes. Both use the 11 sections in `brief-template.md` and the scoring in `completeness-rubric.md`.

## Write a brief

**Use for:** "write a brief", "brief this", "turn this request into a brief", "we need a post about…"

**Inputs (all optional except the content type and some idea of the topic):** content type, working title or idea, goal, persona, what the reader believes now, funnel stage, key message, angle, target search query, sources, requester, subject-matter expert, approver, deadline, CTA, distribution channels.

**If the inputs are thin,** run `intake-interview.md` before writing. If the user says "just write it", write it and put every gap under Open questions.

**Output**
1. `# Content brief: <working title>`
2. The 11 sections as H2 headings, in template order. Use short bullets and tables. A writer should be able to scan it in two minutes.
3. **Milestones:** work backwards from the publish date using the content type's lead times (outline, first draft, review, final approval), moved off weekends. If there's no date, write `[placeholder: publish date]` and skip the milestones.
4. `## Open questions`: each gap as a question, with who can answer it.
5. `## Completeness`: the overall score and verdict from the rubric.

**Rules**
- Use what the requester gave you word for word where it's specific. Tighten it where it's vague, and say so.
- Where you draft something they didn't give you (the angle, an outline, secondary search terms), mark it `(suggested)`.
- Where only the requester can know (names, dates, targets, approvals), write `[placeholder: what's needed]`.

## Check a brief

**Use for:** "check this brief", "is this brief ready", "what's missing", "review my brief"

**Input:** the brief, pasted or attached. Optionally the content type.

**Output:** follow "Output format for a check" in `completeness-rubric.md`: score and verdict, section table, gaps, questions to ask the requester, quick fixes.

**Rules**
- Score what's on the page, not what the requester probably meant.
- A section can be present under a different heading ("Goals" for Objective, "Reviewers" for Stakeholders). Score the content, not the heading.
- Word each question so the requester can answer in one sentence. Offer a default where you can, labeled as a suggestion.

## Rules for every mode

- **Evidence:** never invent statistics, customer names, people, quotes, search volumes or dates. Write `[placeholder: what's needed]` instead.
- **Voice:** plain, specific, active voice. Write in the house voice from the company config when there is one.
- **Formatting:** Markdown with clear headings. Start with the output, no preamble.
