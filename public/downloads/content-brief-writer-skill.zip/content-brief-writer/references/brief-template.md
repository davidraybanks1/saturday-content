# Brief template

Every brief has the same 11 sections, in this order. Nine are required for every piece. Two are required only in some cases. The page holds the same list in its `BRIEF_TEMPLATE` block, so if you change it here, change it there too.

| # | Section | Required | One-line test |
|---|---|---|---|
| 1 | Overview | Yes | Could someone who missed the kickoff say what this is in one breath? |
| 2 | Objective and success metric | Yes | Is there one goal and one number you'll check after it ships? |
| 3 | Audience | Yes | Is the reader a role with a current belief, not just a persona name? |
| 4 | Key message and supporting points | Yes | Is there exactly one thing the reader should believe afterwards? |
| 5 | Angle and outline | Yes | Is the take specific enough that a competitor couldn't publish the same piece? |
| 6 | Search intent and keywords | Only for search content | If it should rank, do we know the query and what the searcher wants? |
| 7 | Sources and proof | Yes | Does every claim the piece makes have a source the writer can reach? |
| 8 | Stakeholders and approvals | Yes | Does the writer know who reviews, in what order, and who has the final say? |
| 9 | Distribution | Recommended | Do we know where it goes after it's published, and who posts it? |
| 10 | Deadline and milestones | Yes | Is there a publish date and a date for each handoff before it? |
| 11 | CTA | Yes | Is there one next step that fits the funnel stage? |

---

## 1. Overview

**Contains:** content type, working title, a one- or two-sentence summary, the requester, and the writer if known.

**Good:** "Blog post. Working title: *Why content reviews stall, and the five brief fields that fix it.* A practical post for content leads on cutting review rounds by fixing the brief. Requested by Priya (content lead). Writer: Sam."

**Weak:** "Blog about reviews."

## 2. Objective and success metric

**Contains:** the business goal in one sentence, the metric that shows it worked, the target if one exists, and when you'll check it.

**Guidance:** one goal per piece. If the requester gives three goals, ask which one wins when they conflict. The metric should suit the funnel stage: engaged reading and sign-ups at the top, downloads and return visits in the middle, demo requests and sales use at the bottom. Don't invent a target. If none exists, write `[placeholder: target, e.g. last quarter's average for this format]`.

## 3. Audience

**Contains:** the persona (role and typical titles), the funnel stage, and **what they believe now**: the current assumption the piece has to move.

**Guidance:** "what they believe now" is the field most briefs skip and the one writers need most. It turns a topic into an argument. "Content leads think reviews are slow because reviewers are busy" gives the writer something to push against.

## 4. Key message and supporting points

**Contains:** one sentence the reader should believe after reading, then 3–5 supporting points that earn it.

**Guidance:** if the key message needs "and", it's two messages. Supporting points should each map to a section of the outline or a piece of proof.

## 5. Angle and outline

**Contains:** the angle (the specific take, in one or two sentences), then a section-by-section outline with a line on what each section does.

**Guidance:** the angle is what makes this piece different from the ten others on the topic. The outline follows the content type's usual shape (see the page's `CONTENT_TYPES` block) unless there's a reason to break it.

## 6. Search intent and keywords

**Required when:** the piece is meant to be found in search (most blog posts, guides and landing pages). Optional for social posts, webinars and sales content.

**Contains:** the primary query, the intent behind it (learn, compare, buy, do), 3–5 secondary terms or questions, and what currently ranks and what it misses.

**Guidance:** don't invent search volumes. If the requester hasn't done keyword research, write the likely query and mark it `[to check]`.

## 7. Sources and proof

**Contains:** links to research, product docs, data, customer stories and past content to build on; the subject-matter expert and what they'll provide; and any claim that needs legal or product sign-off.

**Guidance:** list proof the piece is allowed to use. If a claim has no source yet, list it as a gap, not as a fact.

## 8. Stakeholders and approvals

**Contains:** requester, writer, subject-matter expert, reviewers in order, and the final approver. One name per role.

**Guidance:** surprise stakeholders cause late rewrites. Ask "who else will see this before it goes live?" and write every answer down.

## 9. Distribution

**Contains:** channels, owner per channel, any paid support, and repurposing plans (for example, three LinkedIn posts from the blog).

**Guidance:** recommended for every piece. If the requester says "just the blog", write that down so nobody assumes more.

## 10. Deadline and milestones

**Contains:** publish date, plus dates for outline, first draft, SME review, final approval. Note any fixed date the piece is tied to (a launch, an event).

**Guidance:** work backwards from the publish date. The page suggests milestone dates from the content type's lead times, moved off weekends.

## 11. CTA

**Contains:** the one action the reader should take next, where it links, and a fallback if that page isn't ready.

**Guidance:** match the funnel stage. Top: read more, subscribe. Middle: download, register, see how it works. Bottom: trial, demo, talk to sales.
