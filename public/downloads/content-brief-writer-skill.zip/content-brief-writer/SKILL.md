---
name: content-brief-writer
description: Turn a rough content request into a complete content brief before a writer starts, or check an existing brief for missing sections and the questions to ask the requester. Also builds the team a published Content Brief Writer page with a live brief preview and completeness meter. Use for content briefs, brief templates, intake for content requests, or reviewing whether a brief is ready.
---

# Content brief writer

This skill writes and checks **content briefs** against one template: 11 sections, nine required for every piece, one required only for content meant to rank in search, and one recommended. Every brief gets a completeness score so the team can see whether it's ready before a writer starts.

It has two modes:

- **Write a brief:** turn a request (a form, a Slack message, a sentence in chat) into a complete brief, with open questions for anything only the requester can answer.
- **Check a brief:** score an existing brief per section, list the gaps, and give the questions to ask the requester.

It works two ways:

1. **In chat.** The user asks for a brief or pastes one; you write or check it using the files in `references/`.
2. **As a brief writer page.** You publish `templates/content-brief-writer.html` as a private artifact with the team's template and company details inside it. Teammates fill in a short form (with a live preview and completeness meter) or paste a brief (with a heading scan), and the page writes or checks with Claude on their own account.

## Files

| File | Read it when |
|---|---|
| `references/brief-template.md` | Writing or checking any brief; changing the template |
| `references/modes.md` | Running any Write or Check request |
| `references/intake-interview.md` | The request is thin and you need to ask the requester questions |
| `references/completeness-rubric.md` | Scoring any brief |
| `references/example-brief.md` | You need a model of a finished brief |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Pick the mode.** "Write", "brief this", "we need a post about…" → Write. "Check", "is this ready", "what's missing", or a pasted brief → Check.
2. **For Write, fill what you can first.** Pull every section you can from the request. If the objective, audience or key message is missing, run `intake-interview.md` (two or three short rounds, three to five questions each, with a default offered for each). If the user says "just write it", write it and list the gaps under Open questions.
3. **For Check, score what's on the page.** Match sections by content, not heading. Follow the output format in `completeness-rubric.md`.
4. **Work out milestones** backwards from the publish date with the content type's lead times (see `CONTENT_TYPES` in the page), moved off weekends.
5. **Keep it honest.** Never invent statistics, names, quotes, search volumes, targets or dates. Write `[placeholder: what's needed]`. Mark anything you drafted for them as `(suggested)`.

## Building the brief writer page for a team

1. **Agree the template.** Start from `brief-template.md`. Ask whether the team uses other section names, requires anything extra (legal review, accessibility, localization) or never uses a section. Show the final list as a table (section, required, one-line test) and get a yes.
2. **Copy `templates/content-brief-writer.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice`, `demoNote` (`""` for a real team), `brand` (their name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `BRIEF_TEMPLATE`: one entry per section with `required` (`true`, `false` or `"search"`), `guidance`, `good`, `ask`, `who` and `aliases` (the headings their old briefs use, so the Check scan recognizes them). If you add or remove a section, also update `formScores()` and `previewMd()` so the form maps to it.
   - `SCORING`: keep the defaults unless the team wants different thresholds or hard stops.
   - `CONTENT_TYPES`: the formats they brief, each with `search`, `length`, `lead` days and a usual `outline`.
   - `FUNNEL`, `CHANNELS`, `PERSONAS`: their stages, channels and persona names.
   - `EXAMPLES`: replace with a worked example for each mode from their own work, or keep the Fieldbook ones with `demoNote` set.
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the preview, meter and heading scan still work, and the page builds the prompt for the viewer to paste into Claude.
4. **Tell the user** that each teammate is asked once to allow the page to use Claude, that generation uses their own Claude usage, and that the template changes when they ask you to update it and republish.

## Keeping the template current

When the team's process changes ("legal now reviews every case study", "drop the search section for social"), update `brief-template.md` and the page's `BRIEF_TEMPLATE` together, and republish to the same artifact. Summarize what changed in one or two lines.
