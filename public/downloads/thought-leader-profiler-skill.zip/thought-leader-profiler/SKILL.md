---
name: thought-leader-profiler
description: Build a Narrative ID (podium, posture and pillars) for a subject-matter expert, then pitch topics, draft bylines in their voice, and prep interviews that pull out stories and strong opinions. Also builds the team a published Thought Leader Profiler page that works with Claude. Use for executive thought leadership, ghostwriting, SME interviews, or profiling an expert.
---

# Thought leader profiler

This skill works from a **Narrative ID**: a one-page profile of an expert built on three parts.

- **Podium:** what they're uniquely positioned to speak on, and why they're credible
- **Posture:** their point of view and how they show up (contrarian, practical, optimistic…)
- **Pillars:** the 3–4 themes they return to

It's rounded out by audience, signature stories, strong opinions, phrases they use and avoid, off-limits topics, and proof they can cite. There are four modes: Build a profile, Pitch topics, Draft a byline, and Prep an interview.

It works two ways:

1. **In chat.** The user asks for a profile, pitches, a draft or interview questions; you write them from the Narrative ID and the guides in `references/`.
2. **As a profiler page.** You publish `templates/thought-leader-profiler.html` as a private artifact with the team's experts inside it. Teammates pick a mode and an expert, and the page writes with Claude on their own account.

## Files

| File | Read it when |
|---|---|
| `references/narrative-id.md` | Any request. The framework, with a test for each part. |
| `references/narrative-id-schema.md` | Writing or editing a profile for the page |
| `references/profiling-interview.md` | Building a profile from scratch, or the user has no notes |
| `references/modes.md` | Running any of the four modes |
| `references/voice-matching.md` | Drafting any byline |
| `references/example-experts.json` | You need a model of finished profiles |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Find the expert's Narrative ID.** Look in this conversation, the project's files, or a connected doc. If there isn't one, offer to build one (from notes they paste, or by running the interview in short rounds). For a quick request, a few lines about the person is enough to start; say what you assumed.
2. **Resolve the mode** from the verb: profile/notes/transcript → Build; ideas/topics/pitch → Pitch; write/draft/ghostwrite → Draft; questions/interview/prep → Interview.
3. **Pull the inputs:** expert, topic or hook, format, and any pillar to lean on. Leave unclear picks open rather than asking, and say what you assumed in one line.
4. **Write**, following `modes.md` for the output structure and `voice-matching.md` for drafts.
5. **Keep it honest.** Use only the profile, the notes and the user's context as evidence. Never invent statistics, credentials, customers or quotes; write `[placeholder: what's needed]` instead. Stay off every off-limits topic.

## Building the profiler page for a team

1. **Build a Narrative ID for each expert** (2–6 is typical). Show each back as a compact summary (podium in one line, posture traits, pillar names) and get a yes before publishing. Ask the expert, through the user, whether the podium and pillars sound like them.
2. **Copy `templates/thought-leader-profiler.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice` (house style, used as a floor under each expert's own voice), `demoNote` (`""` for a real team), `brand` (their company name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `EXPERTS`: the team's profiles, following `narrative-id-schema.md`.
   - `FORMATS`: keep LinkedIn post, op-ed and blog post, or add formats the team uses (a newsletter, a conference abstract) with their own `play`.
   - `SAMPLE_NOTES` and `EXAMPLES`: replace with notes and worked examples from their experts, or delete the entries (the Example tab then hides for that mode, and the Load sample button can be removed).
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the page builds the prompt for the viewer to paste into Claude. The interview question set and the profiles view work either way.
4. **Tell the user** that each teammate is asked once to allow the page to use Claude, that generation uses their own Claude usage, and that profiles change when they ask you to update them and republish.

## Keeping profiles current

When something changes ("Maren's stepping back from the AI debate", "add our new CFO"), update the entry, keep the schema, and republish the page to the same artifact. A profile built in the page's Build mode can be added by pasting its output into chat and asking you to add it. Summarize what changed in one or two lines.
