# Thought leader profiler — setup and customization guide

The thought leader profiler builds a Narrative ID for each of your experts (their podium, posture and pillars), then pitches topics, drafts bylines in their voice and preps interviews. You can use it two ways:

- **Ask Claude in chat.** For example: "Pitch eight LinkedIn topics for our CEO around planning season."
- **Share a profiler page with your team.** People pick a mode and an expert, and the page writes with Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Something about each expert: interview notes, a call transcript, past posts or talks, or 30 minutes with them.

## 1. Install the skill

Add the `thought-leader-profiler` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Build your experts' Narrative IDs

Start a new chat and say: **"Use the thought-leader-profiler skill to build a Narrative ID for [name]."** Then attach whatever you have.

- **If you have notes or a transcript:** Claude drafts the profile from them, keeps the expert's own wording, and marks anything it had to guess.
- **If you have nothing yet:** ask for the profiling interview. Claude gives you a question set grouped by podium, posture and pillars, or interviews the expert directly if they're in the chat.

Send each expert their podium, posture and pillars and ask, "Does this sound like you?" Their edits make every later draft better.

## 3. Publish your profiler page (optional)

Say: **"Publish our thought leader profiler page with these experts."** Claude puts your profiles and house voice into the page and publishes it as a private page. Share it from the page's Share menu.

The first time each teammate clicks Generate, Claude asks them to allow the page to use Claude. Each generation uses that teammate's own Claude usage.

## 4. Use it

| Mode | Use it to | You provide |
|---|---|---|
| Build a profile | Turn notes into a Narrative ID | Interview answers, notes or a transcript |
| Pitch topics | Get 8 pitches with angle, hook, format and pillar | An expert, and optionally a timely hook |
| Draft a byline | Get a LinkedIn post, op-ed or blog post in their voice | An expert, a topic and a format |
| Prep an interview | Get 12 questions that pull a story and a strong opinion | An expert, and optionally a topic |

The **Expert profiles** tab shows every Narrative ID with podium, posture and pillars side by side. The interview question set builds from the expert's pillars right in the page, even without Claude, and you can copy or print it.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Add an expert | "Add our CFO. Here are my notes from our call: …" |
| Update a profile | "Theo no longer runs the newsletter. Update his podium and pillars and republish." |
| Add a format | "Add a newsletter issue and a conference abstract as byline formats." |
| Change the posture scales | "Use 'Data-led ↔ Story-led' instead of 'Big picture ↔ In the weeds'." |
| Change the house voice | "Our house voice is warmer and less formal. Here's a post we like: …" |
| Rebrand the page | "Use our colors and fonts on the profiler page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/thought-leader-profiler.html`:

- **`CONFIG`:** company, about, house voice, branding.
- **`EXPERTS`:** your Narrative IDs. See `references/narrative-id-schema.md`.
- **`FORMATS`:** the byline playbooks.
- **`SAMPLE_NOTES` and `EXAMPLES`:** the sample interview notes and the worked examples shown when Claude isn't connected. Replace them with your own, or delete them.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| Drafts invent numbers, customers or credentials | Add the real facts to the expert's `proof` field. The profiler is told never to invent evidence, and uses placeholders instead. |
| Drafts don't sound like the expert | Add more phrases they use and avoid, sharpen their posture summary, and paste a writing sample into Add context. |
| Generate stays disabled | Build a profile needs notes in step 1; Draft a byline needs a topic. |
| A draft touches a sensitive subject | Add it to the expert's `offLimits` list and republish. |
