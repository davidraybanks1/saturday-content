# Voice matching for bylines

A byline works when the expert reads it and thinks "I'd say that." The Narrative ID gives you the raw material. This is how to use it.

## Before drafting

1. **Read the posture first.** It sets the stance of the whole piece. A contrarian expert opens with what's wrong; an optimistic one opens with what's possible; a craft-minded one opens with a specific detail.
2. **Pick one story or one opinion**, not both, unless the format is an op-ed. Only use it if it fits the topic.
3. **Check off-limits** before choosing examples.
4. **Read any writing samples** the user provides. Copy sentence length and rhythm, not words.

## While drafting

| Do | Don't |
|---|---|
| Write in the first person | Write as the company ("we at Fieldbook are excited…") |
| Use one or two of their phrases, where they'd fit naturally | Stack their catchphrases into every paragraph |
| Match their sentence length. Short and blunt if blunt; longer if reflective. | Default to one generic LinkedIn cadence |
| Use concrete details from their stories | Invent new details, numbers or quotes to make a story better |
| State the opinion at the strength they'd state it | Soften a contrarian into "it depends" or sharpen a measured voice into a hot take |
| Leave `[placeholder: …]` where a number or name is needed | Fill gaps with plausible-sounding facts |
| End the way they'd end a conversation | End with "What do you think? Let me know in the comments" unless that's how they talk |

## Posture cues

| Posture | Opening move | Typical structure | Watch for |
|---|---|---|---|
| Contrarian | Name the common belief, then reject it | Claim → why it's wrong → what to do instead | Don't be contrarian about everything |
| Practical | A specific situation or problem | Problem → steps → result | Don't skip the "why" entirely |
| Optimistic | What's possible, or a team that got it right | Example → pattern → how to start | Don't gloss over what's hard |
| Skeptical | A question the reader hasn't asked | Question → evidence → a careful conclusion | Don't end without a point |
| Craft-minded | A small, precise detail | Detail → principle → example | Don't drift into navel-gazing |
| Evidence-first | What they've seen across many cases | Pattern → examples → implication | Don't name customers without permission |

## Formats

### LinkedIn post
150–250 words. Hook in the first two lines. One idea, one story or example, one takeaway. Short paragraphs. A question or light prompt at the end. Three hashtags at most.

### Op-ed
700–900 words. Headline states the argument. Open with a scene or a sharp claim. Thesis by paragraph three. Three supporting points with a story or proof each. Name and answer the strongest counterargument. Close with what the reader should do. Suggest a one-line author bio.

### Blog post
900–1,300 words. Search-friendly H1. Intro names the problem in 2–3 sentences. 4–5 H2 sections with at least one framework or checklist. The expert's story in the first half. Short conclusion, one call to action. Suggest a meta description.

## After drafting

Add a short "Notes for [first name]" section:
- which story or opinion you used
- every placeholder they need to fill
- one line you'd like them to check sounds like them

## The read-aloud test

Read the draft aloud in the expert's voice. Any sentence you stumble on, or that they wouldn't say in a meeting, gets rewritten.
