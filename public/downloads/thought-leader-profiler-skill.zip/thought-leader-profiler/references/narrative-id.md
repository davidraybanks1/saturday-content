# The Narrative ID

A Narrative ID is a one-page profile of a subject-matter expert. It answers three questions before anyone writes a word under their name:

1. **Podium:** what can this person speak on that others can't, and why should anyone listen?
2. **Posture:** what do they believe, and how do they come across when they say it?
3. **Pillars:** what 3–4 themes do they keep coming back to?

Everything else in the profile (audience, stories, opinions, phrases, off-limits topics, proof) supports those three.

## Podium

The podium is the narrow ground where this expert is the most credible person in the room. It is not their job title.

- **Write it as one sentence** that names the vantage point: "The operator who ran a content agency for eight years and built the product because the spreadsheets broke."
- **Back it with 2–4 credentials** the expert can say out loud: roles held, things built, things seen at scale. No adjectives.
- **Add one line on why it matters:** why this vantage point gives them something others don't have.

A good podium is narrow. "Marketing leader" is not a podium. "The person who has onboarded every customer content team we have" is.

**Test:** could someone else at the company give the same talk with the same authority? If yes, the podium is too wide.

## Posture

Posture is the point of view and the way they carry it. Two experts on the same podium can have opposite postures.

- **2–3 trait words**, the first being the dominant one. Common ones: contrarian, practical, optimistic, skeptical, craft-minded, evidence-first, provocative, generous, candid, wry.
- **A 2–3 sentence description** of how they show up: what they push against, what they lead with, how they sound.
- **Optional scales** (0–100) to place them between two poles, for example optimistic ↔ skeptical, big picture ↔ in the weeds, measured ↔ provocative. These help writers calibrate tone fast.

**Test:** read one of their strong opinions aloud. Does the posture predict how they'd say it?

## Pillars

Pillars are the 3–4 recurring themes that everything they publish should ladder up to.

- **Name each in a few words**, ideally as a claim rather than a category: "The brief is the strategy", not "Briefs".
- **One sentence each** on what the pillar covers.
- **3–4, never more.** Five pillars is a content calendar, not a narrative.
- **At least one pillar should be ownable**, meaning it follows from their podium and nobody else at the company would naturally say it.

**Test:** take their last five posts or talks. Each should map to a pillar. If two don't, either the pillars are wrong or the expert has been off-message.

## Rounding it out

| Field | What it holds | Why it matters |
|---|---|---|
| Audience | Who they're talking to, by role and situation | Sets the stakes and vocabulary |
| Signature stories | 2–3 true stories they tell well, one or two sentences each | Stories are what readers remember and what makes a byline sound like a person |
| Strong opinions | 3–4 claims a reasonable reader could disagree with | These become hooks and headlines |
| Phrases they use | Words and lines that sound like them | Voice matching |
| Phrases they avoid | Words they'd never say | Stops a ghostwriter from making them sound corporate |
| Off-limits | Topics, names and numbers they won't discuss publicly | Guardrails for every draft |
| Proof they can cite | Facts they're allowed to say, with numbers only if approved | The only evidence a draft may use |
| Where they publish | Their channels | Shapes formats in pitches |

## How the parts work together

- **Pitching:** the podium decides whether they're the right person for a topic; pillars decide whether it fits; opinions and stories supply the hook.
- **Drafting:** posture sets the stance, phrases set the texture, stories and proof supply the substance, off-limits sets the edges.
- **Interviewing:** questions are grouped by podium, posture and pillars, so each answer fills a gap in the profile or produces material for a piece.

## Keeping it current

Revisit a Narrative ID every quarter or after any big change (a new role, a launch, a public stance). Add stories as they happen. Retire pillars the expert no longer cares about. Opinions date fastest; check them first.
