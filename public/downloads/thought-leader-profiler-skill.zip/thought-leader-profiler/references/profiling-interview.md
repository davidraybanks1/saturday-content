# The profiling interview

Use this to build a Narrative ID from scratch. It takes 30–45 minutes, live or on a call. If the expert would rather write answers, send one group at a time.

**Before the call:** read anything they've already published or said publicly. Note phrases that repeat. Don't ask questions their LinkedIn already answers.

**During the call:** record it if they agree. Ask for moments, not summaries ("tell me about a time", not "how do you think about"). When they say something sharp, ask them to say it again in one sentence; that's usually a strong opinion.

## Podium: what they can speak on, and why

1. What do you know about your field that most people in your seat don't?
2. What have you done, built or seen that gives you that view? Be as specific as you can.
3. What do people come to you for, inside the company and out?
4. If you gave a talk tomorrow with no prep, what would it be about?
5. Who should not be listening to you on this? *(Shows where the podium ends.)*

## Posture: what they believe, and how they show up

6. What's the advice in your field you'd push back on?
7. Finish this: "Most people think ___, but actually ___."
8. Where have you changed your mind in the last few years?
9. When you disagree with someone in a meeting, how do you usually say it?
10. Three words a colleague would use to describe how you communicate?
11. What tone do you hate seeing in your industry's content?

## Pillars: the themes they come back to

12. What topics could you talk about every month for a year without running out?
13. What problem do you keep seeing that nobody seems to fix?
14. What do you wish your audience understood that they don't?
15. Tell me about a time it went wrong. What did you change afterward?
16. Tell me about a time it went right. What made the difference?

## Round it out

17. **Audience:** Who do you most want to reach? Describe one specific person.
18. **Stories:** What story do you find yourself telling over and over?
19. **Phrases:** Are there words you use a lot? Any you can't stand?
20. **Off-limits:** What won't you talk about publicly: clients, numbers, competitors, anything personal?
21. **Proof:** What numbers or facts can you cite? Which need approval first?

## After the call

1. Draft the Narrative ID within a day, while the conversation is fresh.
2. Quote the expert's own words for opinions, phrases and stories wherever you can.
3. Mark anything inferred with "(inferred)".
4. List gaps (a missing story, an unconfirmed number) as questions for the next conversation.
5. Send the expert the Podium, Posture and Pillars only, and ask: "Does this sound like you?" Their edits are the most useful data you'll get.

## If you only have 10 minutes

Ask 1, 6, 7, 12, 18 and 20. That's enough for a first draft of the Narrative ID.
