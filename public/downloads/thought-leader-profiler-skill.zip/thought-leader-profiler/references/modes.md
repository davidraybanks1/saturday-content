# Modes

Every request is one of four modes. Pitch, Draft and Interview need an expert with a Narrative ID. All four accept optional extra context.

## Build a profile

**Use for:** "profile", "build a Narrative ID", "here are my interview notes", "turn this transcript into…"

**Needs:** interview answers, call notes, a transcript or past writing. If there's nothing, run the interview in `profiling-interview.md`.

**Output**
1. Title line: name and role
2. **Podium:** one-sentence statement, then 2–4 credibility bullets
3. **Posture:** 2–3 trait words and a 2–3 sentence description
4. **Pillars:** 3–4, each a short name and one sentence
5. Audience
6. Signature stories (2–3)
7. Strong opinions (3–4, in their words where possible)
8. Voice: phrases they use, phrases they avoid
9. Off-limits
10. Proof they can cite
11. Gaps to fill in the next conversation

**Rules:** keep the expert's wording wherever the notes quote them. Mark anything inferred with "(inferred)". Never fill a gap with an invented credential or number.

## Pitch topics

**Use for:** "what should [expert] write about", "pitch topics", "ideas for [expert]'s LinkedIn"

**Inputs:** expert; optional timely hook; optional pillar to lean on.

**Output**
1. Summary table: #, working title, pillar, format (LinkedIn post, op-ed, blog post, talk or podcast)
2. For each of 8 pitches: the angle in one sentence, the hook (why now), why this expert (tie to the podium), and the story, opinion or proof to use
3. **Strongest three**, with a one-line reason each
4. **Skip:** one tempting topic that doesn't fit their podium, and why

**Rules:** spread pitches across pillars (at least three pillars when none is chosen). Every pitch must pass the podium test: could someone else say this with the same authority? If yes, cut it.

## Draft a byline

**Use for:** "write a LinkedIn post for [expert]", "draft an op-ed", "ghostwrite"

**Inputs:** expert; topic; format (LinkedIn post, op-ed or blog post); optional pillar.

**Output:** the draft, then "Notes for [first name]". Follow `voice-matching.md`.

## Prep an interview

**Use for:** "interview questions for [expert]", "prep me for a call with…", "what should I ask…"

**Inputs:** expert; optional topic; optional pillar.

**Output**
1. One line: what we're after (one story and one opinion we can publish)
2. 12 questions, grouped:
   - Podium (3): why them, what they've seen
   - Posture (3): what they believe and push back on
   - Pillars (4): one per pillar where possible, each asking for a specific moment
   - Close (2): the one line to remember; what not to print or what to check
3. For each question: what it pulls (story, opinion or proof) and a follow-up probe for the key ones
4. **Watch for:** off-limits topics and claims that need checking

**Rules:** open questions only. Ask for moments, not summaries. Don't put words in their mouth.

The page builds a version of this question set without Claude, from the expert's pillars. Claude's version tailors each question to the topic and the expert's known stories.

## Rules for every mode

- **Evidence:** never invent statistics, names, customers, quotes or credentials. Use only the profile, the notes or the user's context. Write `[placeholder: what's needed]` instead.
- **Off-limits:** never touch an off-limits topic, even to say it's off-limits.
- **Voice:** the expert's posture and phrases first, the company's house voice as a floor.
- **Formatting:** Markdown with clear headings. Start with the output itself, with no preamble.
