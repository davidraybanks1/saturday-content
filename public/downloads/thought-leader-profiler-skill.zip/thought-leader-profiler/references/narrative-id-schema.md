# Narrative ID schema

The page keeps one entry per expert in its `EXPERTS` block. `example-experts.json` holds three finished entries.

```json
{
  "id": "maren",
  "name": "Maren Okafor",
  "initials": "MO",
  "role": "Co-founder and CEO",
  "blurb": "Content is an operations problem",
  "podium": {
    "statement": "One sentence naming the vantage point.",
    "credentials": ["2–4 things they've done, built or seen"],
    "why": "One line on why this vantage point matters."
  },
  "posture": {
    "traits": ["Dominant trait", "Second", "Third"],
    "summary": "2–3 sentences on how they show up.",
    "scales": [
      { "l": "Optimistic", "r": "Skeptical", "v": 65 },
      { "l": "Big picture", "r": "In the weeds", "v": 70 },
      { "l": "Measured", "r": "Provocative", "v": 75 }
    ]
  },
  "pillars": [{ "name": "Short claim", "summary": "One sentence." }],
  "audience": "Who they speak to, by role and situation.",
  "stories": [{ "title": "Short name", "body": "One or two sentences." }],
  "opinions": ["A claim a reasonable reader could disagree with."],
  "phrases": { "use": ["..."], "avoid": ["..."] },
  "offLimits": ["..."],
  "proof": ["Facts they may cite. Use [placeholder: …] for numbers not yet approved."],
  "channels": "Where they publish."
}
```

## Field guidance

| Field | Required | Notes |
|---|---|---|
| `id` | yes | lowercase, unique |
| `name`, `role` | yes | As they'd appear in a byline |
| `initials` | yes | 2–3 characters, shown on the picker card |
| `blurb` | yes | Under 45 characters. Usually their main pillar or posture in a phrase. |
| `podium.statement` | yes | The single most important field |
| `podium.credentials` | yes | 2–4. Facts, not adjectives. |
| `podium.why` | recommended | |
| `posture.traits` | yes | 2–3. First one is the dominant trait and shows as a tag on the profile. |
| `posture.summary` | yes | |
| `posture.scales` | optional | `v` runs 0 (left word) to 100 (right word). Keep the same three scales across experts so they're comparable. |
| `pillars` | yes | 3–4 |
| `stories` | recommended | 2–3. Only true stories the expert has told or approved. |
| `opinions` | recommended | 3–4, in their words where possible |
| `phrases.use` / `phrases.avoid` | recommended | 3–6 each |
| `offLimits` | strongly recommended | Anything legal, competitive or personal |
| `proof` | strongly recommended | The only evidence drafts may use |
| `channels` | optional | |

## Quality bar

- A writer who reads only this entry should be able to draft a LinkedIn post that the expert would sign with light edits.
- Keep each entry to about 400 words.
- Never put confidential figures, customer names without permission, or unreleased plans in a profile that will be shared beyond the team.
