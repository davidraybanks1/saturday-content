# Audience profile builder — setup and customization guide

The audience profile builder turns customer research into audience profiles your content team can write from. Each profile comes with short quotes from the research that back every pain and objection. You can use it two ways:

- **Ask Claude in chat.** For example: "Build an audience profile from these call notes."
- **Share a builder page with your team.** People paste research, see it tagged on the evidence board, and generate profiles, comparisons and gap reports with Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Some research: sales call notes, review site exports, open-text survey answers, support tickets, or interview transcripts. Twenty lines is enough to start. Fifty or more from three kinds of source is better.

## 1. Install the skill

Add the `audience-profile-builder` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Build your first profile

Start a new chat and say: **"Use the audience-profile-builder skill to build a profile for our [role] buyers."** Then paste or attach the research.

Claude codes each line into the profile fields, writes the profile, lists the quotes behind each pain and objection, and says which parts are strong and which rest on one mention. Anything the research doesn't support is left as `[placeholder: …]` for you to fill.

No research to hand? Say **"Show me with the sample research."**

## 3. Compare segments or find the gaps

| Mode | Use it to | You provide |
|---|---|---|
| Build a profile | Get one library-ready profile with evidence | One research set |
| Compare segments | See what differs and what to say differently | Two research sets, one per group |
| Find the gaps | Learn what you don't know yet and what to ask | One research set |

## 4. Publish your builder page (optional)

Say: **"Publish our audience profile builder page."** Claude sets your company and voice in the page and publishes it as a private page. Share it from the page's Share menu.

The first time each teammate clicks Generate, Claude asks them to allow the page to use Claude. Each generation uses that teammate's own Claude usage. The evidence board and the prompt builder work without Claude.

## 5. Send profiles to the content studio

Click **Copy as studio library entry** under a profile, or ask Claude for "the library entry." The JSON matches the B2B content studio's library. Replace every placeholder, then ask Claude to add it to your studio and republish.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Tag your competitors | "Add Contentstack, Asana and Monday as tools on the evidence board." |
| Use your own sample research | "Replace the sample research on the page with this anonymized set." |
| Change the profile fields | "Add a 'buying trigger' field to our profiles." Note: the studio won't use fields it doesn't know. |
| Write for industries, not roles | "Build a vertical profile for healthcare from these notes." |
| Rebrand the page | "Use our colors and fonts on the builder page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/audience-profile-builder.html`:

- **`CONFIG`:** company, about, house voice, branding.
- **`SAMPLE_RESEARCH`:** the research preloaded on first open.
- **`TAG_RULES`:** the keywords the evidence board tags lines with. End a keyword with `*` to match word endings.
- **`SOURCES` and `USES`:** the option cards.
- **`EXAMPLES`:** worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| A quote shows "Not in research" | Claude reworded it. Remove it from the entry, or click Try another version. |
| Too many lines are untagged | Add your customers' words to `TAG_RULES`. The board is a first pass; Claude reads every line either way. |
| "The research is too long" | Split it by source, build a profile from each, then ask Claude to merge them. |
| The profile is full of placeholders | The research doesn't cover those fields. Run Find the gaps and use the questions it writes. |
