# Research synthesis method

How to turn raw research into profile fields. Work in this order; don't write the profile until the research is coded.

## 1. Split and label

- Break the research into one point per line. A long call note becomes several lines.
- Label each line with its source: the kind (call, review, survey, ticket, interview) and the role if known ("Discovery call 2 · Managing Editor, fintech").
- Count sources, not lines. Ten lines from one call is one source.

## 2. Code each line

Give each line one or more codes. These map onto profile fields.

| Code | Look for | Goes to |
|---|---|---|
| **Pain** | Something going wrong now: chasing, waiting, redoing, can't answer, too many | `pains`, `emphasize` |
| **Objection** | A reason not to buy or switch: price, migration, another tool, security, adoption | `objections` |
| **Goal** | What they're trying to achieve: double output, prove impact, one place for… | `goal`, `value` |
| **Tool** | A product, competitor or workaround they use today | `avoid` (don't attack it), compare-mode tables |
| **Metric** | How they're measured, or a number they gave | `metrics`, `proof` |
| **Language** | A phrase worth keeping word for word | `pains`, `tone` |
| **Role** | Title, team size, who signs | `titles` |
| **Outcome** | A result a customer attributed to the product | `proof` |

The page's evidence board does a rough version of this with keyword rules. Treat its tags as a starting point; code from meaning, not keywords.

## 3. Cluster

- Group lines with the same code that describe the same thing ("chasing approvals" and "reviewers miss due dates" are one pain).
- Name each cluster in the customer's words, not yours.
- Count independent sources per cluster.

## 4. Weigh

| Sources agreeing | Call it | How to use it |
|---|---|---|
| 3 or more, of 2+ kinds | Pattern | Lead with it |
| 2 | Signal | Use it, say it's thin |
| 1 | Anecdote | Note it under gaps; don't lead with it |

Weigh source types differently:
- **Calls and interviews** show context and reasoning, but notes are filtered through the note-taker.
- **Reviews and tickets** have the customer's exact words, but skew toward strong feelings.
- **Survey answers** show how common something is, but are short.

## 5. Write the fields

- Write `pains` from the strongest clusters, in their words.
- Write `objections` as they'd say them. Only fill `r` from the research (an answer that worked on a call, a review that resolves it). Otherwise `[placeholder: …]`.
- Write `goal`, `emphasize` and `value` last. They are synthesis; say they're inferred.
- Pick evidence: 1–3 shortest verbatim snippets per pain and objection.

## 6. Check

- Every quote appears in the input, exactly.
- No number, name or outcome appears that isn't in the input.
- Every field that the research doesn't support says so.

## Comparing two segments

Code both sets the same way, then compare cluster by cluster. Before you call something a difference, check:
- Is it missing from one set because nobody asked? (Different source mix.)
- Is one set much smaller? Say so.
- Is it the same pain in different words? Then it's shared ground.
