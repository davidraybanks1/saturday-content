# Interview question bank

Use these to close gaps a profile has. Ask about past behaviour, not hypotheticals ("what did you do" beats "would you"). Pick 6–10 per interview; don't ask them all.

## Opening (context and role)
1. Walk me through your role. What does a normal week look like?
2. Who's on your team, and who do you report to?
3. What are you measured on this year?

## Pains
4. What's the most frustrating part of [the job the product does] right now?
5. Tell me about the last time that went wrong. What happened?
6. What have you tried to fix it?
7. How much time does it cost you in a week? How do you know?

## Trigger and goals
8. What made you start looking for something new? What happened that week?
9. If this worked perfectly, what would be different in six months?
10. Who else cares whether this gets fixed?

## Buying process and objections
11. Who else had to say yes? What did they need to see?
12. What else did you look at, and why didn't you pick it?
13. What almost stopped you?
14. What would have made the decision easier?

## Language and proof
15. How would you describe [the product] to a peer?
16. What would you tell another [role] before they start?
17. If it disappeared tomorrow, what would you go back to?
18. May we quote you? With your name and title, or only your role?

## Tips
- Record and transcribe if you can. Notes lose the exact words.
- Ask "tell me about the last time" for anything that matters. Specific stories beat opinions.
- Keep a source label at the top of each set of notes: "# Interview 4 · Head of Content, fintech". The page uses lines starting with # as source labels.
