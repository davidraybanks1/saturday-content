# Sample research set: Fieldbook

Invented research for Fieldbook, the fictional content operations platform used in the demo. Every call, review, survey answer and ticket below is made up. Use it to try the skill, or as a model for how to lay out your own research.

**Format:** one point per line. A line starting with `#` names the source of the lines under it (kind, then role and company type). The builder page and the evidence board read this format.

## Segment A: Content lead

```text
# Discovery call 1 · Head of Content, 60-person software company
Team of four writers plus two freelancers. Briefs live in Google Docs, the calendar lives in Airtable.
"Every review turns into a rewrite because nobody agreed on the angle up front."
She spends Monday mornings chasing approvals in Slack.
Asked whether Fieldbook replaces Asana. Worried about running two tools.
Goal for the year: double output without hiring.
Leadership wants to know which content drives pipeline and she can't answer it.
# Discovery call 2 · Managing Editor, fintech company
Legal review adds about two weeks to every piece.
"We published the same comparison post twice last year and nobody noticed for a month."
Concerned about migration: 400 posts in the old CMS.
Price came up early: "We can't add another seat-based tool this year."
Wants a single place where freelancers see the brief and the feedback.
# Discovery call 3 · Content Marketing Manager, HR software company
Tried Notion for the calendar and gave up after a quarter because nobody kept it updated.
Biggest pain is vague briefs from product marketing.
Measured on organic sign-ups and content-influenced pipeline.
Asked if Fieldbook writes the content. Relieved when we said no.
# Reviews
"Finally one place for briefs and reviews. Our approval time went from 9 days to 4." (Head of Content)
"The calendar is great but setup took longer than we expected." (Content Ops Lead)
"Reporting is the weakest part. I still export to a spreadsheet for the monthly deck." (Content Director)
"My writers stopped asking me where the latest brief is." (Managing Editor)
# Survey · What's the hardest part of running content?
Getting stakeholders to review on time.
Knowing what we already have so we don't duplicate it.
Proving content's impact to the CFO.
Too many tools: Docs, Sheets, Slack, Asana and the CMS.
Onboarding freelancers takes too long because the context is scattered.
# Survey · What would make you switch tools?
If it connected to HubSpot so I could see which posts lead to demos.
If the team would actually use it without me nagging them.
Not worth it unless it saves at least 5 hours a week.
# Support tickets
Can approvers get reminders automatically? We keep missing due dates.
How do I import our existing calendar from Airtable?
```

## Segment B: Marketing ops

```text
# Discovery call 1 · Marketing Operations Manager, 300-person software company
Every team tracks content in its own spreadsheet.
"I spend the last week of every quarter stitching spreadsheets together."
First question was about permissions: who can edit templates and fields.
"If it doesn't sync with Salesforce, it's a non-starter."
Worried about yet another tool to administer.
# Discovery call 2 · Director of Marketing Operations, logistics software company
Security review is required for any new tool and takes six weeks.
Wants required fields so every asset has a campaign and a persona.
Measured on data completeness and reporting turnaround.
"I don't care about the calendar. I care that the data is clean."
# Reviews
"Custom fields are flexible, but the API docs are thin." (Marketing Ops Lead)
"We retired three spreadsheets and a shared drive in the first month." (Marketing Systems Manager)
# Survey · What's the hardest part of your job?
Reconciling content data across HubSpot, the CMS and Sheets.
Enforcing naming conventions across six teams.
Getting attribution numbers that sales actually trusts.
# Support tickets
Can we restrict who edits the brief template? Writers keep deleting fields.
Export to CSV drops custom fields.
```

## Expected result

Building a profile from Segment A should give something close to the library entry below. Every evidence quote appears word for word in Segment A. Placeholders mark what the research doesn't say.

```json
{
  "id": "content-lead",
  "dimension": "persona",
  "name": "Content lead",
  "icon": "target",
  "blurb": "Ship more without more chasing",
  "titles": "Head of Content, Managing Editor, Content Marketing Manager",
  "goal": "Fieldbook is where briefs, reviews and the content record live, so the team ships more without more people and the lead can show what content drives.",
  "tone": "Peer to peer. A fellow editor who has spent Monday mornings chasing approvals.",
  "pains": "Reviews turn into rewrites because the angle was never agreed. Approvals get chased by hand in Slack. Work gets duplicated because nobody knows what exists. Freelancer context is scattered. Leadership asks what drives pipeline and there's no answer.",
  "emphasize": "Briefs that settle the angle before drafting; review reminders and owners; a library that stops duplicate work; one place for freelancers; per-asset performance.",
  "avoid": "Don't position it as an Asana replacement. Don't imply it writes the content. Don't promise reporting that replaces their CRM.",
  "proof": "Review quote: approval time went from 9 days to 4 [placeholder: permission to cite]. Review quote: writers stopped asking where the latest brief is.",
  "objections": [
    {
      "o": "We already use Asana. Do we need two tools?",
      "r": "Keep Asana for company projects. Fieldbook covers what it doesn't: briefs, review rounds and the content library."
    },
    {
      "o": "We can't add another seat-based tool this year.",
      "r": "[placeholder: pricing answer from sales]"
    },
    {
      "o": "Migrating 400 posts sounds painful.",
      "r": "[placeholder: import path and time from the product team]"
    },
    {
      "o": "My team won't keep it updated.",
      "r": "Start with briefs and reviews, where the team saves time first. [placeholder: adoption proof]"
    }
  ],
  "value": "More content shipped by the same team, with fewer rewrites and a straight answer on impact.",
  "metrics": "Output per writer; organic sign-ups; content-influenced pipeline",
  "evidence": [
    {
      "supports": "pain",
      "quote": "Every review turns into a rewrite because nobody agreed on the angle up front."
    },
    {
      "supports": "pain",
      "quote": "spends Monday mornings chasing approvals in Slack"
    },
    {
      "supports": "pain",
      "quote": "We published the same comparison post twice last year and nobody noticed for a month."
    },
    {
      "supports": "pain",
      "quote": "Onboarding freelancers takes too long because the context is scattered."
    },
    {
      "supports": "pain",
      "quote": "Leadership wants to know which content drives pipeline and she can't answer it."
    },
    {
      "supports": "objection",
      "quote": "Asked whether Fieldbook replaces Asana. Worried about running two tools."
    },
    {
      "supports": "objection",
      "quote": "We can't add another seat-based tool this year."
    },
    {
      "supports": "objection",
      "quote": "Concerned about migration: 400 posts in the old CMS."
    },
    {
      "supports": "objection",
      "quote": "If the team would actually use it without me nagging them."
    }
  ]
}
```
