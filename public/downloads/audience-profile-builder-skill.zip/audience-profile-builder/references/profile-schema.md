# Profile schema

A profile is one entry in the B2B content studio's messaging library, plus an `evidence` list. The keys match the studio's `references/library-schema.md` exactly (in the `b2b-content-studio` skill), so a profile can be pasted straight into a studio page's `LIBRARY` block. If the two ever disagree, the studio's schema wins.

```json
{
  "id": "content-lead",
  "dimension": "persona",
  "name": "Content lead",
  "icon": "target",
  "blurb": "Ship more without more chasing",
  "titles": "Head of Content, Managing Editor",
  "goal": "What this audience should come to believe about the product. One or two sentences.",
  "tone": "How to sound for this audience.",
  "pains": "What's going wrong for them today, in their words.",
  "emphasize": "The 3–5 themes to lead with.",
  "avoid": "Positioning, words or claims to stay away from.",
  "proof": "Real capabilities, data or customer facts the writer may cite.",
  "objections": [{ "o": "The objection, as they'd say it.", "r": "The answer." }],
  "value": "The outcome to land, in one sentence.",
  "metrics": "How this audience is measured.",
  "evidence": [{ "supports": "pain", "quote": "A short snippet copied exactly from the research." }]
}
```

## Field guidance

| Field | Required | Where it comes from in research |
|---|---|---|
| `id` | yes | Lowercase-hyphenated from the name |
| `dimension` | yes | `persona` for a role, `vertical` for an industry |
| `name`, `blurb` | yes | Blurb under 40 characters. Write it from the top pain or goal. |
| `icon` | no | One of: target, megaphone, rocket, gear, pen, building, code, pulse, chart, factory, briefcase, cap |
| `titles` | optional | Job titles named in call headers, review bylines, survey demographics |
| `goal` | yes | Your synthesis: what they need to believe, given their pains and goals. Mark it as inferred. |
| `tone` | optional | How they talk: formal or casual, technical or not, what they're tired of hearing |
| `pains` | yes | Lines coded as pains. Keep their words. |
| `emphasize` | optional | The pains and goals that came up most, turned into themes |
| `avoid` | recommended | Words or claims they reacted badly to; things they said the product isn't |
| `proof` | recommended | Only outcomes customers stated (review quotes, numbers they gave). Mark anything that needs permission to cite. |
| `objections` | recommended | Lines coded as objections, as they'd say them. `r` is a placeholder unless the research shows an answer that worked. |
| `value` | optional | The outcome they'd recognize, in one sentence |
| `metrics` | optional | Lines coded as metrics: what they're measured on |
| `evidence` | this skill | 1–3 snippets per pain and per objection. See below. |

## Evidence

- `supports` is `pain` or `objection`. Add `goal` or `metric` if the user wants more.
- `quote` is copied character for character from the input. Trim to the shortest snippet that still makes the point (usually under 25 words). Don't fix typos.
- Don't include customer names or company names unless the user says they can be shared.
- The page checks each quote against the pasted research and flags any that don't match.

## Quality bar

- A writer who reads only this entry should know what to say and what not to.
- The whole entry, without evidence, should fit in about 250 words.
- Every `[placeholder: …]` must be replaced before the entry goes into a published studio.
