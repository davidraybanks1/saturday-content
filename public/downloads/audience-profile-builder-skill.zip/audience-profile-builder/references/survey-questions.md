# Survey question bank

Surveys show how common something is. Keep them short (5–8 questions) and include at least two open-text questions, because those give you the customer's words.

## Role and context
| Question | Answer type |
|---|---|
| What's your role? | Single choice, with "other" |
| How many people are on your team? | Single choice: 1, 2–5, 6–15, 16+ |
| Who approves new tools for your team? | Single choice: me, my manager, a VP, procurement |

## Pains
| Question | Answer type |
|---|---|
| What's the hardest part of [the job]? | Open text |
| How many hours a week do you spend on [the pain]? | Number |
| Rank these problems from most to least painful. | Ranking (4–6 items from your research) |

## Trigger and alternatives
| Question | Answer type |
|---|---|
| What made you start looking for a new way to do this? | Open text |
| Which tools have you used or compared? | Multi-select, with "other" |
| What would make you switch tools? | Open text |

## Measurement
| Question | Answer type |
|---|---|
| How is your work measured? | Multi-select, with "other" |
| How do you report on it today? | Single choice |

## Permission
| Question | Answer type |
|---|---|
| May we quote your answers in our marketing? | Yes or no, with name and title fields |

## Tips
- Put each open-text answer on its own line when you paste results into the builder, with a `# Survey · [question]` line above each question's answers.
- Don't lead. "How frustrating is X?" assumes it is. Ask "How do you feel about X?" or ask them to rank.
- 30 answers is enough to see patterns in open text.
