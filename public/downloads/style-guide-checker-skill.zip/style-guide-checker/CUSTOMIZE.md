# Style guide checker — setup and customization guide

The style guide checker edits drafts against your team's own style guide. Every edit cites the rule it applies, so writers learn the guide as they go. You can use it two ways:

- **Ask Claude in chat.** For example: "Check this blog post against our style guide."
- **Share a checker page with your team.** People paste a draft, see an instant quick check, and get full line edits from Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- Your style guide in any form: a doc, a wiki page, a PDF, a list of pet peeves, or a few edited drafts. If you have nothing written down, Claude can interview you.

## 1. Install the skill

Add the `style-guide-checker` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Import your style guide

Start a new chat and say: **"Use the style-guide-checker skill to import our style guide."** Then paste or attach it.

- **If you have a guide:** Claude splits it into numbered rules (V1, G4, A1…), gives each a severity, and pulls out a word list of terms to use and avoid. It marks anything it had to infer, such as a missing "don't" example.
- **If you have no guide:** Claude asks a few short rounds of questions and drafts one.

Check the summary table before you say yes. Every edit the checker makes cites one of these rules.

## 3. Publish your checker page (optional)

Say: **"Publish our style guide checker page."** Claude puts your rules, word list and a sample draft into the page and publishes it as a private page. Share it from the page's Share menu.

The quick check runs in the browser and needs no Claude usage. The first time a teammate asks Claude for a full check, Claude asks them to allow the page to use Claude. Each check uses that teammate's own Claude usage.

## 4. Check, rewrite or explain

| Mode | Use it to | You get |
|---|---|---|
| Check a draft | Review a draft before it goes out | A summary, line edits with rule IDs and severity, and a revised version |
| Rewrite to style | Clean up a draft fast | The revised version and a change list grouped by rule |
| Explain a rule | Settle a question or onboard a writer | The why, do and don't examples, and edge cases |

On Check and Rewrite you can narrow the pass to one category (for example, only accessibility) or one severity level (for example, only must-fix issues).

### What the quick check catches

Without Claude, the page flags avoid-list words, exclamation points, Title Case headings, sentences over 30 words, likely passive voice, "click here" link text, number style breaks, em dashes and double spaces. Each flag shows its rule ID, and a count by rule sits above the highlights. Claude checks every rule, including the ones that need judgment.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Add or change a rule | "Add a rule: we always write percent as %. Make it a should." |
| Grow the word list | "Add 'leverage', 'robust' and 'holistic' to the avoid list." |
| Change severity | "Make the sentence case rule a must." |
| Change the sentence limit | "Flag sentences over 25 words instead of 30." |
| Keep brand names capitalized | "Add our product names to the heading check's proper nouns." |
| Rebrand the page | "Use our colors and fonts on the checker page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/style-guide-checker.html`:

- **`CONFIG`:** company, about, voice, proper nouns, branding.
- **`STYLE_RULES`:** your rules. See `references/importing-a-guide.md` for the fields.
- **`WORD_LIST`:** terms to avoid, what to use instead, and the rule each one belongs to.
- **`SAMPLE_DRAFT`** and **`EXAMPLES`:** the preloaded draft and the worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · quick check and prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| The quick check flags something that's fine | It uses simple patterns, so expect a few false positives, mostly on passive voice and numbers. Claude's full check confirms or drops each flag. |
| A brand name keeps getting flagged in headings | Add it to `properNouns` in `CONFIG`, or ask Claude to. |
| Edits cite rules you don't have | Ask Claude to re-import the guide. The checker is told to cite only rule IDs in your guide. |
| "The draft is too long" | Check one section at a time. |
