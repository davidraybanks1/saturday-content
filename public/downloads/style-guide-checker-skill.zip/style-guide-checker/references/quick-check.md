# Quick check (in-browser linter)

The checker page runs a lightweight linter in the browser on every keystroke. It needs no Claude usage. Each flag shows its rule ID, severity and line, and the draft is highlighted inline. The page also sends the flags to Claude as a pre-check, so Claude confirms them, drops false positives and finds what the linter missed.

These are pattern checks, not grammar parsing. Expect a few false positives, mostly on passive voice and numbers.

| Check | Rule (Fieldbook) | How it works | Known misses and false positives |
|---|---|---|---|
| Avoid-list words | W1–W4, I1–I4, G8, F5 | Matches each `WORD_LIST` entry as a whole word, using `forms` for variants and `cs` for case-sensitive brand spellings | Misses misspellings; flags quoted examples of bad words |
| Exclamation points | V4 | Any `!` except Markdown image syntax | Flags `!` inside code or quoted UI text |
| Title Case headings | G1 | Markdown headings (`#`) where two or more words after the first are capitalized and not in `CONFIG.properNouns` | Only checks Markdown headings; may flag headings full of names not listed as proper nouns |
| Long sentences | V6 | Splits each non-heading line on `.`, `!`, `?` and counts words; flags over 30 | Abbreviations with periods split sentences early |
| Likely passive voice | V3 | A form of *be* (am, is, are, was, were, be, been, being), optionally an -ly adverb, then a word ending in -ed or -en or a common irregular participle | Flags adjectives ("is interested"); misses "got" passives |
| Vague link text | A1 | Markdown links whose text is here, click here, this, link, read more, learn more or more; plus "click here" in plain text | Misses vague link text in HTML |
| Number style | G2 | Single digits 1–9 in running text, and spelled-out ten to ninety and hundred | Skips list numbers, percentages, units, versions, steps and dates; may flag counts in tables |
| Em dashes | G7 | Any em dash | Flags em dashes in quotes |
| Double spaces | G6 | Two or more spaces between non-space characters | Doesn't flag trailing spaces |

## Tuning

- **Sentence limit:** change `30` in the long-sentence check, and update the rule text to match.
- **Proper nouns:** add brand and product names to `CONFIG.properNouns` so the heading check leaves them alone.
- **New avoid words:** add `WORD_LIST` entries. No code change needed.
- **Turning a check off:** remove the `lint` field from its rule and delete its block in `lint()`. The rule stays in the guide; Claude still checks it.
- **Mapping to your rule IDs:** each check cites a fixed rule ID (for example, passive voice cites `V3`). If your guide numbers rules differently, update the ID in `lint()` or keep your active voice rule at V3.

## In chat

When working in chat without the page, run the same checks mentally before the judgment pass, and fold the results into the line edits. Don't list the checks separately.
