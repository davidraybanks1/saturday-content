# Severity rubric

Every rule has one severity. Every edit inherits the severity of the rule it cites. Severity tells the writer what to fix before publishing and what can wait.

| Severity | Meaning | Publish with it? |
|---|---|---|
| **must** | Wrong, harmful, inaccessible or off-brand in a way a reader would notice | No |
| **should** | Breaks house voice or mechanics; makes the piece weaker or inconsistent | Only under deadline, and fix it next pass |
| **consider** | Polish and house preferences; reasonable people differ | Yes |

## How to assign severity to a rule

Ask these in order. The first yes sets the severity.

1. **Does breaking it exclude or harm a reader?** Inaccessible links or images, gendered defaults, disability metaphors, terms rooted in race or slavery. → **must**
2. **Is it a factual or brand error?** Misspelled product or company names, wrong feature names, legal or regulated wording. → **must**
3. **Would a careful reader notice and think less of the piece?** Passive voice that hides who acts, long sentences, hype words, exclamation points, Title Case headings, unexplained abbreviations. → **should**
4. **Is it a house preference with a defensible alternative?** Serial comma, contractions, numbers style, paragraph length, double spaces. → **consider**

## Calibrating

- A guide with more than a third of its rules at **must** loses the signal. Move preferences down.
- A rule with no **don't** example is probably a **consider**: if you can't show it going wrong, it rarely matters.
- Raise a rule's severity for a channel when the stakes change. For example, a team may treat number style (G2) as **should** in pricing pages.

## Severity in the output

- **Summary:** count issues by severity, and name the musts first.
- **Line edits:** show severity in every item: `L5 · W1 · must`.
- **Strictness filter:** "Must fix only" reports only musts. "Must and should" adds shoulds. "Everything" reports all three.

## Fieldbook distribution (example)

| Severity | Rules |
|---|---|
| must | I1, I2, I4, A1, A2, A3, W1 |
| should | V1, V2, V3, V4, V6, V7, G1, G5, G8, F1, F2, F5, I3, A4, A5, W2, W4 |
| consider | V5, G2, G3, G4, G6, G7, F3, F4, W3 |
