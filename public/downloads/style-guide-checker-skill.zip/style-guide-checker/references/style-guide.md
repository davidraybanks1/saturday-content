# Fieldbook house style guide

The full guide the checker page carries in its `STYLE_RULES` and `WORD_LIST` blocks. Fieldbook is a fictional company; this guide is an original example written for this skill. Replace it with your team's guide (see `importing-a-guide.md`).

33 rules in 6 categories. Severity is defined in `severity-rubric.md`. Rules marked **quick check** are flagged automatically by the page's in-browser linter.

## Voice and tone (V)

### V1. Lead with what the reader can do

**Severity:** should

Open with the action or the outcome. Background and context come after.

**Why:** Readers decide in the first line whether to keep going. A wind-up about the market spends that line on nothing.

- **Do:** Assign an owner to every review step so drafts stop waiting on someone unknown.
- **Don't:** In today's fast-moving content landscape, teams face more review challenges than ever.

### V2. Specific beats impressive

**Severity:** should

Swap adjectives for the thing itself: a feature, a number from a real source, a short example.

**Why:** Praise words ask the reader to trust us. Specifics let them check.

- **Do:** Each approval step shows its owner and due date.
- **Don't:** Our powerful, intuitive approvals experience.

### V3. Name who does what

**Severity:** should · **quick check**

Write in active voice. Passive is fine when the actor is unknown or doesn't matter.

**Why:** Passive sentences hide the owner, and in product copy the owner is usually the point: who acts, the reader or Fieldbook.

- **Do:** Your editor approves the draft. Fieldbook locks it until then.
- **Don't:** The draft is approved by your editor and is locked until then.

### V4. No exclamation points

**Severity:** should · **quick check**

End sentences with a period. Let the content carry the energy.

**Why:** Exclamation points read as shouting or forced cheer, and they wear out fast across a page.

- **Do:** Calendars now sync with campaign dates.
- **Don't:** Calendars now sync with campaign dates!

### V5. Talk to the reader as you

**Severity:** consider

Address the reader directly. Say "we" for Fieldbook only when the company itself is acting.

**Why:** "Users" and "customers" put distance between the page and the person reading it.

- **Do:** You can filter the calendar by campaign.
- **Don't:** Users are able to filter the calendar by campaign.

### V6. Keep sentences under 30 words

**Severity:** should · **quick check**

Split any sentence over 30 words. Aim for an average under 20.

**Why:** Long sentences make readers hold too much in their heads, and they break up badly on phones and in screen readers.

- **Do:** Most teams review in email and chat. Drafts sit for days because nobody knows who signs off.
- **Don't:** Most teams review content in a mix of email and chat, and the result is that drafts sit for days while nobody is sure who is supposed to sign off on what or when it's due.

### V7. Stay calm when things go wrong

**Severity:** should

In errors, billing and account messages, say what happened and what to do next. No jokes.

**Why:** A reader who just lost work wants a fix, not a personality.

- **Do:** We couldn't save your brief. Check your connection, then try again.
- **Don't:** Oops, something went sideways. Our bad.

## Grammar and mechanics (G)

### G1. Sentence case for headings

**Severity:** should · **quick check**

Capitalize only the first word and proper nouns in headings, buttons, tabs and menu items.

**Why:** Sentence case is faster to read and removes arguments about which small words get capitals.

- **Do:** How to run a content review
- **Don't:** How To Run A Content Review

### G2. Numbers: words to nine, numerals from 10

**Severity:** consider · **quick check**

Spell out zero through nine in running text. Use numerals for 10 and up, and always for percentages, money, measurements, versions, steps and dates.

**Why:** One consistent rule keeps numbers scannable and stops the same count appearing two ways on a page.

- **Do:** Add three reviewers. Briefs with 12 fields take 5% longer to write.
- **Don't:** Add 3 reviewers. Briefs with twelve fields take five percent longer to write.

### G3. Skip the serial comma

**Severity:** consider

Leave out the comma before "and" or "or" in a list, unless the list is ambiguous without it.

**Why:** It's Fieldbook house style. Consistency matters more than which choice we made.

- **Do:** Briefs, calendars and reviews
- **Don't:** Briefs, calendars, and reviews

### G4. Use contractions

**Severity:** consider

Use common contractions such as you'll, don't, isn't and it's. Skip awkward ones such as it'd or should've.

**Why:** Contractions sound like a person talking. Their absence sounds like a contract.

- **Do:** You don't need to set this up again.
- **Don't:** You do not need to set this up again.

### G5. Write dates and times one way

**Severity:** should

Write dates as March 4, 2026 in text and Mar 4 in tables. Write times as 9:30 am PT. Always name the time zone.

**Why:** Numeric dates such as 04/03 mean different days in different countries.

- **Do:** The webinar starts March 4 at 9:30 am PT.
- **Don't:** The webinar starts 3/4 at 9:30AM.

### G6. One space between sentences

**Severity:** consider · **quick check**

Use a single space after a period and between words.

**Why:** Double spaces cause uneven gaps on the web and stray breaks when copy is pasted into other tools.

- **Do:** Save the brief. Then assign a reviewer.
- **Don't:** Save the brief.  Then assign a reviewer.

### G7. Avoid em dash asides

**Severity:** consider · **quick check**

Use a comma, parentheses or a new sentence instead of an em dash aside. Use an en dash without spaces for ranges (10–20).

**Why:** Stacked dashes make sentences sprawl and they render inconsistently across tools.

- **Do:** Reviews (the slowest step for most teams) now have due dates.
- **Don't:** Reviews — the slowest step for most teams — now have due dates.

### G8. Spell out abbreviations once

**Severity:** should · **quick check**

Spell out an abbreviation the first time it appears, unless readers know it better short (PDF, URL, API). Write "for example" and "that is" instead of e.g. and i.e.

**Why:** Unexplained abbreviations shut out new readers, and Latin shorthand trips up screen readers and translators.

- **Do:** Medical, legal and regulatory (MLR) review
- **Don't:** MLR review, e.g. for claims

## Formatting (F)

### F1. Headings in order

**Severity:** should

Use one H1 per page. Don't skip levels: an H3 sits under an H2.

**Why:** Screen reader users jump between headings to navigate. Skipped levels look like missing content.

- **Do:** H1 page title, then H2 sections, then H3 subsections
- **Don't:** H1 page title, then an H4 because it looked the right size

### F2. Lists that match their job

**Severity:** should

Number steps that happen in order. Bullet everything else. Start each item the same way, and skip end periods unless items are full sentences.

**Why:** Parallel lists scan fast. Mixed lists make readers re-read each item.

**Do:**

- Create a brief
- Assign a reviewer
- Set a due date

**Don't:**

- Brief creation
- You should assign a reviewer.
- Due dates


### F3. Bold for interface labels

**Severity:** consider

Bold the names of buttons and fields the reader should look for. Don't bold whole sentences for emphasis.

**Why:** When everything is bold, nothing stands out, and the labels readers need get lost.

- **Do:** Select **Publish** when the last reviewer signs off.
- **Don't:** **This is really important to remember before publishing.**

### F4. Short paragraphs on the web

**Severity:** consider

Keep web paragraphs to three sentences or fewer. One idea per paragraph.

**Why:** Readers skim on screens. Walls of text get skipped.

- **Do:** A three-sentence paragraph with one point, followed by a new paragraph for the next point.
- **Don't:** A seven-sentence paragraph that covers briefs, reviews and reporting at once.

### F5. Name controls by their label

**Severity:** should · **quick check**

Refer to buttons and fields by their exact on-screen label. Say "select", not "click on".

**Why:** "Select" works for mouse, touch and keyboard. Exact labels let readers find the control.

- **Do:** Select **Add reviewer**.
- **Don't:** Click on the little plus icon.

## Inclusive language (I)

### I1. Gender-neutral by default

**Severity:** must · **quick check**

Use "they" for a person whose gender you don't know. Address groups as everyone, team or folks.

**Why:** Our readers are every gender. Defaults that assume one tell the rest the page isn't for them.

- **Do:** When a reviewer signs off, they get a confirmation.
- **Don't:** Hey guys, when a reviewer signs off, he gets a confirmation.

### I2. No disability metaphors

**Severity:** must · **quick check**

Don't use disabilities or mental health conditions as metaphors. Say the plain thing you mean.

**Why:** Words such as crazy, lame or blind spot turn real conditions into insults, and the plain word is clearer anyway.

- **Do:** That result surprised us. Here's the gap in our reporting.
- **Don't:** The results were crazy. Here's our blind spot.

### I3. Skip idioms that don't travel

**Severity:** should · **quick check**

Avoid sports, war and regional idioms. Say the literal thing.

**Why:** Idioms confuse readers working in a second language and break in translation.

- **Do:** The pattern was clear.
- **Don't:** The pattern was a slam dunk, a real home run.

### I4. Neutral technical terms

**Severity:** must · **quick check**

Use allowlist and blocklist, primary and replica, main branch. Avoid terms built on race or slavery.

**Why:** Neutral terms describe the function more accurately and don't carry harm.

- **Do:** Add the domain to your allowlist.
- **Don't:** Add the domain to your whitelist.

## Accessibility (A)

### A1. Link text says where it goes

**Severity:** must · **quick check**

Write link text that describes the destination. Never use "click here", "here" or "read more" alone.

**Why:** Screen reader users often browse a list of links out of context. Twelve links called "here" tell them nothing.

- **Do:** Read the [approval steps guide](https://example.com).
- **Don't:** To learn about approvals, [click here](https://example.com).

### A2. Alt text for every image

**Severity:** must

Describe what an image shows and why it's there. Give decorative images empty alt text.

**Why:** Without alt text, screen reader users get a file name or nothing at all.

- **Do:** alt="Calendar view with three briefs due this week"
- **Don't:** alt="screenshot_final_v2.png"

### A3. Don't rely on color or position

**Severity:** must

Don't point readers to things by color, shape or position alone. Use the label.

**Why:** Color-blind readers, screen reader users and anyone on a narrow screen may not see what you see.

- **Do:** Select **Approve**.
- **Don't:** Click the green button on the right.

### A4. Plain words first

**Severity:** should

Write for an eighth-grade reading level. Pick the short common word when it means the same thing.

**Why:** Plain language helps every reader, including experts who are busy.

- **Do:** Start the review.
- **Don't:** Commence the review process.

### A5. No all caps for emphasis

**Severity:** should

Don't write words in all capitals for emphasis. Acronyms are fine.

**Why:** Some screen readers spell all-caps words letter by letter, and all caps reads as shouting.

- **Do:** This can't be undone.
- **Don't:** This CANNOT be undone.

## Word list (W)

### W1. Product terms exactly

**Severity:** must · **quick check**

Write Fieldbook as one word with a capital F. Use brief, approval step, content library and calendar in lowercase.

**Why:** Brand and feature names are how readers find things in the product and in search.

- **Do:** Open the content library in Fieldbook.
- **Don't:** Open the Content Library in FieldBook.

### W2. No hype words

**Severity:** should · **quick check**

Don't use the hype words on the word list. Replace them with what the feature does.

**Why:** Hype words are what every vendor says, so readers skip them. They also promise more than we can show.

- **Do:** Approvals now show who is next and when it's due.
- **Don't:** Our game-changing approvals unlock seamless collaboration.

### W3. Plain verbs

**Severity:** consider · **quick check**

Prefer the plain verb on the word list: use, help, start, before, to.

**Why:** Inflated verbs add syllables, not meaning.

- **Do:** Use templates to start every brief the same way.
- **Don't:** Utilize templates in order to commence every brief the same way.

### W4. Sign in, set up, email

**Severity:** should · **quick check**

Use sign in (verb) and sign-in (noun), set up (verb) and setup (noun), and email with no hyphen.

**Why:** These words show up on every page. Writing them one way keeps the product and the docs consistent.

- **Do:** Set up your workspace, then sign in by email.
- **Don't:** Setup your workspace, then log in by e-mail.

### Word list

| Avoid | Use | Rule |
|---|---|---|
| FieldBook | Fieldbook | W1 |
| Field Book | Fieldbook | W1 |
| Content Library | content library | W1 |
| revolutionize | say what changes | W2 |
| game-changer | say what it does | W2 |
| unlock | get, see, use | W2 |
| seamless | name the integration | W2 |
| world-class | a specific claim | W2 |
| best-in-class | a specific claim | W2 |
| cutting-edge | new, or name it | W2 |
| supercharge | speed up, improve | W2 |
| empower | let, help | W2 |
| synergy | cut it | W2 |
| utilize | use | W3 |
| leverage (verb) | use | W3 |
| facilitate | help, run | W3 |
| commence | start | W3 |
| in order to | to | W3 |
| prior to | before | W3 |
| click on | select | F5 |
| e.g. | for example | G8 |
| i.e. | that is | G8 |
| e-mail | email | W4 |
| log in | sign in | W4 |
| guys | everyone, team | I1 |
| crazy | surprising, wild | I2 |
| sanity check | quick check | I2 |
| blind spot | gap | I2 |
| lame | weak, dull | I2 |
| slam dunk | clear, easy | I3 |
| home run | clear win | I3 |
| ballpark | rough estimate | I3 |
| whitelist | allowlist | I4 |
| blacklist | blocklist | I4 |
| simply | cut it | W2 |
| basically | cut it | W2 |
