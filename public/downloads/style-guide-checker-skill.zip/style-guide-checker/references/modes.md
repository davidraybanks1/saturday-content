# Modes

Every request is one of three modes. Check and Rewrite need a draft. Explain needs a rule ID or a question about a rule. All three use the house style guide and word list.

## Check a draft

**Use for:** "check", "review", "edit", "proofread", "does this follow our style guide"

**Needs:** the draft. If it's missing, ask for it in one line.

**Options:** a category focus (for example, only accessibility) and a strictness level (must only; must and should; everything). Default is everything.

**Output**
1. **Summary:** two or three sentences on the overall state of the draft, with the count of issues by severity (must, should, consider). Name the two or three fixes that matter most.
2. **Line edits:** a numbered list in the order the issues appear. Each item:
   - `**L<line> · <rule ID> · <severity>**`
   - the original text in quotes → the edited text in quotes
   - a one-sentence reason
   One item per issue. If one phrase breaks two rules, give two items.
3. **Revised version:** the full draft inside a ```` ```text ```` fence, with every edit applied and nothing else changed.

**Rules:** count blank lines when numbering. Skip rules the draft follows; don't list passes. If a rule bends for a good reason (see the rule's edge cases), leave the text alone and don't list it.

## Rewrite to style

**Use for:** "rewrite", "clean up", "fix this", "make this on-style"

**Needs:** the draft.

**Output**
1. **Revised version:** the full draft inside a ```` ```text ```` fence.
2. **What changed:** a bulleted list grouped by rule ID, most important first. Format: `**V3** (3 edits): made reviewers the subject of each sentence.`

**Rules:** same edits as Check would make. Keep headings, links, lists and paragraph order. Don't add content.

## Explain a rule

**Use for:** "why do we…", "explain V3", "is this passive", "what's the rule on numbers"

**Needs:** a rule ID, a rule name, or a question you can map to one rule. If it maps to two, explain the main one and point to the other.

**Output**
1. `## <ID>: <title>` and the rule in one sentence.
2. **Why it matters:** two or three sentences, starting from the guide's own "why".
3. **Do:** three short examples in the company's context.
4. **Don't:** three short examples, each followed by its fix.
5. **Edge cases:** two or three cases where the rule bends or another rule takes over, citing rule IDs.
6. If the user gave text: **Applied to your text**, checking it against this rule only.

## Rules for every mode

- **Cite only real rules.** Use only IDs from the team's guide. Never invent a rule. If something reads badly but no rule covers it, you may mention it once at the end under "Not in the guide", without an ID.
- **Keep the writer's draft.** Change only what a rule requires. Keep meaning, facts, structure and the writer's word choices where they're on-style.
- **Evidence:** never invent statistics, customer names or quotes. If a fix needs a fact you don't have, write `[placeholder: what's needed]`.
- **Formatting:** Markdown with the exact section headings above. No preamble; start with the first heading.
- **Severity:** use the severity the guide sets for each rule. See `severity-rubric.md`.
