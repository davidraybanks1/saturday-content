# Worked examples (Fieldbook)

These are the examples the checker page shows when Claude isn't connected. Fieldbook is a fictional company and the draft is invented. Use them as the model for output structure and tone.

## The sample draft

Preloaded on the page. It breaks about a dozen Fieldbook rules on purpose. Line numbers count blank lines.

```text
 1  # How To Run Faster Content Reviews With Fieldbook
 2  
 3  Reviews are where good content goes to wait!  Most teams utilize a mix of email threads, comment bubbles and Slack messages, and the result is that drafts are passed around for days while nobody is quite sure who is supposed to sign off on what or when the final version is due.
 4  
 5  With FieldBook's new approval steps, you can seamlessly assign 3 reviewers to every brief. Each reviewer is notified when it's their turn, and the draft is locked until they approve it.
 6  
 7  ## Why Reviews Stall
 8  
 9  We talked to twelve content leads last quarter. Hey guys, the pattern was a slam dunk: no owner, no due date.
10  
11  - Approvals were skipped when deadlines got tight
12  - Feedback was scattered across four different tools
13  
14  To set up your first approval step, [click here](https://example.com/approvals). It's a total game-changer for your team!
```

## Check a draft

Input: the sample draft, all categories, everything.

### Summary

A clear point buried under hype and passive voice. 19 issues: 3 must, 12 should, 4 consider. Fix the brand name, the "guys" greeting and the link text first.

### Line edits

1. **L1 · G1 · should** "How To Run Faster Content Reviews With Fieldbook" → "How to run faster content reviews in Fieldbook". Headings are sentence case.
2. **L3 · V4 · should** "goes to wait!" → "goes to wait." No exclamation points.
3. **L3 · G6 · consider** Two spaces after "wait" → one space.
4. **L3 · W3 · consider** "utilize" → "use". Plain verb from the word list.
5. **L3 · V6 · should** The 44-word second sentence → split into two: "Most teams use a mix of email threads, comment bubbles and Slack messages. Drafts sit for days because nobody knows who signs off or when the final version is due."
6. **L3 · V3 · should** "drafts are passed around" → "drafts sit". Names the real problem without a hidden actor.
7. **L5 · W1 · must** "FieldBook's" → "Fieldbook". Product name is one word, one capital.
8. **L5 · W2 · should** "seamlessly assign" → "assign". Hype word; the sentence works without it.
9. **L5 · G2 · consider** "3 reviewers" → "three reviewers". Words for zero to nine.
10. **L5 · V3 · should** "Each reviewer is notified… the draft is locked" → "Fieldbook tells each reviewer when it's their turn and locks the draft until they approve it." Says who acts.
11. **L7 · G1 · should** "Why Reviews Stall" → "Why reviews stall".
12. **L9 · G2 · consider** "twelve content leads" → "12 content leads". Numerals from 10.
13. **L9 · I1 · must** "Hey guys," → cut. Gendered greeting, and it doesn't fit a blog post.
14. **L9 · I3 · should** "a slam dunk" → "clear". Sports idiom.
15. **L11 · V3 · should** "Approvals were skipped" → "Teams skipped approvals".
16. **L12 · V3 · should** "Feedback was scattered across four different tools" → "Feedback lived in four different tools".
17. **L14 · A1 · must** "[click here]" → "[Set up your first approval step]". Link text names the destination.
18. **L14 · W2 · should** "a total game-changer" → "one clear path from draft to sign-off". Hype word; say what it does.
19. **L14 · V4 · should** "for your team!" → end with a period.

### Revised version

```text
# How to run faster content reviews in Fieldbook

Reviews are where good content goes to wait. Most teams use a mix of email threads, comment bubbles and Slack messages. Drafts sit for days because nobody knows who signs off or when the final version is due.

With Fieldbook approval steps, you can assign three reviewers to every brief. Fieldbook tells each reviewer when it's their turn and locks the draft until they approve it.

## Why reviews stall

We talked to 12 content leads last quarter. The pattern was clear: no owner, no due date.

- Teams skipped approvals when deadlines got tight
- Feedback lived in four different tools

[Set up your first approval step](https://example.com/approvals). It gives your team one clear path from draft to sign-off.
```

## Rewrite to style

Input: the sample draft.

### Revised version

```text
# How to run faster content reviews in Fieldbook

Reviews are where good content goes to wait. Most teams use a mix of email threads, comment bubbles and Slack messages. Drafts sit for days because nobody knows who signs off or when the final version is due.

With Fieldbook approval steps, you can assign three reviewers to every brief. Fieldbook tells each reviewer when it's their turn and locks the draft until they approve it.

## Why reviews stall

We talked to 12 content leads last quarter. The pattern was clear: no owner, no due date.

- Teams skipped approvals when deadlines got tight
- Feedback lived in four different tools

[Set up your first approval step](https://example.com/approvals). It gives your team one clear path from draft to sign-off.
```

### What changed

- **W1** (1 edit): FieldBook → Fieldbook.
- **I1** (1 edit): cut "Hey guys".
- **A1** (1 edit): replaced "click here" with link text that names the task.
- **V3** (4 edits): made a person or Fieldbook the subject in each passive sentence.
- **V6** (1 edit): split the 44-word sentence in two.
- **V4** (2 edits): removed both exclamation points.
- **W2** (2 edits): cut "seamlessly" and "game-changer"; the last line now says what the feature does.
- **G1** (2 edits): both headings in sentence case.
- **I3** (1 edit): "slam dunk" → "clear".
- **G2** (2 edits): "3" → "three", "twelve" → "12".
- **W3, G6** (2 edits): "utilize" → "use"; one space between sentences.

## Explain a rule

Input: rule V3, no text.

### V3: Name who does what

Write in active voice, so the reader can see who acts. Passive is fine when the actor is unknown or doesn't matter.

### Why it matters

Most Fieldbook copy is about ownership: who reviews, who approves, what Fieldbook does automatically. Passive voice hides exactly that. "The draft is approved" leaves the reader asking by whom, and whether it's them.

### Do

- Your editor approves the draft, then Fieldbook moves it to **Ready**.
- Fieldbook emails each reviewer when it's their turn.
- You set the due date; Fieldbook shows it on the calendar.

### Don't

- "The draft is approved and moved to Ready." Fix: "Your editor approves the draft, then Fieldbook moves it to **Ready**."
- "Reviewers are notified by email." Fix: "Fieldbook emails each reviewer."
- "Mistakes were made in the March calendar." Fix: "We published the wrong date on the March calendar."

### Edge cases

- **Unknown actor:** "The file was deleted on March 4" is fine in an audit log if nobody knows who deleted it.
- **The object matters more:** "Your brief is saved" is fine as a status message. The reader cares about the brief, not the saver. Keep it short (**V7**).
- **Long sentences:** fixing passive voice can add words. If the sentence passes 30 words, split it (**V6**).
