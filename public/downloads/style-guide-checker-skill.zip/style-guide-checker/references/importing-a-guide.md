# Importing a team's style guide

Turn whatever the team has (a doc, a wiki, a PDF, a list of pet peeves, edited drafts) into rules in the schema below. The page's `STYLE_RULES` and `WORD_LIST` blocks use the same fields.

## Rule schema

```json
{
  "id": "V3",
  "category": "voice",
  "severity": "should",
  "title": "Name who does what",
  "lint": "passive",
  "rule": "Write in active voice. Passive is fine when the actor is unknown or doesn't matter.",
  "why": "Passive sentences hide the owner, and in product copy the owner is usually the point.",
  "do": "Your editor approves the draft. Fieldbook locks it until then.",
  "dont": "The draft is approved by your editor and is locked until then."
}
```

| Field | Required | Notes |
|---|---|---|
| `id` | yes | Category letter plus a number: V voice and tone, G grammar and mechanics, F formatting, I inclusive language, A accessibility, W word list. Never reuse a retired ID. |
| `category` | yes | `voice`, `grammar`, `formatting`, `inclusive`, `accessibility` or `words` |
| `severity` | yes | `must`, `should` or `consider`. See `severity-rubric.md`. |
| `title` | yes | Under 40 characters, sentence case. Shown on the picker card. |
| `rule` | yes | One or two sentences a writer can apply without reading anything else. |
| `why` | strongly recommended | The reason, in one or two sentences. Explain mode leans on it. |
| `do`, `dont` | strongly recommended | Short, realistic examples in the company's own context. Use `\n- ` for list examples. |
| `lint` | no | Only when a built-in check covers this rule: `passive`, `exclaim`, `long`, `titlecase`, `numbers`, `dblspace`, `emdash`, `linktext`, `avoid`. |

## Word list schema

```json
{ "avoid": "utilize", "use": "use", "rule": "W3", "forms": "utiliz(?:e|es|ed|ing)" }
```

| Field | Required | Notes |
|---|---|---|
| `avoid` | yes | The term as people write it. Shown in the guide. |
| `use` | yes | The replacement, or "cut it", or a short instruction. |
| `rule` | yes | The rule ID it belongs to (often a W rule, but inclusive terms belong to I rules). |
| `forms` | no | A regular expression for the variants to catch (plurals, tenses, hyphen or space). Without it, the page matches `avoid` as a whole word. |
| `cs` | no | `true` to match case exactly, for brand spellings such as FieldBook vs Fieldbook. |

## From an existing guide (fastest)

1. **Read the whole guide.** Note its sections; map each to one of the six categories.
2. **Split into atomic rules.** One rule per decision a writer makes. "Use sentence case and avoid exclamation points" is two rules.
3. **Write each rule in the schema.** Keep the guide's intent and the team's examples. Rewrite in your own words: short, imperative, plain.
4. **Fill the gaps.** If the guide gives no reason or no examples, draft them and mark them `(inferred)` in your summary.
5. **Assign severity** with `severity-rubric.md`.
6. **Pull out the word list.** Every "use X, not Y", every banned buzzword, every product spelling. Link each to a rule.
7. **Set `lint`** on rules a built-in check covers.
8. **Merge duplicates and flag conflicts.** If two sections disagree (for example, serial comma yes and no), ask the user which wins.

Aim for 20–40 rules. Over 50 and writers stop reading; under 15 and the checker has little to cite. Put niche rules (legal disclaimers, release notes) in a separate category only if the team writes that content often.

## By interview (no guide yet)

Ask in two or three short rounds, not all at once.

**Round 1: voice**
1. Name two or three words for how your writing should sound, and one it should never sound like.
2. Paste a paragraph you're proud of and one you'd never publish.
3. Which words or phrases make you wince?

**Round 2: mechanics**
4. Headings: sentence case or Title Case?
5. Serial comma, yes or no? Contractions?
6. Numbers: when do you spell them out?
7. How do you write dates, times and your product names?

**Round 3: inclusion and accessibility**
8. Any terms your team has agreed to replace?
9. Who checks alt text and link text today?

Draft the guide from the answers, then fill obvious gaps (accessibility, inclusive language) with sensible defaults marked `(suggested)`.

## Before publishing

Show a compact table of every rule (ID, title, severity, quick check yes or no) and the word list. Ask the user to confirm or correct it. Then write the full entries into the page's `STYLE_RULES` and `WORD_LIST` blocks, and replace `SAMPLE_DRAFT` with a short draft in their domain that breaks five to eight of their rules.

## Don't

- Don't copy a published style guide into a team's guide. Write rules in your own words from the team's materials.
- Don't put confidential product names or unreleased plans in a guide that will be shared beyond the team.
