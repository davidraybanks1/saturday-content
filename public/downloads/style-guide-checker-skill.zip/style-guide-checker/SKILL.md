---
name: style-guide-checker
description: Check drafts against a team's house style guide and return line edits that cite the rule each one breaks, rewrite a draft to style, or explain a rule with do and don't examples. Also builds the team a published Style Guide Checker page with an in-browser quick check that edits with Claude. Use for style guide reviews, copy edits against house rules, importing a style guide, or setting up a style checker page.
---

# Style guide checker

This skill edits writing against a **style guide**: a numbered set of house rules, each with an ID (V3, G1, A1), a category, a severity, the rule, why it exists, and a do and a don't. Every edit cites a rule ID, so writers learn the guide instead of just accepting changes.

There are three modes:

- **Check a draft:** a summary, line-by-line edits with rule IDs and severity, and a clean revised version.
- **Rewrite to style:** just the revised version, plus a list of what changed grouped by rule.
- **Explain a rule:** the why behind one rule, with do and don't examples and edge cases.

It works two ways:

1. **In chat.** The user pastes a draft or asks about a rule; you work from their guide and the playbooks in `references/`.
2. **As a checker page.** You publish `templates/style-guide-checker.html` as a private artifact with the team's guide inside it. Teammates paste a draft, see an instant quick check in the browser, then ask Claude for the full edit on their own account.

## Files

| File | Read it when |
|---|---|
| `references/modes.md` | Running any Check, Rewrite or Explain request |
| `references/severity-rubric.md` | Assigning severity to a rule or an edit |
| `references/importing-a-guide.md` | The user has their own style guide, or none yet |
| `references/style-guide.md` | You need a model of a finished guide (Fieldbook, fictional) |
| `references/example-style-rules.json` | The same guide in the page's data format |
| `references/quick-check.md` | Explaining or tuning the page's in-browser linter |
| `references/worked-examples.md` | You want to see the expected output for each mode |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Find the guide.** Look for one in this conversation, the project's files or a connected doc. If there isn't one, ask whether to import one now (`importing-a-guide.md`) or check against general plain-language practice for this pass. If they choose general practice, say so in the summary and cite no rule IDs.
2. **Pick the mode** from the verb: check, review, edit, proofread → Check. Rewrite, clean up, fix → Rewrite. Why, explain, what does V3 mean → Explain. If unclear, default to Check.
3. **Number the lines** of the draft (blank lines count) so edits can cite `L<n>`.
4. **Run the mechanical checks first** (see `quick-check.md`): avoid-list words, exclamation points, Title Case headings, sentences over the length limit, likely passive voice, vague link text, number style, double spaces. Then read for the judgment rules a linter can't catch (voice, idioms, structure).
5. **Write the output** in the exact structure in `modes.md`.
6. **Keep the writer's draft.** Change only what a rule requires. Don't rewrite for taste. Never invent statistics, customer names or quotes; if a fix needs a fact you don't have, write `[placeholder: what's needed]`.

## Building the checker page for a team

1. **Import the guide** using `importing-a-guide.md`. Show it back as a compact table (ID, title, severity, quick check yes or no) plus the word list, and get a yes before publishing.
2. **Copy `templates/style-guide-checker.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice` (one paragraph), `demoNote` (`""` for a real team), `properNouns` (brand and product names the heading check should leave capitalized), `brand` (their name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `STYLE_RULES`: the team's rules, following the schema in `importing-a-guide.md`. Set `lint` only on rules a built-in check covers.
   - `WORD_LIST`: their avoid and use terms, each pointing at a rule ID.
   - `CATEGORIES`: keep the six defaults unless the team groups rules differently. Every rule's `category` must match an `id` here.
   - `SAMPLE_DRAFT` and `EXAMPLES`: replace with a short draft in their domain that breaks several of their rules, and a worked example per mode written from their guide. Or delete the `EXAMPLES` entries; the Example tab then shows a summary built from the rule itself.
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the quick check still works and the page builds the full prompt for the viewer to paste into Claude.
4. **Tell the user** that the quick check runs in the browser with no Claude usage, that each teammate is asked once to allow the page to use Claude, and that the guide changes when they ask you to update it and republish.

## Keeping the guide current

When the user says a rule changed ("we use the serial comma now", "add 'leverage' to the avoid list"), update the rule or word list entry, keep the IDs stable (retire an ID rather than reuse it), and republish to the same artifact. Summarize the change in one or two lines.
