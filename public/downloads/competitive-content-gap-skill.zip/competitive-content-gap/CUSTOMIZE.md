# Competitive content gap: setup and customization guide

The competitive content gap skill shows which topics your competitors' content covers and yours doesn't. It also shows what only you cover and which audience questions nobody answers. Then it ranks the gaps and briefs the best ones. You can use it two ways:

- **Ask Claude in chat.** For example: "Run a content gap analysis of us against Quillcrate, Draftmoor and Pressfold." Claude collects the page lists itself.
- **Share a gap-map page with your team.** People paste page lists, see the coverage map right away, and ask Claude to prioritize and brief.

---

## What you need

- A Claude plan that supports skills and artifacts. Web search helps in chat but isn't required.
- Your site's URL, and the names or URLs of up to four competitors.
- Optional: a list of questions your audience asks. Good sources are sales calls, support tickets, search queries and community threads.

## 1. Install the skill

Add the `competitive-content-gap` folder (or the .zip) as a skill in Claude. Then check that it appears in your skills list.

## 2. Run your first analysis

Start a new chat and say: **"Use the competitive-content-gap skill to compare our content at [your site] with [competitor sites]."**

- **With web access**, Claude reads each site's sitemap, blog index or resource library to build the page lists. It tells you how many pages it found per site and whether any list is partial.
- **Without web access**, paste each list yourself: URLs, paths or titles, one per line. A pasted sitemap.xml works too.

Add your audience questions in the same message or the next one.

## 3. Publish your gap-map page (optional)

Say: **"Publish our content gap page."** Claude puts your lists, company description and audience into the page and publishes it as a private page. Share it from the page's Share menu.

The page builds the coverage map in the browser, so it works for everyone. The first time a teammate clicks Generate, Claude asks them to allow the page to use Claude. Each generation uses that teammate's own Claude usage.

## 4. Use it

| Step | What happens | Needs Claude |
|---|---|---|
| Paste lists | Topics are pulled from titles and paths and grouped by shared words | No |
| Coverage map | Topics × companies, with page counts and Gap, Strength or Shared labels | No |
| Audience questions | Each question is matched to topics; unmatched ones are Whitespace | No |
| Copy as table | Copies the map as a Markdown table | No |
| Cluster and prioritize | Claude regroups topics by meaning and ranks gaps by fit and effort | Yes |
| Brief the top gaps | A short content brief for each of the top 5 | Yes |

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Swap a competitor | "Replace Draftmoor with [new competitor] and republish." |
| Change who it prioritizes for | "Our audience is now finance leaders at mid-market companies. Update the page." |
| Weight effort differently | "We have no designers, so treat anything needing a template or tool as large effort." |
| Stop one topic swallowing everything | "Treat 'payroll' as a word every page shares." |
| Rerun next quarter | "Recollect the lists and tell me what changed since last time." |
| Rebrand the page | "Use our colors and fonts on the gap page," then share hex codes and Google Fonts names. |
| Remove saturday content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/competitive-content-gap.html`:

- **`CONFIG`:** company, about, audience, voice, branding.
- **`YOUR_CONTENT`, `COMPETITORS`, `QUESTIONS`:** the starting lists.
- **`TOPIC_RULES`:** words to ignore, words every page shares, and synonyms.
- **`RUBRIC` and `MODES`:** how Claude scores gaps, and what each mode returns.
- **`EXAMPLES`:** the worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · map + prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| One huge topic contains half the pages | A word every page shares is being treated as a topic. Add it to `TOPIC_RULES.domain`. |
| Synonyms land in different topics ("decay" and "refresh") | Expected: the map groups by shared words. Run "Cluster and prioritize" to group by meaning, or add a synonym to `TOPIC_RULES.synonyms`. |
| Lists come out short in chat | The site has no sitemap or blocks fetching. Paste the blog index URLs, or export a list from your SEO tool. |
| "The lists are too long" | Trim each list to blog, guide and resource pages. Product, legal and careers pages add noise. |
| Briefs cite numbers you don't have | They shouldn't. The skill uses `[placeholder: …]` instead. If you see a number, ask Claude for its source. |
