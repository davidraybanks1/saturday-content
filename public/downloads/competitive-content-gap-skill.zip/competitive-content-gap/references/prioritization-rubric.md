# Prioritization rubric

Score each gap (and each whitespace question) on four factors. Show the factor scores, not just the total, so the user can push back on a specific number.

| Factor | Scale | How to score |
|---|---|---|
| **Audience fit** | 1–5 | How directly the topic answers a question the target audience asks while choosing or running what the company sells. 5 = a core job to be done; 3 = a regular adjacent task; 1 = curiosity. |
| **Competitive pressure** | 0–3 | 0 = nobody (whitespace); 1 = one competitor, 1–2 pages; 2 = two or more competitors, or one with depth (3+ pages); 3 = most competitors, with depth. |
| **Question match** | 0–2 | 2 = answers a listed audience question; 1 = close to one; 0 = none. |
| **Effort** | S / M / L | S = one article from knowledge the team already has. M = needs an SME, original examples, data or a template. L = a hub, original research, a tool or a series. |

**Priority = Audience fit × 2 + Competitive pressure + Question match − effort penalty** (S 0, M 1, L 3).

The maximum is 15. Break ties toward topics that link naturally to the company's strengths, because internal links and existing authority make them easier to win.

## Adjustments to state, not hide

- **Off-strategy gaps.** If a gap is something the company deliberately doesn't do (no SEO program, no AI angle), list it under "Skip on purpose" with one line of reasoning. Don't rank it.
- **Thin shared coverage.** When a competitor has 3 or more times your pages in a shared cluster, you may rank it as a gap. Mark it "thin".
- **Freshness.** If `lastmod` dates show a competitor's cluster hasn't been updated in two or more years, add 1 to its priority. The pages are beatable.

## Output table

| # | Topic | Who covers it | Fit | Pressure | Q | Effort | Score | Why it matters |
|---|---|---|---|---|---|---|---|---|

Follow the table with **Do these first**: three moves for this quarter, one sentence each.
