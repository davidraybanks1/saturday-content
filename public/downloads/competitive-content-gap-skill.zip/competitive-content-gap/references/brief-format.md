# Gap brief format

One short brief per top gap. Keep each one under about 200 words, so the brief stays something a writer can start from today.

```markdown
### [n]. Working title
- **Gap it closes:** the topic, and which competitors cover it (cite their page titles or paths).
- **Reader and question:** who it's for and the question they're asking, in their words.
- **Angle:** why this piece will be more useful than what competitors published. Name the one thing their pages likely miss, judged from titles unless you read the pages.
- **Outline:** 4–6 H2s.
- **Format and length:** e.g. guide ~1,800 words; template + article; checklist.
- **Internal links:** 2–3 existing pages from the company's own list.
- **Call to action:** one, matched to the funnel stage.
- **Needs before writing:** SMEs, data or examples to gather, as [placeholder: …] lines.
```

End with one line on publishing order and why.

## Rules

- The angle must be specific to this company: its product, audience or point of view. "More comprehensive" is not an angle.
- Cite competitor pages by their exact titles or paths. Don't describe what they say unless you fetched them.
- Never invent statistics, customers or quotes. Use `[placeholder: …]`.
- Internal links must come from the company's own list. Don't invent URLs.
