# Collecting a site's content list

The goal is one line per editorial page: URL, path or title. Try sources in this order and stop when you have a credible list.

## 1. Sitemap

- Fetch `https://<domain>/sitemap.xml`. If it 404s, fetch `https://<domain>/robots.txt` and look for `Sitemap:` lines.
- **Sitemap indexes** list other sitemaps. Open only the editorial ones: names like `post-sitemap.xml`, `blog-sitemap.xml`, `resources-sitemap.xml` or `sitemap-articles.xml`. Skip product, category, tag, author, image and locale sitemaps.
- Pull every `<loc>` value. Keep paths under `/blog/`, `/resources/`, `/guides/`, `/learn/`, `/library/`, `/glossary/`, `/templates/`, `/insights/` and `/compare/`, or the site's equivalent.
- `<lastmod>` is useful. Note how many pages changed in the last 12 months, since it shows how active the program is.

## 2. Blog index

If there's no usable sitemap, fetch the blog home (`/blog`, `/resources`, `/insights`):
- Collect post titles and links.
- Follow pagination (`/page/2`, `?page=2`) up to about 10 pages, or until posts are older than 3 years.
- Category pages help when the index is a feed of only the newest posts.

## 3. Resource library

Many B2B sites keep ebooks, reports, webinars and templates in a separate hub (`/resources`, `/library`, `/content-hub`). Collect titles there too, and note which are gated. Gated assets count as coverage. Their landing-page titles are usually enough.

## 4. Search fallback

If fetching is blocked, run `site:<domain>/blog <topic>` searches for the main clusters you already see. Mark the list **partial**.

## 5. From the user

Ask for an export from their CMS, Google Search Console (Pages report) or an SEO tool. For competitors, a "top pages" export from an SEO tool is the best source when the user has one.

## Cleaning the list

- Remove duplicates, including trailing-slash, `www` and `http` variants and query-string copies.
- Remove non-editorial pages: home, pricing, product, careers, legal, login, author, tag, pagination and `/page/n`.
- Remove other languages unless the analysis is about that market.
- **Cap** at about 400 pages per site. If a site has more, keep the most recent, or the sections relevant to the user's market, and say so.

## Reporting what you collected

Start the analysis with one line per company:

> Quillcrate: 38 pages from post-sitemap.xml (complete). Pressfold: 30 titles from /blog pages 1–3 (partial; older posts not checked).
