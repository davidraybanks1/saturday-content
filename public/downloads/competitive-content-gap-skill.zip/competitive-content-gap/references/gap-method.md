# The gap method

Five steps. The page runs steps 1–4 with word matching in the browser. Claude repeats them by meaning, then adds step 5.

## 1. Turn each page into topic terms

Read the topic from the URL slug (the last meaningful path segment) or the title.

- **Split** slugs on `-`, `_`, `/` and case changes. Drop query strings, file extensions and dates.
- **Skip** path segments that are sections, not topics: `blog`, `resources`, `guides`, `learn`, `en-us`, `category`, `tag`, years.
- **Strip** stopwords (`how`, `to`, `the`, `vs`), format words (`guide`, `template`, `checklist`, `examples`, `ultimate`) and domain words that every page in the market shares (`content`, `marketing`, `b2b`, plus the category name).
- **Stem lightly** so plurals and verb forms match (`briefs` and `brief`, `refreshing` and `refresh`). Map known synonyms (`ops` and `operations`, `KPIs` and `metrics`).

A page with no topic terms left is navigation, not content. Drop it.

## 2. Cluster

- **Word clusters (the page's method).** Find the term or adjacent two-term phrase shared by the most unassigned pages. Make it a cluster. Repeat until no term is shared by two pages. Leftover pages are one-page topics.
- **Meaning clusters (Claude's method).** Group pages that answer the same reader question, even when they share no words ("content decay", "refresh old posts" and "content audit" can be one cluster). Aim for 10–16 clusters for 100–200 pages. Name each cluster by the reader's job, not a keyword ("Measuring ROI and attribution").

Don't make a cluster so broad that most pages land in it. If one cluster holds more than about 20% of all pages, split it.

## 3. Build the coverage matrix

One row per cluster, one column per company. Each cell holds that company's page count in the cluster.

| Status | Rule |
|---|---|
| **Gap** | You have 0 pages; at least one competitor has 1 or more |
| **Strength** | You have 1 or more; every competitor has 0 |
| **Shared** | You and at least one competitor both have pages |

Depth matters. Within Shared, flag clusters where a competitor has 3 or more times your pages as **thin coverage**. These are gaps in all but name.

## 4. Find whitespace

Match each audience question to clusters:
- A question matches when the cluster's defining term appears in it.
- Or when at least about 60% of the question's topic terms appear in one page.

| Result | Meaning |
|---|---|
| Matched one of your pages | Covered |
| Matched competitor pages only | A gap, backed by a real question. Raise its priority. |
| Matched nobody | **Whitespace.** Nobody answers it yet. |

Claude can also infer whitespace from the lists, such as a question implied by competitor topics that nobody answers directly. Label inferred whitespace as inferred.

## 5. Prioritize and brief

Score gaps with `prioritization-rubric.md`. Brief the top five with `brief-format.md`. Whitespace questions compete in the same ranking: score them as gaps with competitive pressure 0 and question match 2.

## Limits to state in every report

- Titles and URLs show what a page is about, not whether it's any good. A competitor's 10 thin pages can lose to your one strong page.
- Lists are only as complete as their source. Say which lists are partial.
- No traffic, ranking or backlink data is used unless the user supplies it.
