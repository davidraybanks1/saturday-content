---
name: competitive-content-gap
description: Map the topics competitors' content covers against yours, find the gaps, strengths and unanswered audience questions, rank the gaps and brief the top ones. Also builds the team a published gap-map page that works with Claude. Use for content gap analysis, competitor content audits, topic coverage comparisons, or deciding what to write next against competitors.
---

# Competitive content gap

This skill compares **your content** with **up to four competitors' content** topic by topic. It returns four things:

- **Gaps:** topics competitors cover and you don't.
- **Strengths:** topics you cover and they don't.
- **Shared:** topics everyone covers.
- **Whitespace:** audience questions nobody's content answers.

It then ranks the gaps by audience fit and effort, and writes short briefs for the top five.

It works two ways:

1. **In chat.** You collect the page lists yourself, using web search and fetch on sitemaps, blog indexes and resource libraries. Then you run the method in `references/gap-method.md`.
2. **As a gap-map page.** You publish `templates/competitive-content-gap.html` as a private artifact. Teammates paste page lists. The page builds the coverage map in the browser, and asks Claude to cluster, prioritize and brief. The page can't browse, so it works only from pasted lists.

## Files

| File | Read it when |
|---|---|
| `references/gap-method.md` | Running any gap analysis, in chat or for the page |
| `references/collecting-content-lists.md` | You need to gather a site's page list (yours or a competitor's) |
| `references/prioritization-rubric.md` | Ranking gaps or choosing which to brief |
| `references/brief-format.md` | Writing briefs for the top gaps |
| `references/sample-data.json` | You need a model of the inputs (Fieldbook and three invented competitors) |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Running it in chat

1. **Get the inputs.** You need:
   - The user's company and site.
   - 1–4 competitors.
   - Optionally, audience questions from sales calls, search, support tickets or communities.

   If the user names competitors but gives no lists, collect the lists yourself (step 2). If they don't name competitors, ask for up to four in one line, or suggest 3–4 from a quick search and confirm them.
2. **Collect the page lists** with `collecting-content-lists.md`. Start with `/sitemap.xml` or `/robots.txt`, then fall back to the blog index and resource library. Keep only editorial pages: blog posts, guides, resources, templates, glossaries, comparisons. Note each list's source and size. Say so plainly if a list is partial (pagination limit, blocked fetch).
3. **Run the method** in `gap-method.md`:
   - Turn each page into topic terms.
   - Cluster by meaning.
   - Build the coverage matrix (clusters × companies, with page counts).
   - Label each cluster Gap, Strength or Shared.
   - Match audience questions to clusters to find whitespace.
4. **Prioritize** the gaps with `prioritization-rubric.md`. Show the score inputs, so the user can disagree with a specific number.
5. **Brief** the top five with `brief-format.md`, if the user asks or the request implies "what should we write".
6. **Keep it honest.**
   - Judge topics from titles and URLs unless you actually fetched a page.
   - Never invent traffic, rankings, statistics, customer names or quotes. Write `[placeholder: what's needed]` instead.
   - If you used an SEO tool's data that the user supplied, say which numbers came from it.

**Output order:**
1. A one-line summary of sources ("Read 212 pages across 4 sites; Pressfold's list is its first 3 blog pages only").
2. The coverage table.
3. Ranked gaps.
4. Strengths.
5. Whitespace.
6. Briefs, if asked.
7. "Do these first": three moves.

## Building the gap-map page for a team

1. **Copy `templates/competitive-content-gap.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `audience` (who the content is for), `voice`, and `demoNote` (`""` for a real team). Also `brand` (their name and URL, or `null`), `footer` (`""` or their line) and `ctaUrl` (`""` hides the get-the-skill box).
   - `YOUR_CONTENT`, `COMPETITORS`, `QUESTIONS`: the lists you collected in chat. These are the starting values; viewers can paste over them. Keep each list to its editorial pages.
   - `TOPIC_RULES.domain`: add the words every page in their market shares (the category name, for example "payroll" or "observability"). Otherwise one cluster swallows everything.
   - `EXAMPLES`: replace them with one worked example per mode from their data, or delete them. The Example tab then shows "No example".
2. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it, or outside Claude, the page still builds the map and writes the full prompt to paste into Claude.
3. **Tell the user** these things:
   - Each teammate is asked once to allow the page to use Claude.
   - Generation uses that teammate's own Claude usage.
   - Whatever a viewer pastes stays in their browser only.
   - To refresh the starting lists, ask you to recollect them and republish.

## Refreshing

When the user asks to rerun it ("check again next quarter", "add a new competitor"), do two things:
- Recollect only the lists that changed.
- Report what moved since last time: new gaps, gaps closed, and new competitor clusters.
