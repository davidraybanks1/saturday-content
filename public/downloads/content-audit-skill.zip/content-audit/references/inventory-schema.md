# Inventory schema

One row per URL. Header names don't need to match exactly; the page guesses from common names and lets you change the mapping.

| Column | Need | What it holds | Notes |
|---|---|---|---|
| `url` | Required | Full URL or path | Query strings and fragments are dropped. Full URLs are reduced to their path. |
| `title` | Recommended | Page title or H1 | Used for duplicate detection and clusters. Without it, the title is guessed from the URL slug. |
| `published` | Recommended | First publish date | YYYY-MM-DD is safest. MM/DD/YYYY and YYYYMMDD also work. |
| `updated` | Recommended | Last meaningful update | Used for "old". Falls back to `published` when empty. |
| `sessions` | Required | Sessions or views in the period | Any traffic measure works, as long as it's the same one for every row. |
| `conversions` | Required | Conversions in the period | Sign-ups, demo requests, key events. Use 0 rather than blank. |
| `sessions_prev` | Optional | Sessions in the previous period of the same length | Needed to spot declining pages. |
| `topic` | Optional | Topic, category or pillar | Gives clean clusters. Pages with different topics are never merged. |
| `backlinks` | Optional | Backlinks or referring domains | Protects pages with links from being retired. |
| `word_count` | Optional | Words on the page | Needed to spot thin pages. |

## Before scoring, check

- **One row per URL.** Merge duplicates caused by trailing slashes, `http` vs. `https`, or tracking parameters, and add their numbers together.
- **Same period for every row.** Mixed date ranges make pages incomparable.
- **No non-content URLs.** Remove search results, tag archives, thank-you pages and anything you'd never edit. Or protect them.
- **Numbers are numbers.** Thousands separators and percent signs are fine; text like "n/a" is read as blank.
- **At least 12 months.** Shorter windows punish seasonal pages.

## Minimal example

```csv
url,title,published,updated,sessions,conversions
/blog/how-to-write-a-content-brief,How to write a content brief,2022-03-14,2025-11-02,18400,212
/blog/content-brief-checklist,Content brief checklist,2020-02-04,2020-02-04,410,0
```

`sample-inventory.csv` is a full 62-page example with every optional column.
