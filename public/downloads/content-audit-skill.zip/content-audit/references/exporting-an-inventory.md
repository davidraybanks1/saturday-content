# Exporting an inventory

An inventory joins three things: **the list of pages** (from your CMS or a crawl), **traffic and conversions** (from your analytics tool), and optionally **search and link data**. These are generic steps. Menu names differ between tools and change over time, so look for the equivalent in yours.

## 1. The list of pages (CMS)

Most CMSs can export posts and pages, either built in, through a plugin, or through their API.

1. Export every published page and post. Skip drafts, archived items and media.
2. Keep these fields: URL or slug, title, publish date, last modified date, and category or tag if you use them for topics.
3. If your CMS exports slugs rather than full paths, add the folder (`/blog/`) so they match your analytics URLs.
4. Save as CSV.

**No CMS export?** A site crawler, or your XML sitemap, gives you the URL list. Sitemaps often include a last-modified date (`lastmod`), which can stand in for `updated`.

## 2. Traffic and conversions (analytics)

In your analytics tool, open the report that lists pages or landing pages.

1. Set the date range to the last 12 months.
2. Use page path (or landing page) as the row dimension.
3. Add sessions (or views) and your conversion measure: sign-ups, demo requests, or whatever counts as a conversion for you.
4. Turn on comparison to the previous period, if the tool offers it, and export that column too. That becomes `sessions_prev`.
5. Export every row, not just the first page of results. Check the row limit.
6. Save as CSV.

**If you use GA4:** the pages report and the landing page report both work. Landing pages count the session where it started, which suits content that brings people in. Conversions appear as key events in current versions. The Explore section is often easier for exporting many rows with a comparison period. If your property shows different names, use the closest equivalents.

## 3. Search data (optional)

If you use Google Search Console, the Performance report's Pages tab exports clicks and impressions per URL. Clicks can stand in for sessions on sites without analytics, and impressions help spot pages that rank but don't get clicks. Search Console uses full URLs; the audit reduces them to paths.

## 4. Backlinks (optional)

Any backlink tool can export referring domains per URL. Use referring domains rather than total links; a single site linking 500 times is still one site.

## 5. Join them

Use a spreadsheet, or ask Claude to do it:

1. Put the CMS export in one tab and analytics in another.
2. Match on path (strip the domain, query strings and trailing slashes first).
3. Bring sessions, previous sessions and conversions into the CMS tab. Pages with no analytics row get 0.
4. Add backlinks and word count if you have them.
5. Export as CSV with one header row.

Or attach the separate exports to a chat and say: **"Join these into one content inventory for the content-audit skill."**

## Common problems

| Problem | Fix |
|---|---|
| Paths don't match between exports | Lowercase everything and remove trailing slashes, `?` parameters and the domain. |
| Analytics shows URLs that aren't pages | Filter out search results, tag pages, thank-you pages and anything with parameters. |
| Some pages missing from analytics | They had no traffic. Keep them with 0 sessions; they're likely Retire candidates. |
| Export cut off | Analytics tools cap rows per export. Raise the row count or export in chunks. |
