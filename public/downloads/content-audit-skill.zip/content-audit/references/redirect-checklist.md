# Redirect and merge checklist

Use this before acting on any Merge or Retire verdict. Work in batches of 10–20 pages so you can see the effect.

## Before you change anything

- [ ] **Read both pages.** The rules matched on titles. Confirm the merge target really covers the same intent.
- [ ] **Check for backlinks** you didn't have in the inventory. A page with strong links may deserve a merge rather than a retire.
- [ ] **Check internal links.** Search the site for links to the URL. Note every page that links to it.
- [ ] **Check where it's used outside the site:** email nurtures, ads, sales decks, partner pages, social bios, QR codes.
- [ ] **Note the current numbers** for both pages (sessions, conversions, rankings if you track them) so you can compare later.
- [ ] **Get sign-off** from whoever owns the page. Customer stories and legal pages usually have an owner outside the content team.

## Merging (Merge verdict)

1. Copy anything unique from the weaker page into the target: a better example, a section the target lacks, a useful image or quote you have rights to.
2. Update the target's title and intro if the merged page covered an angle the target didn't.
3. Update the target's "last updated" date.
4. Publish the target first.
5. Then add a **301 (permanent) redirect** from the merged URL to the target.
6. Remove the merged page from your sitemap.

## Retiring (Retire verdict)

1. Decide where it redirects. Use the suggested target unless something closer exists. Avoid redirecting everything to the home page.
2. Add a **301 redirect** to the target.
3. If nothing relevant exists, let it return 410 (gone) or 404 instead of redirecting to an unrelated page.
4. Remove it from the sitemap.
5. Archive the content somewhere internal in case you need it back.

## After

- [ ] **Test every redirect.** Each old URL should return a single 301 straight to the target, with no chains (A → B → C) and no loops.
- [ ] **Update internal links** to point at the target directly, rather than relying on the redirect.
- [ ] **Fix redirect chains** created by earlier redirects that pointed at the page you just redirected.
- [ ] **Update outside uses** you noted: emails, ads, decks.
- [ ] **Check the target** after 6–8 weeks: did it keep or gain the combined traffic?
- [ ] **Keep a redirect log** (from, to, date, reason). The "Copy redirect map" button gives you the first two columns.

## Things to avoid

- Deleting pages without redirects.
- Redirecting to the home page as a catch-all.
- Retiring pages that convert, even a little, without a closer look.
- Merging and refreshing the same target in separate passes. Do both at once.
- Changing many URLs right before a site migration. Do one or the other.
