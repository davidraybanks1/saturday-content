# Scoring rules

Every page gets exactly one verdict. The rules run in this order, and the first one that matches wins. The page's `RULES` block holds every threshold named here; the defaults are in brackets.

## Before the rules: what gets measured

| Measure | How it's worked out |
|---|---|
| **Traffic tier** | Relative to this inventory. High: sessions at or above the 75th percentile [`highTrafficPercentile: 75`]. Low: at or below the 30th percentile, and always under 100 sessions [`lowTrafficPercentile: 30`, `minSessions: 100`]. Everything else is mid. |
| **Old** | Not updated (or, with no update date, not published) for 24 months or more [`staleMonths: 24`]. |
| **Declining** | Sessions down 25% or more against the previous period [`declineShare: 0.25`]. Needs a previous-sessions column. |
| **Weak conversion** | Conversion rate (conversions ÷ sessions) under half the inventory's median rate [`weakConversionShare: 0.5`]. Only for pages with at least `minSessions`. |
| **Thin** | Under 500 words [`thinWords: 500`]. Needs a word-count column. |
| **Strong** | High traffic and conversions at or above the inventory's median. |
| **Value** | sessions + conversions × 25 + backlinks × 40 [`conversionWeight`, `backlinkWeight`]. Used to decide which of two similar pages is stronger, and to rank pages. Shown as a 0–100 percentile. |
| **Similarity** | How much two titles overlap, from 0 to 1. Rare words count more than common ones; format words like "guide" or "complete" are ignored [`ignoreWords`]. Pages in the same URL folder get +0.1 [`sameFolderBonus`]. Pages with different topics never match. |
| **Cluster** | The topic column if there is one. Otherwise, the most-shared distinctive word in the title. |

## The rules

1. **Keep (protected).** The path is on the protect list [`protect: ["/", "/pricing", "/product/*"]`]. Core pages need a human review, not a rule.
2. **Keep (too new).** Published under 6 months ago [`newMonths: 6`]. It hasn't had time to earn traffic.
3. **Retire.** Low traffic, at most 0 conversions [`retireMaxConversions: 0`], old, and fewer than 5 backlinks [`retireMaxBacklinks: 5`]. Redirect target: the most similar surviving page in the same cluster, or the cluster's hub if nothing is close, or `/blog` [`fallbackRedirect`].
4. **Merge (near-duplicate).** Its most similar page scores 0.5 or more [`mergeSimilarity: 0.5`], has a higher value, and this page isn't strong. Target: that sibling, or, if the sibling is itself going away, wherever the sibling goes.
5. **Merge (keep the links).** Would have been retired, but has 5 or more backlinks. Fold it into the cluster's hub so the links still count.
6. **Refresh.** Declining, old, weak-converting or thin, and still earning something (not low traffic, or has at least one conversion). The reason lists every signal that fired.
7. **Keep.** Nothing above matched. Labeled "Strong", "Healthy" or "Small but healthy".

**The hub** of a cluster is its highest-value page with a Keep or Refresh verdict. Merges and redirects never point at a page that is itself being merged or retired.

## Why it works this way

- **Relative tiers, not fixed numbers.** "Low traffic" means something different on a 60-page blog and a 6,000-page one. Percentiles adapt; `minSessions` stops a tiny site from protecting pages with 20 visits.
- **Retire is strict on purpose.** A page needs four signals at once: low traffic, no conversions, old, few backlinks. Anything less gets a softer verdict.
- **Merge before Refresh.** Refreshing two pages that compete for the same query wastes the work. Consolidate first.
- **Backlinks save pages from deletion, not from change.** A dead page with links becomes a merge, so the links pass to a live page through the redirect.

## Limits to tell the user about

- The rules see titles and numbers, not the pages. A title match is a strong hint of overlap, not proof. Check merges by reading both pages.
- Seasonal pages (annual reports, event pages) can look dead off-season. Use 12 months of data or protect them.
- Conversions are only as good as the tracking. A page with zero conversions may assist conversions elsewhere.
- Rules flag; people decide. Treat every Merge and Retire as a recommendation to check, especially on pages with backlinks.

## Tuning guide

| If the audit… | Change |
|---|---|
| Retires too much | Raise `retireMaxBacklinks`, lower `lowTrafficPercentile`, or raise `staleMonths` |
| Retires too little | Raise `retireMaxConversions` to 1–2, or raise `lowTrafficPercentile` |
| Merges pages that aren't duplicates | Raise `mergeSimilarity` to 0.6, or add the shared words to `ignoreWords` |
| Misses obvious duplicates | Lower `mergeSimilarity` to 0.4 |
| Flags too many refreshes | Raise `staleMonths` or `declineShare` |
