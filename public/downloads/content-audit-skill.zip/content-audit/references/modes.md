# Modes

Both modes start from a scored inventory: every page with its verdict, reason and target (see `scoring-rules.md`). The page sends Claude the summary, then the pages that need action grouped by cluster, plus the top Keep pages in each cluster.

## Recommend actions

**Use for:** "what should we do", "prioritize", "audit plan", "where do we start"

**Output**
1. **The short version:** 2–3 sentences on the state of the inventory, using the summary numbers.
2. **Priorities:** the 8–10 actions worth doing first, in order. Group related pages into one action (a merge plus its redirects, say). Each gets: the URLs, what to do, why (numbers from the data), and effort and impact as low, medium or high.
3. **By cluster:** 1–3 sentences per cluster: the hub, what to fix, any gap the titles suggest.
4. **Verdicts to check by hand:** rule-based verdicts you disagree with, and why.
5. **Quick wins this week:** 3–5 small tasks.

**How to prioritize:** high-value Refresh pages first (traffic and backlinks at stake), then consolidations that remove competing pages, then bulk retirements. Effort is low for redirects, medium for refreshes, high for rewrites.

## Write refresh briefs

**Use for:** "refresh briefs", "what should the writer change", "brief the top refreshes"

The page picks the top Refresh pages by value [`RULES.briefCount: 5`] and sends, for each: its numbers, why it was flagged, the pages being folded into it, and the other live pages in its cluster.

**Output:** one brief per page, each under 250 words, headed "Refresh brief N: <url>":
- **Why now:** the numbers that triggered it.
- **Goal of the refresh:** one sentence tied to the content goal.
- **What to check and update:** 4–6 bullets. Claude hasn't read the page, so these are things to check, with assumptions marked.
- **Fold in:** pages merging into this one and what to take from each.
- **Internal links to add:** 2–3 pages from the same cluster.
- **CTA:** the call to action that fits.
- **Measure:** what to compare, and over what window.

## Rules for both modes

- **Evidence:** use only numbers from the inventory. Never invent statistics, keywords, rankings, customer names or quotes. Write `[placeholder: what's needed]` instead.
- **Honesty about scope:** say when a suggestion depends on reading the page.
- **Disagreement is welcome:** if a rule-based verdict looks wrong, say so and why.
- **Formatting:** Markdown with clear headings. Refer to pages by path. Start with the output, no preamble.
