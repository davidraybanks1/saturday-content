---
name: content-audit
description: Audit a content inventory and recommend what to keep, refresh, merge or retire, with a reason and a redirect target for every page. Also builds the team a published Content Audit page that scores a CSV in the browser and writes the plan and refresh briefs with Claude. Use for content audits, content pruning, consolidation and redirect planning, or picking refresh candidates.
---

# Content audit

This skill turns a **content inventory** (one row per URL with traffic, conversions and dates) into a verdict for every page: **Keep, Refresh, Merge or Retire**. Verdicts come from transparent rules first, so anyone can see why a page got one. Claude then adds judgment on top: a prioritized plan, and refresh briefs for the pages worth saving.

It works two ways:

1. **In chat.** The user shares an inventory; you score it with the rules in `references/scoring-rules.md`, then write the plan or briefs.
2. **As an audit page.** You publish `templates/content-audit.html` as a private artifact. Teammates upload a CSV, map the columns, and get the scored table, clusters and a redirect map in the browser. With Claude connected, the page also writes the plan and refresh briefs on their own account.

## Files

| File | Read it when |
|---|---|
| `references/scoring-rules.md` | Scoring any inventory, or explaining or changing a verdict |
| `references/inventory-schema.md` | Checking or cleaning an inventory before scoring |
| `references/exporting-an-inventory.md` | The user doesn't have an inventory yet |
| `references/modes.md` | Writing the plan (Recommend actions) or refresh briefs |
| `references/redirect-checklist.md` | The user is about to act on Merge or Retire verdicts |
| `references/sample-inventory.csv` | You need a model inventory, or a demo |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Get the inventory.** Look for a CSV or spreadsheet in the conversation or project. If there isn't one, point the user to `exporting-an-inventory.md` and offer to work from a pasted sample. Required columns: url, sessions, conversions. Strongly recommended: title, published, updated. Optional: previous-period sessions, topic, backlinks, word count.
2. **Check it** against `inventory-schema.md`. Say in one line which columns you found, which are missing, and what that changes (no dates means nothing can be called old, for example).
3. **Score every page** with the rules in `scoring-rules.md`, in order. If you can run code, run the scoring rather than eyeballing it. Show the counts per verdict and a table of the pages that need action, each with its reason and target.
4. **Write what the user asked for**, following `modes.md`: the prioritized plan, refresh briefs, or both.
5. **Keep it honest.** Use only the numbers in the inventory. You haven't read the pages themselves, so frame content suggestions as things to check. Never invent statistics, keywords, customers or quotes; write `[placeholder: what's needed]` instead.

## Building the audit page for a team

1. **Ask what to tune.** The defaults in `RULES` suit most B2B blogs. Ask only about the protect list (pages that must never be flagged, such as home, pricing and product pages) and whether "old" should be something other than 24 months.
2. **Copy `templates/content-audit.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about` (2–3 sentences), `voice`, `goal` (what content should achieve), `demoNote` (`""` for a real team), `brand` (their name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` hides the get-the-skill box).
   - `RULES`: thresholds and the protect list. Each line is commented.
   - `COLUMNS`: add the header names from the team's own export to `match` so mapping is automatic.
   - `SAMPLE_CSV`: replace with the team's own inventory if they want it preloaded, or keep the Fieldbook sample. Set `SAMPLE_AS_OF` to the export date.
   - `EXAMPLES`: replace with examples written from their inventory, or delete the entries.
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the page still scores everything in the browser and builds the prompt for the viewer to paste into Claude.
4. **Tell the user** that the CSV never leaves their browser unless they click Generate, that each teammate is asked once to allow the page to use Claude, and that generation uses their own Claude usage.

## Re-running the audit

When the user brings a fresh export ("here's this quarter's data"), score it again with the same rules and say what changed since last time: pages that moved verdict, and merges or retirements that still haven't shipped.
