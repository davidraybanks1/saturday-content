# Content audit — setup and customization guide

The content audit scores every page in your content inventory as Keep, Refresh, Merge or Retire, gives the reason for each, and suggests where merged and retired pages should redirect. You can use it two ways:

- **Ask Claude in chat.** For example: "Audit this inventory and tell me what to retire."
- **Share an audit page with your team.** People upload a CSV and get the scored table, topic clusters and a redirect map. With Claude connected, the page also writes the plan and refresh briefs.

---

## What you need

- A Claude plan that supports skills and artifacts.
- A content inventory as a CSV: one row per URL with sessions and conversions, ideally with title, published and updated dates. See `references/exporting-an-inventory.md` if you don't have one.

## 1. Install the skill

Add the `content-audit` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Export your inventory

Pull a list of URLs from your CMS, then add traffic and conversions from your analytics tool for the same period. Add last period's sessions if you can; that's how the audit spots declining pages. `references/exporting-an-inventory.md` has the steps.

Use at least 12 months of data. Shorter windows make seasonal pages look dead.

## 3. Run the audit

Start a new chat, attach the CSV and say: **"Use the content-audit skill to audit this inventory."**

Claude checks the columns, scores every page, and shows the counts and the pages that need action. Then ask for what you need:

| Ask for | You get |
|---|---|
| "Recommend actions" | A prioritized plan, cluster by cluster, with effort and impact |
| "Write refresh briefs" | A short brief for each of the top refresh candidates |
| "Give me the redirect map" | Every Merge and Retire URL with its target, as CSV |

## 4. Publish the audit page (optional)

Say: **"Publish our content audit page."** Claude sets your company details and rules in the page and publishes it as a private page. Share it from the page's Share menu.

Anyone with the page can upload a CSV. Scoring happens in their browser. The data goes to Claude only when they click Generate, and each generation uses that person's own Claude usage.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Protect pages | "Never flag anything under /docs/ or /legal/." |
| Change what counts as old | "Call a page old after 18 months, not 24." |
| Retire more aggressively | "Retire pages with up to 2 conversions if they're old and low traffic." |
| Catch more duplicates | "Lower the merge similarity to 0.4 and show me what changes." |
| Map your export automatically | "Our export calls it 'Landing page' and 'Leads'. Add those to the column matching." |
| Rebrand the page | "Use our colors and fonts on the audit page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/content-audit.html`:

- **`CONFIG`:** company, about, house voice, content goal, branding.
- **`RULES`:** every threshold, with a comment on each line. `references/scoring-rules.md` explains them.
- **`COLUMNS`:** the header names the page recognizes when you upload a CSV.
- **`SAMPLE_CSV`:** the preloaded inventory. Paste your own to have it load by default.
- **`EXAMPLES`:** the worked examples shown when Claude isn't connected.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · scores in your browser" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Scoring still works. To generate, open it in claude.ai or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| Nothing is retired | Check that a date column is mapped. Without dates, no page counts as old. |
| No pages are "declining" | Map a previous-period sessions column. |
| Clusters look odd | Map a topic or category column. Without one, clusters are guessed from shared title words. |
| A key page got Retire or Merge | Add its path to `RULES.protect`. Then check the data: it may be tracked under another URL. |
| "The inventory is too large for one request" | Filter the export to one section of the site, or raise the low-traffic thresholds so fewer pages need action. |
| Dates read wrong | Use YYYY-MM-DD in the export. The page also reads MM/DD/YYYY and YYYYMMDD. |
