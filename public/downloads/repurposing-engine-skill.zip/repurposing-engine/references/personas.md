# Personas and funnel stages (short form)

The repurposing engine uses a short version of the messaging library from the B2B content studio skill: just enough to aim the pack at one reader. Both picks are optional. With neither, the pack is written for a general practitioner audience at the top of the funnel.

## Persona entry

```json
{
  "id": "content-lead",
  "name": "Content lead",
  "icon": "target",
  "blurb": "Ship more without more meetings",
  "angle": "What this reader cares about in one sentence. The pack leads with the atoms that speak to it.",
  "avoid": "One or two 'Don't…' lines."
}
```

| Field | Required | Notes |
|---|---|---|
| `id`, `name`, `blurb` | yes | Shown on the picker card. Blurb under 40 characters. |
| `icon` | no | A key from the page's `ICON` map |
| `angle` | yes | Steers which atoms each asset leads with |
| `avoid` | recommended | Keeps the pack on-message |

If the team already has a full messaging library (from the B2B content studio skill), take `angle` from each entry's `goal` and `pains`, and `avoid` from its `avoid` field.

## Fieldbook personas (demo)

| Persona | Angle | Avoid |
|---|---|---|
| Content lead | Fewer review rounds and status meetings; briefs the whole team follows | Don't call Fieldbook a project management tool. Don't lead with AI. |
| Demand gen marketer | Campaign content that ships on time and can be tied to pipeline | Don't promise attribution magic. |
| Product marketer | Launch assets that stay on-message and are easy for sales to find | Don't suggest anyone else should own positioning. |
| Marketing ops | Clean, consistent structure for content work and data that can be reported on | Don't say "seamless". Be specific. |
| Writer and creator | Clear briefs up front, feedback in one place, fewer surprise rewrites | Don't talk about output or productivity metrics. |
| Executive buyer | A content program leadership can see, measure and defend | Don't bury the outcome under features. |

## Funnel stages

| Stage | What changes in the pack |
|---|---|
| **Top of funnel** | Lead with the problem and the idea. Mention the company lightly or not at all. CTAs: watch, read, follow. |
| **Middle of funnel** | Lead with the method. Show where the product fits without pushing. CTAs: get the template, register, see how it works. |
| **Bottom of funnel** | Lead with outcomes and proof from the source. The sales email and FAQ do the heavy lifting. CTAs: book a call, start a trial. |

The source decides what's true; the persona and stage only decide what leads.
