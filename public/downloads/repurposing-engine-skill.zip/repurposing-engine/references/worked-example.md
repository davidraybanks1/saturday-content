# Worked example: the full pack for the sample source

- **Source:** `sample-source.md` ("Briefs that survive review", Fieldbook webinar excerpt, about 900 words)
- **Outputs:** all eight
- **Persona:** Content lead
- **Funnel stage:** Middle of funnel

Every number and quote below comes from the source. Nothing was added.

---

## Atom map

- **Core belief:** Most content goes wrong in the brief, not the draft, and a short brief that's actually finished fixes it.
- **Lead atoms by asset:** LinkedIn 1 → the 4.2 vs 2.1 stat · LinkedIn 2 → the five fields · LinkedIn 3 → "a brief nobody wrote down" · Video → Jordan's Monday question · Email → 16 to 9 days · Thread → the five fields · FAQ → audience questions from Priya, Tomás and Jordan

---

## LinkedIn post 1: the stat

We pulled 140 of our own briefs and matched each one to how many review rounds the finished piece needed.

Briefs that left the audience vague: 4.2 rounds on average.
Briefs that named a specific role and the one belief we wanted to change: 2.1.

Same writers. Same reviewers. Same quarter.

When a piece comes back with forty comments, most of them aren't about the writing. They're about who it's for, what it should prove, and what the reader should do next. Those are brief questions. If the brief doesn't answer them, the review does, and review is the most expensive place to answer anything.

What does your team's brief leave for review to decide?

#ContentOps #ContentMarketing

*For: Maya Okafor*

## LinkedIn post 2: the method

Our brief template once had 23 fields.

Writers filled in word count and due date. They skipped the hard ones.

Now it has five, and all five are required:

1. The reader, by role. Not a persona nickname.
2. The one thing they should believe after reading.
3. What they believe today, and why it's wrong.
4. The proof, with links. Not "some stats."
5. The single next step.

A short template that's actually finished beats a long one that's half finished.

Which of the five does your team skip?

#ContentMarketing #Briefs

*For: Maya Okafor*

## LinkedIn post 3: the quote

"What's not fine is quietly rewriting the piece to a brief nobody wrote down."

Maya Okafor said this on our webinar last week, and I keep thinking about it.

Her point: a brief isn't only instructions for the writer. It's a record of what the team agreed. So when a late comment contradicts it, there are two honest options. The brief was wrong, so you update it and accept the delay. Or the comment is out of scope, and it goes on a list for the next piece.

Both are fine. The silent rewrite isn't.

Full recording in the comments.

#ContentOps

*For: Dev Ramirez*

---

## Newsletter section

### Your briefs are doing more damage than your drafts

When a piece comes back from review covered in comments, it's tempting to blame the draft. Maya Okafor, head of content at Fieldbook, thinks that's usually wrong. On our latest webinar she shared what happened when her team matched 140 briefs to the review rounds each piece needed: briefs with a vague audience averaged 4.2 rounds, and briefs that named a specific role and one belief averaged 2.1.

Her fix is five required fields: the reader by role, the one belief, what they believe today, the proof with links, and the next step. Briefs now take about 20 minutes longer to write, and pieces move from brief to publish in 9 working days instead of 16.

"You spend 20 minutes up front to save a week at the back."

[Link: watch the full recording and get the five-field template]

---

## Blog post summary

*Adapted from the Fieldbook webinar "Briefs that survive review."*

### How to write a content brief that survives review

**Meta description:** Most review rounds fix problems the brief should have solved. Five required fields that cut review rounds roughly in half.

When a draft comes back with forty comments, the writing usually isn't the problem. In a recent Fieldbook webinar, head of content Maya Okafor explained why most content goes wrong in the brief, and what her team changed.

#### The review is answering the brief's questions

"The draft gets blamed for decisions nobody made earlier," Okafor said. Most review comments ask who the piece is for, what it should prove, and what the reader should do next. If the brief doesn't answer those, the review does.

Her team tested this on 140 of their own briefs from last year. Briefs that left the audience vague averaged 4.2 review rounds. Briefs that named a specific role and the one belief to change averaged 2.1, with the same writers and reviewers in the same quarter.

#### Five required fields

1. **The reader, by role.** "Marketing ops manager at a 200-person software company," not a persona nickname.
2. **The one belief.** One thing the reader should believe after reading. Two beliefs means two pieces.
3. **What they believe today, and why it's wrong.** This is where the tension comes from.
4. **The proof, with links.** The actual sources, or "no proof yet" if it's an opinion piece.
5. **The single next step.**

The team's old template had 23 fields. Writers filled in the easy ones and skipped the hard ones. "A short template that's actually finished beats a long one that's half finished."

#### Who writes it, and what it costs

The brief belongs to whoever will defend the piece in review, usually the strategist or content lead. Writers get a fifteen-minute brief review to push back before they start. Briefs now take about 20 minutes longer, and the average piece goes from brief to publish in 9 working days instead of 16.

#### When a stakeholder ignores the brief

The brief is a record of what the team agreed. A late comment that contradicts it means either the brief was wrong (update it and accept the delay) or the comment is out of scope (save it for the next piece).

#### Start on Monday

If you change one thing, make the belief field required. No brief moves to drafting until someone has written, in one sentence, what the reader should believe afterward.

**[Watch the full recording and get the five-field template]**

---

## Sales follow-up email

**Subject:** The one field to add to your briefs
**Alternative subject:** 16 days to 9, from one brief change

Hi [First name],

Thanks for joining "Briefs that survive review."

If you only take one thing from it: Maya's team cut brief-to-publish time from 16 working days to 9, and the change started with making one field required. The belief field. No brief moves to drafting until someone writes, in one sentence, what the reader should believe afterward.

The five-field template from the session is here: [Link]

If your team is looking at how briefs and reviews run today, I'm happy to walk through how Fieldbook sets up required brief fields and review steps. Would 20 minutes next week be useful?

[Rep name]

---

## Short video script

**Length:** about 60 seconds · **Speaker:** Maya Okafor

| Time | Said | On screen |
|---|---|---|
| 0–5s | "If I can only change one thing on Monday, what should it be?" | Text: *One change for Monday* |
| 5–15s | "When a piece comes back from review with forty comments, most of those comments aren't about the writing." | Maya to camera |
| 15–30s | "We pulled 140 briefs. The ones that left the audience vague averaged 4.2 review rounds. The ones that named a specific role and one belief averaged 2.1." | Text: *4.2 rounds → 2.1 rounds* |
| 30–45s | "A good belief is something a reader could disagree with. If the belief is safe, the piece will be forgettable." | Text: *Is your belief arguable?* |
| 45–55s | "Make the belief field required. Even if you change nothing else, you'll see it in the reviews within a month." | Text: *Make the belief field required* |
| 55–60s | Voiceover: "Get the five-field brief template." | Text: *Five-field template, link in caption* |

---

## 5 pull quotes

> "The draft gets blamed for decisions nobody made earlier." — Maya Okafor, head of content, Fieldbook

*Works best:* quote card, opening slide.

> "If the brief doesn't answer them, the review does, and the review is the most expensive place to answer anything." — Maya Okafor

*Works best:* LinkedIn image, blog pull quote.

> "A short template that's actually finished beats a long one that's half finished." — Maya Okafor

*Works best:* quote card, newsletter.

> "You spend 20 minutes up front to save a week at the back." — Maya Okafor

*Works best:* sales email sign-off, slide.

> "If the belief is safe, the piece will be forgettable." — Maya Okafor

*Works best:* quote card, video overlay.

---

## Social thread

1/ We matched 140 content briefs to the review rounds each piece needed. Vague audience: 4.2 rounds. Specific role plus one belief: 2.1. Here are the five fields that made the difference.

2/ The reader, by role. "Marketing ops manager at a 200-person software company" beats a persona nickname, because a writer can picture that person's Tuesday.

3/ The one belief. One thing the reader should believe after reading. If you write two, you have two pieces.

4/ What they believe today, and why it's wrong. That's where the tension in the piece comes from.

5/ The proof, with links. Not "add stats." The actual source, or "no proof yet" so everyone knows it's an opinion piece.

6/ The single next step for the reader.

7/ The old template had 23 fields. Writers filled in the easy ones and skipped the hard ones. Five fields, all required, all finished.

8/ If you only change one thing: make the belief field required. Full webinar and template: [Link]

---

## FAQ

**Who should write the brief, the strategist or the writer?**
"The person who will defend the piece in review," said Maya Okafor. Usually that's the strategist or content lead. The writer should push back before starting, which is why her team runs a fifteen-minute brief review.

**Doesn't a longer brief slow everything down?**
It moves the time rather than adding it. Briefs take about 20 minutes longer to write, and the average piece goes from brief to publish in 9 working days instead of 16.

**What do you do when a stakeholder ignores the brief and rewrites the piece?**
Show them the brief. Either the brief was wrong, so you update it and accept the delay, or the comment is out of scope and goes on a list for the next piece.

**If I can only change one thing, what should it be?**
Make the belief field required. Don't let a brief move to drafting until someone has written, in one sentence, what the reader should believe afterward.

**What makes a good belief?** *(likely question)*
Something a reader could disagree with. "Content is important" isn't a belief. "Your calendar isn't why content slips, your briefs are" is.

**What if we don't have proof for the piece?** *(likely question)*
Write "no proof yet" in the brief so everyone knows it's an opinion piece, rather than asking the writer to find numbers later.

**Why only five fields?** *(likely question)*
Long templates get half filled. The team's 23-field template had the easy fields done and the belief field blank, which Okafor called worse than five fields filled in properly.
