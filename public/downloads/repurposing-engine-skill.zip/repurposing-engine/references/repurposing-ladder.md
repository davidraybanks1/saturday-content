# The repurposing ladder

Not every asset is worth the same effort. The ladder ranks the eight outputs by how much work they take after the pack is generated, against how far they usually travel. Use it to decide what to publish first when time is short.

| Rung | Asset | Effort to finish | Typical reach | Lifespan | Notes |
|---|---|---|---|---|---|
| 1 | Pull quotes | Very low | Medium | Weeks | Drop into a quote-card template; reuse in slides and emails |
| 2 | Sales follow-up email | Low | Narrow but warm | One send | Highest intent readers you have; send within 48 hours of the event |
| 3 | LinkedIn posts (3) | Low | Medium to high | Days each | Space them a few days apart; post from a person, not the brand |
| 4 | Social thread | Low | Medium | Days | Works on X, Threads, Bluesky; the method atom carries it |
| 5 | Newsletter section | Low | Owned audience | One send, then archive | Link to the full recording or post |
| 6 | FAQ | Medium | Search, sales, support | Months | Add to the resource page or help center; feeds sales enablement |
| 7 | Blog post summary | Medium | Search | Months to years | Needs a final edit, links and an image; best long-term return |
| 8 | Short video script | High | High if produced well | Weeks | Needs recording and editing; reuse the original speaker if you can |

## How to read it

- **Low rungs first.** Quotes, the follow-up email and LinkedIn posts can ship the same week as the source with little more than a read-through.
- **Middle rungs build durable reach.** The FAQ and blog summary keep working long after the event.
- **The top rung costs the most.** A video script is only worth it if someone will record it.

## A one-week rollout for a webinar

| Day | Publish |
|---|---|
| Day 0 (event) | Sales follow-up email to attendees |
| Day 1 | LinkedIn post 1 (strongest stat), newsletter section |
| Day 3 | LinkedIn post 2 (method), social thread |
| Day 5 | Blog post summary with the FAQ at the end |
| Day 8 | LinkedIn post 3 (quote), pull quote cards |
| Later | Video script, when someone has time to record |

## Spread the atoms

If every asset leads with the same stat, the audience sees one idea eight times. Assign a different lead atom to each asset (see `atoms-first.md`). The core belief is the only thing that should appear everywhere.
