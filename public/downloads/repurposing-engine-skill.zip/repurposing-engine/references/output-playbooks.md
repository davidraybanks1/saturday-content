# Output playbooks

The page carries short versions of these in its `OUTPUTS` block. Use the fuller notes below when repurposing in chat. Every asset follows the rules in `atoms-first.md`: facts from the source only, quotes word for word and attributed.

## 3 LinkedIn posts
- **Count:** three, each leading with a different atom (a stat, the method, a quote or contrarian belief).
- **Length:** 120–220 words each.
- **Hook:** the first two lines show before "see more". Put the atom there.
- **Body:** one idea, one example from the source, one takeaway. One- or two-line paragraphs.
- **Ending:** a question or a light pointer to the full source ("Full recording in the comments").
- **Hashtags:** 3 at most, at the end.
- **Voice:** first person, written for a named person to post (usually the speaker or host).
- **Avoid:** "I'm excited to share", "Key takeaways from today's webinar", engagement bait.

## Newsletter section
- **Length:** 150–250 words.
- **Shape:** a short headline, two or three paragraphs, a link line (`[Link: full recording]`).
- **Angle:** what the reader gets from it, not what happened at the event.
- **Include:** one stat and one short quote at most.

## Blog post summary
- **Length:** 500–800 words.
- **Title:** an H1 a reader would search for. Suggest a meta description under 155 characters.
- **Intro:** two or three sentences naming the problem and the payoff.
- **Body:** 3–4 H2 sections following the source's own structure; the method atom as a list.
- **Quotes:** two at most, attributed with role.
- **Ending:** a short conclusion and one CTA (watch the recording, get the template).
- **Note at the top:** "Adapted from [source name]" so readers know it's a recap.

## Sales follow-up email
- **Reader:** someone who attended or registered. Warm, not cold.
- **Length:** 90–150 words. Subject line under 50 characters, plus one alternative.
- **Shape:** thanks in one line, the single most useful idea for this reader, one stat, one soft ask (a reply, a 20-minute call, or the resource).
- **Avoid:** recapping the whole session, attachments-first emails, "just following up."
- **Placeholders:** `[First name]`, `[Rep name]`, `[Link]`.

## Short video script
- **Length:** 45–75 seconds when read aloud (about 120–180 words of voiceover).
- **Shape:** a table or list with time codes: hook (0–5s), problem (5–15s), the idea (15–45s), close and CTA (last 10s).
- **Columns:** time, what's said, what's on screen (text overlay or b-roll note).
- **Hook:** open with a question or the strongest stat. No logo intro.
- **Speaker:** write it for the original speaker when possible, using their actual lines.

## 5 pull quotes
- **Count:** five, exactly as said. Trim with an ellipsis only.
- **Length:** under 30 words each; under 20 is better for quote cards.
- **Format:** `> "Quote." — Name, role`
- **Pick for:** a point of view, a number, or a turn of phrase. Skip lines that only make sense in context.
- **Add:** one line under each saying where it works best (quote card, slide, email sign-off).

## Social thread
- **Count:** 5–8 posts, numbered `1/`, `2/`…
- **Post length:** under 280 characters each.
- **Post 1:** the hook (stat or contrarian belief) and a promise of what's in the thread.
- **Middle:** the method atom, one step per post.
- **Last post:** the takeaway and a pointer to the source.

## FAQ
- **Count:** 5–7 questions.
- **Source of questions:** first the questions asked in the source (audience Q&A), then questions a reader would likely ask next.
- **Answers:** 2–4 sentences, using the source's answers. Attribute when you quote.
- **Mark** questions not asked in the source with "(likely question)" in a comment or note to the editor, so they can be checked.

## Adding outputs

Add an entry to `OUTPUTS` in the page (id, name, icon, blurb, play). Good candidates: a slide outline, an Instagram carousel, a podcast show-notes block, a sales one-pager, a customer email newsletter, a press pitch.
