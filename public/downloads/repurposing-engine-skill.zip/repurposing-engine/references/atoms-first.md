# Atoms first: the repurposing method

Most repurposing goes wrong in the same way: someone opens the source, skims it, and starts writing a LinkedIn post from memory. The post drifts from what was said, a number gets rounded, a quote gets paraphrased into something the speaker never said, and the reviewer sends it back.

Atoms first fixes that. Before writing any asset, break the source into **atoms**: the smallest pieces that can stand on their own. Then build every asset from atoms, not from memory.

## The five kinds of atom

| Atom | What it is | How to find it | Used most in |
|---|---|---|---|
| **Core belief** | The one thing the source wants the reader to believe | Ask: what would the speaker argue for if challenged? | Every asset (it's the spine) |
| **Quote** | A sentence that works on its own, attributed to a named speaker | Short, declarative, has a point of view, no "this" or "that" pointing backward | Pull quotes, LinkedIn, video, thread |
| **Stat** | Any sentence containing a number from the source | Scan for digits and number words | LinkedIn hooks, email, newsletter |
| **Question** | A question the source asks or answers | Audience Q&A, interviewer questions, rhetorical questions | FAQ, thread, video hook |
| **Method** | A list, framework or set of steps | "First… second…", numbered fields, "three things" | Blog summary, thread, newsletter |

The page extracts quotes, stats and questions automatically, plus word count and reading time. You supply the core belief and the method, or Claude finds them during generation.

## The process

1. **Read the whole source once** without writing anything.
2. **Write the core belief in one sentence.** If you can't, the source may hold two pieces. Pick one.
3. **List the atoms.** Copy them exactly. Keep the speaker name next to every quote and the context next to every number ("140 briefs, from their own team, last year").
4. **Check each stat.** Note what it measures and what it doesn't. "4.2 review rounds on average" is not "twice as many comments."
5. **Map atoms to assets.** Each asset leads with a different atom, so the set doesn't repeat itself. A typical map:
   - LinkedIn post 1 leads with the strongest stat
   - LinkedIn post 2 leads with the method
   - LinkedIn post 3 leads with a quote or a contrarian belief
   - Video script opens with a question
   - FAQ uses the questions the audience actually asked
6. **Write each asset from its atoms.** Add only connective tissue and what the format needs (a hook, a CTA, a subject line).
7. **Fact-check against the atom list**, not against your memory of the source.

## Rules that never bend

- **Never invent a stat.** If an asset needs a number the source doesn't have, write `[placeholder: number needed]`.
- **Never invent or improve a quote.** Quote marks mean the speaker said exactly those words. Trim with an ellipsis if you must; never rephrase inside quotes.
- **Attribute every quote** to the speaker named in the source, with their role the first time.
- **Don't merge two numbers into a new one.** If the source says 16 days before and 9 after, you may say "from 16 to 9 working days." You may not say "44% faster" unless the source says it.
- **Keep the speaker's hedges.** "Roughly half" stays "roughly half."
- **If the source names audience members,** use first names only as the source does, or drop them.

## When the source is weak

If the source has no stats, no quotable lines or no clear belief, say so before writing. A thin source makes a thin pack. Suggest which assets still make sense (usually the newsletter section and FAQ) and skip the rest.
