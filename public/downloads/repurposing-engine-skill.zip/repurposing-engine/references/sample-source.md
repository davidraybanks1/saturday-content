# Sample source: Fieldbook webinar transcript (excerpt)

Invented for the demo. Fieldbook is a fictional content operations platform, and every name, number and quote below is made up. Use it to try the repurposing engine, then replace it with your own source.

- **Event:** "Briefs that survive review", a Fieldbook webinar
- **Host:** Dev Ramirez, community lead at Fieldbook
- **Guest:** Maya Okafor, head of content at Fieldbook
- **Length of excerpt:** about 900 words

---

**Dev Ramirez:** Welcome back, everyone. For the next half hour we're talking about the least glamorous document in content marketing: the brief. Maya, you've said the brief is where most content goes wrong. Why there and not in the draft?

**Maya Okafor:** Because the draft gets blamed for decisions nobody made earlier. When a piece comes back from review with forty comments, most of those comments aren't about the writing. They're about who the piece is for, what it's supposed to prove, and what the reader should do next. Those are brief questions. If the brief doesn't answer them, the review does, and the review is the most expensive place to answer anything.

**Dev Ramirez:** You actually measured this, right?

**Maya Okafor:** We did. Last year we pulled 140 briefs from our own team and matched each one to how many review rounds the finished piece needed. The briefs that left the audience vague averaged 4.2 review rounds. The briefs that named a specific role and the one belief we wanted to change averaged 2.1. Same writers, same reviewers, same quarter. The only real difference was the brief.

**Dev Ramirez:** That's half the review time.

**Maya Okafor:** Roughly half the rounds, yes. And the rounds you cut are the painful ones, the late rewrites where a stakeholder shows up and says, "Wait, who is this for?"

**Dev Ramirez:** So what goes into a brief that survives review?

**Maya Okafor:** Five fields, and we made all five required. First, the reader, by role, not by persona nickname. "Marketing ops manager at a 200-person software company" beats "Ops Olivia" every time, because a writer can picture that person's Tuesday. Second, the one thing the reader should believe after reading. One thing. If you write two, you have two pieces. Third, what the reader believes today and why it's wrong. That's where the tension in the piece comes from. Fourth, the proof we'll use, with links. Not "some stats," the actual sources. Fifth, the single next step we want the reader to take.

**Dev Ramirez:** Only five? People expect a longer template.

**Maya Okafor:** Long templates are part of the problem. We had a brief template with 23 fields at one point. Writers filled in the easy ones, like word count and due date, and skipped the hard ones. A brief with 23 fields and the belief field left blank is worse than a brief with five fields filled in properly. A short template that's actually finished beats a long one that's half finished.

**Dev Ramirez:** We've got a question from the audience. Priya asks: "Who should write the brief, the strategist or the writer?"

**Maya Okafor:** The person who will defend the piece in review. Usually that's the strategist or the content lead. The writer should push back on the brief before they start, and we built a fifteen-minute brief review into our process for exactly that. If the writer can't explain the one belief back to you in a sentence, the brief isn't done.

**Dev Ramirez:** Doesn't that slow everything down?

**Maya Okafor:** It moves the time, it doesn't add it. Our briefs now take about 20 minutes longer to write. But the average piece goes from brief to publish in 9 working days instead of 16. You spend 20 minutes up front to save a week at the back.

**Dev Ramirez:** Another question, from Tomás: "What do you do when a stakeholder ignores the brief and rewrites the piece anyway?"

**Maya Okafor:** You show them the brief. That's the other job a brief does: it's a record of what we agreed. When a late comment contradicts the brief, the reviewer has two options. Either the brief was wrong, and we update it and accept the delay, or the comment is out of scope and it goes into a list for the next piece. Both are fine. What's not fine is quietly rewriting the piece to a brief nobody wrote down.

**Dev Ramirez:** I like that. "A brief nobody wrote down."

**Maya Okafor:** It happens constantly. Somebody has a different brief in their head, and the review is where you find out.

**Dev Ramirez:** Let's talk about the belief field, because I think that's the one people struggle with. What does a good one look like?

**Maya Okafor:** A good belief is something a reader could disagree with. "Content is important" is not a belief, nobody argues with it. "Your calendar isn't why content slips, your briefs are" is a belief, and some readers will push back, which is exactly what makes it worth writing. If the belief is safe, the piece will be forgettable.

**Dev Ramirez:** And the proof field? Where do teams get that wrong?

**Maya Okafor:** They write "add stats" and hope the writer finds some. Then the writer finds a number from an unrelated survey, and the reviewer flags it, and that's another round. We ask for the specific source in the brief, or we write "no proof yet" so everyone knows the piece is an opinion piece. Being honest about that up front saves a lot of arguments.

**Dev Ramirez:** Last question before we wrap. From Jordan: "If I can only change one thing on Monday, what should it be?"

**Maya Okafor:** Make the belief field required. Don't let a brief move to drafting until someone has written, in one sentence, what the reader should believe afterward. Even if you change nothing else, you'll see it in the reviews within a month.

**Dev Ramirez:** Maya, thank you. For everyone watching, the five-field brief template is in the resources tab, and we'll send the recording tomorrow.

**Maya Okafor:** Thanks, Dev. And to everyone with a 23-field template: you can delete 18 of them. Nobody will notice.
