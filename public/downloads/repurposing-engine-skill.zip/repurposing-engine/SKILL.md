---
name: repurposing-engine
description: Turn one long source (webinar transcript, long post, report, podcast notes) into a full pack of on-message assets (LinkedIn posts, newsletter section, blog summary, sales follow-up email, short video script, pull quotes, social thread, FAQ) using only facts and quotes from the source. Also builds the team a published Repurposing Engine page that extracts atoms in the browser and writes the pack with Claude. Use for repurposing, content recycling, "turn this webinar into…", or setting up a repurposing workflow.
---

# Repurposing engine

This skill turns one long piece into a set of assets that all say the same true thing. It works **atoms first**: before writing anything, break the source into its smallest standalone pieces (core belief, quotes, stats, questions, method), then build every asset from those atoms, never from memory.

It works two ways:

1. **In chat.** The user pastes or attaches a source and asks for assets; you extract atoms and write the pack using the playbooks in `references/`.
2. **As an engine page.** You publish `templates/repurposing-engine.html` as a private artifact with the team's company, voice and personas inside it. Teammates paste a source, see its atoms instantly in the browser, tick the outputs they want, and the page writes the whole pack with Claude on their own account.

## Files

| File | Read it when |
|---|---|
| `references/atoms-first.md` | Any repurposing request. The method and the rules that never bend |
| `references/output-playbooks.md` | Writing any of the eight outputs |
| `references/personas.md` | A persona or funnel stage is chosen or implied, or you're setting up the team's personas |
| `references/repurposing-ladder.md` | The user asks what to publish first, or how to roll out the pack |
| `references/sample-source.md` | You need a test source, or want to show how the engine works |
| `references/worked-example.md` | You need a model of a finished pack |
| `CUSTOMIZE.md` | Buyer-facing guide; point the user to it |

## Using it in chat

1. **Get the source.** If it's long, work from the whole thing; don't summarize it first. If it's a transcript without speaker labels, ask who is speaking before writing any quotes.
2. **Resolve the picks.** Outputs from the request ("a few LinkedIn posts and an email" → those two); if none are named, propose the four lowest rungs of the ladder (pull quotes, sales email, LinkedIn posts, newsletter section) and say so in one line. Persona and funnel stage are optional; take them from the request or leave them open.
3. **Extract atoms** following `atoms-first.md`. Show the atom map (core belief plus the lead atom for each asset) at the top of the pack.
4. **Write each asset** under its own `##` heading, following `output-playbooks.md`. Give each asset a different lead atom.
5. **Fact-check against the atoms.** Every number must appear in the source with the same meaning. Every quote must be word for word and attributed to the named speaker. Anything missing becomes `[placeholder: what's needed]`. Never invent statistics, names, customers or quotes, and never compute new percentages the source doesn't state.

## Building the engine page for a team

1. **Gather the setup:** company name, a 2–3 sentence description, house voice rules, a default CTA, and 3–6 personas in the short form from `personas.md`. If the team already has a messaging library (for example from the B2B content studio skill), derive the personas from it. Show the personas back as a compact table and get a yes.
2. **Copy `templates/repurposing-engine.html`** and edit only the top of the script:
   - `CONFIG`: `title`, `company`, `about`, `voice`, `ctaDefault`, `demoNote` (`""` for a real team), `brand` (their name and URL, or `null`), `footer` (`""` or their line), `ctaUrl` (`""` to hide the get-the-skill box).
   - `OUTPUTS`: keep the eight defaults, edit a `play` to match house rules, or add outputs (each needs `id`, `name`, `icon`, `blurb`, `headings`, `play`, `effort`, `reach`, `life`).
   - `PERSONAS` and `FUNNEL`: the team's personas; keep the funnel unless they use other stages.
   - `SAMPLE_SOURCE` and `EXAMPLE`: replace with one of their own sources and a pack you wrote from it, or set `SAMPLE_SOURCE` to `""` and `EXAMPLE.text` to `""`.
3. **Load the `artifact-design` and `artifact-capabilities` skills**, then publish with:
   ```json
   {"sample": {}}
   ```
   That lets the page ask Claude on the viewer's own account. Without it (or outside Claude), the page still extracts atoms and builds the full prompt for the viewer to paste into Claude.
4. **Tell the user** that each teammate is asked once to allow the page to use Claude, that each pack is one generation on their own Claude usage, and that long sources with all eight outputs can be cut short (the page says so; pick fewer outputs).

## Keeping it current

When the team's rules change ("our LinkedIn posts are always under 150 words", "add a slide outline output", "drop the exec persona"), edit the matching block, keep the shape, and republish to the same artifact. Summarize what changed in one or two lines.
