# Repurposing engine — setup and customization guide

The repurposing engine turns one long piece (a webinar transcript, a long post, a report, podcast notes) into a full set of assets: three LinkedIn posts, a newsletter section, a blog post summary, a sales follow-up email, a short video script, five pull quotes, a social thread and an FAQ. Every asset is built from what the source actually says. No invented numbers, no made-up quotes.

You can use it two ways:

- **Ask Claude in chat.** For example: "Use the repurposing engine on this transcript. I want LinkedIn posts and a follow-up email for content leads."
- **Share an engine page with your team.** People paste a source, see its quotes, numbers and questions straight away, tick the outputs they want, and the page writes the whole pack with Claude.

---

## What you need

- A Claude plan that supports skills and artifacts.
- A source to repurpose. Transcripts work best when each turn starts with the speaker's name ("Maya Okafor: …").
- Optional: your company description, house voice, and the personas you write for.

## 1. Install the skill

Add the `repurposing-engine` folder (or the .zip) as a skill in Claude, then check that it appears in your skills list.

## 2. Try it in chat

Start a new chat, attach or paste a source, and say: **"Use the repurposing engine. Make the full pack."** Claude shows an atom map first (the core belief and which quote or number each asset leads with), then each asset under its own heading.

## 3. Publish your engine page (optional)

Say: **"Set up our repurposing engine page."** Claude asks for your company description, house voice and personas (or builds the personas from your messaging library if you have one), shows them back for a yes, and publishes a private page. Share it from the page's Share menu.

The first time each teammate clicks Generate, Claude asks them to allow the page to use Claude. Each pack is one generation on that teammate's own Claude usage.

## 4. Use the page

| Step | What happens |
|---|---|
| Paste the source | Word count and reading time update as you type |
| Atoms | The page lists candidate pull quotes, every sentence with a number, and every question, with the speaker next to each. No Claude needed. Copy them with one click |
| Make… | Tick any of the eight outputs |
| For… / At… | Optional persona and funnel stage. They change what each asset leads with, not what's true |
| Generate the pack | One generation writes every asset you ticked. Each asset has its own Copy button |

Outside Claude, the page builds the full prompt (atoms included) for you to paste into Claude, and shows a finished example pack for the sample source.

The **Method and ladder** tab explains the atoms-first method and ranks the outputs by effort and reach, so you know what to ship first.

---

## Customizing

Ask Claude in plain words. Common requests:

| You want | Ask Claude |
|---|---|
| Change an output's rules | "Our LinkedIn posts are always under 150 words with no hashtags. Update the engine." |
| Add an output | "Add a slide outline and podcast show notes as outputs." |
| Add or change personas | "Add a CFO persona: they care about cost per asset and don't want feature talk." |
| Change the voice | "Make the house voice warmer. Here's a post we like: …" |
| Use your own sample | "Replace the sample with this transcript and write the example pack from it." |
| Rebrand the page | "Use our colors and fonts on the engine page," then share hex codes and Google Fonts names. |
| Remove Saturday Content branding | "Remove the brand strip and footer, and put our company name there." |

### If you edit the file yourself

Everything you'd change is at the top of the script in `templates/repurposing-engine.html`:

- **`CONFIG`:** company, about, house voice, default CTA, branding.
- **`OUTPUTS`:** the eight outputs and their playbooks. See `references/output-playbooks.md`.
- **`PERSONAS` and `FUNNEL`:** who you write for. See `references/personas.md`.
- **`METHOD`:** the steps shown on the Method tab.
- **`SAMPLE_SOURCE` and `EXAMPLE`:** the preloaded source and its finished pack. Replace them, or set both to `""`.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Demo · prompt builder" shows instead of "Live" | The page is open outside Claude, or it was published without the `sample` capability. Open it in claude.ai, or ask Claude to republish it with that capability. |
| "Claude isn't allowed for this page" | Allow it from the page's permissions menu, then try again. |
| Quotes are attributed to the wrong person, or "No speaker labels found" | Start each turn of the transcript with the speaker's full name and a colon. Add a line like "Guest: Name, role" at the top to get roles. |
| The atoms panel misses a good quote | The quote finder is a simple heuristic. Claude reads the whole source, so it will still find it. |
| "The pack was cut short" | Tick fewer outputs, or paste a shorter excerpt, and generate again. |
| Output has `[placeholder: …]` in it | The asset needed a fact the source doesn't contain. Fill it in, or delete the line. That's the engine refusing to invent. |
| Generate button stays disabled | Paste a source and tick at least one output. |
